# DataChannel

## Tool to collate business data from disparate sources