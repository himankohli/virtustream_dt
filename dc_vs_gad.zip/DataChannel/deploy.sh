git reset HEAD --hard
git pull -vvv
cp project_config.prod.json project_config.json
cp init/main_config.$1.json init/main_config.json