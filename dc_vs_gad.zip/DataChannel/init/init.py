import os
import sys
import json
import time
import logging
import subprocess
import traceback
import logging.handlers

# build sys.argv dict
args_dict = {}
for arg in sys.argv:
    if "--" in arg and "=" in arg:
        args_dict[arg.split("=")[0].replace("--","")] = arg.split("=")[1]

# get dir of current file
basepath = os.path.dirname(__file__)    

# creating logging dir
if not os.path.isdir("/var/log/DataChannel"):
    print("executing command: mkdir /var/log/DataChannel")
    subprocess.call(["mkdir", "/var/log/DataChannel"])

# get logging level
loglevel = args_dict["loglevel"] if "loglevel" in args_dict else "DEBUG"

# logging basic configuration   
root = logging.getLogger()
root.setLevel(loglevel)
# adding handler to stdout as well
ch = logging.StreamHandler(sys.stdout)
# adding rotation
handler = logging.handlers.RotatingFileHandler(filename='/var/log/DataChannel/init.log', maxBytes=1024*1024*1, backupCount=99)
# defining the format
formatter = logging.Formatter('%(asctime)s : %(levelname)s : %(message)s','%m/%d/%Y %H:%M:%S')
ch.setFormatter(formatter)
ch.setLevel(loglevel)
root.addHandler(ch)
root.addHandler(handler)

started_timestamp = time.time()

logging.info("Started")

# load project config 
project_config = {}

filepath = os.path.abspath(os.path.join(basepath, "..", "project_config.json")) # "project_config.json" is one dir level up 
with open(filepath) as project_config_json:
    project_config = json.loads(project_config_json.read())
    logging.info("project_config loaded")

current_user = subprocess.check_output(["whoami"]).decode("utf-8").strip("\n")

logging.info("current logged in user: {0}".format(current_user))

logging.debug("Reading /etc/passwd file to check existing users")

existing_users_lst = []
with open("/etc/passwd") as existing_users:
    existing_users_lst = [user.split(":")[0] for user in existing_users.read().split("\n")]

with open("{0}init/main_config.json".format(project_config["source_dir"])) as in_file:
    main_json = json.loads(in_file.read())
for client in main_json:
    machine_user = str(client['username'].strip())
    logging.debug("checking if user already exists")
    if machine_user in existing_users_lst and False:
        logging.debug(machine_user + " user already exists! Exiting!")
    else:
        machine_user_password = str(client['password'].strip())
        logging.info("starting for user:" + machine_user)
        logging.info("creating user and group")
        logging.debug("executing command: useradd " + machine_user)
        try:
            subprocess.call(["useradd", machine_user])
        except:
            logging.error('exception while "useradd":'.format(traceback.format_exc()))
        logging.info("creating home dir for {0}".format(machine_user))
        logging.debug("executing command: mkdir /data/{0}".format(machine_user))
        subprocess.call(["mkdir", "/data/{0}".format(machine_user)])
        logging.info("creating user password")
        logging.debug("executing command: echo " + machine_user + ":<REDACTED> | sudo chpasswd")
        password_change_return = subprocess.check_output(["sh", "{0}init/call_chpasswd.sh".format(project_config["source_dir"]), machine_user , machine_user_password ])
        logging.info("saving a copy of the current client config from main_config.json to the users home directory as user_config.json")
        with open("/data/{0}/user_config.json".format(machine_user), "w") as user_config_file:
            user_config_file.write(json.dumps(client, indent=2))
        logging.info("Getting selected data_destination")
        for data_destination in client["data_destination"]:
            if data_destination["active"]:
                break
        # print(data_destination)
        logging.info("checking Data Sources for " + machine_user)
        for data_source in client['data_sources']:
            data_source_name = data_source["name"]
            logging.info("Data Source: " + data_source_name)
            logging.info("Creating dirs for " + machine_user + "'s " + data_source_name)
            logging.debug("executing command: mkdir -p /data/" + machine_user + "/" + data_source_name + "/work/log")
            subprocess.call(["mkdir", "-p", "/data/" + machine_user + "/" + data_source_name + "/work/log"])
            logging.debug("executing command: mkdir -p /data/" + machine_user + "/" + data_source_name + "/auth")
            subprocess.call(["mkdir", "-p", "/data/" + machine_user + "/" + data_source_name + "/auth"])
            logging.debug("executing command: mkdir -p /data/" + machine_user + "/" + data_source_name + "/data/processing")
            subprocess.call(["mkdir", "-p", "/data/" + machine_user + "/" + data_source_name + "/data/processing"])
            logging.debug("executing command: mkdir -p /data/" + machine_user + "/" + data_source_name + "/data/downloaded")
            subprocess.call(["mkdir", "-p", "/data/" + machine_user + "/" + data_source_name + "/data/downloaded"])
            logging.debug("executing command: mkdir -p /data/" + machine_user + "/" + data_source_name + "/data/completed")
            subprocess.call(["mkdir", "-p", "/data/" + machine_user + "/" + data_source_name + "/data/completed"])
            logging.debug("executing command: mkdir -p /data/" + machine_user + "/" + data_source_name + "/data/error")
            subprocess.call(["mkdir", "-p", "/data/" + machine_user + "/" + data_source_name + "/data/error"])

            if data_source_name == 'GoogleAds' and os.path.exists("{0}init/googleads.yaml".format(project_config["source_dir"])):
            	logging.info('copying yaml file to user\'s data source\'s auth dir')
            	with open("{0}init/googleads.yaml".format(project_config["source_dir"])) as googleads_yaml_file:
            		with open('/data/{machine_user}/{data_source_name}/auth/googleads.yaml'.format(machine_user=machine_user, data_source_name=data_source_name), 'w') as auth_yaml:
            			auth_yaml.write(googleads_yaml_file.read())

            if os.path.exists("{0}init/{1}".format(project_config["source_dir"], data_source["config_file"])):
                logging.info("Saving a copy of the config file to the user's directory")
                logging.debug("executing command: cp {0}init/{1} {2}".format(project_config["source_dir"], data_source["config_file"], "/data/" + machine_user + "/" + data_source_name +"/work/reports_config.json"))  
                subprocess.call(["cp", "{0}init/{1}".format(project_config["source_dir"], data_source["config_file"]), "/data/" + machine_user + "/" + data_source_name +"/work/reports_config.json"])
                with open("{0}init/{1}".format(project_config["source_dir"], data_source["config_file"])) as data_config_file:
                    data_config_file_dict = json.loads(data_config_file.read())
                    logging.info("Scheduling up cron jobs now")
                    logging.info("Deleting /etc/cron.d/{0}_{1} if it exists".format(machine_user,data_source_name))
                    logging.debug("executing command rm -f /etc/cron.d/{0}_{1}".format(machine_user,data_source_name))
                    subprocess.call(["rm","-f","/etc/cron.d/{0}_{1}".format(machine_user,data_source_name)])
                    if not os.path.isfile("/etc/cron.allow") and not os.path.isfile("/etc/cron.deny"):
                        if "delete_n_days" in client:
                            logging.info("Creating log file for delete_n_days")
                            open("/data/" + machine_user + "/" + data_source_name + "/work/log/delete_n_days.log", 'a').close()
                            logging.info("/data/" + machine_user + "/" + data_source_name + "/work/log/delete_n_days.log created")
                        if os.path.isfile('/var/mail/{0}'.format(machine_user)):
                            subprocess.call(["mkdir", "-p", "/data/{0}/log".format(machine_user)])
                            logging.info("Creating log file for clear_mail_file")
                            open("/data/" + machine_user + "/log/clear_mail_file.log", 'a').close()
                            logging.info("/data/" + machine_user + "/log/clear_mail_file.log created")
                        port = 7889
                        for report in data_config_file_dict["reports"]: # YahooGemini and Zemanta specific spec as of now; let's see how this evolves
                            # logging.info("Creating log files for cron to output to")
                            # open("/data/" + machine_user + "/" + data_source_name + "/work/log/start_report_" + report["report"] + ".log", 'a').close()
                            # logging.info("/data/" + machine_user + "/" + data_source_name + "/work/log/start_report_" + report["report"] + ".log created")
                            logging.info("Creating filters_and_fields and history dirs")
                            logging.debug("executing command: mkdir -p /data/" + machine_user + "/" + data_source_name + "/work/filters_and_fields/{0}/history".format(report["report"]))
                            subprocess.call(["mkdir", "-p", "/data/{0}/{1}/work/filters_and_fields/{2}/history".format(machine_user, data_source_name, report["report"])])
                            logging.info("/data/" + machine_user + "/" + data_source_name + "/work/filters_and_fields/" + report["report"] + " created")
                            logging.info("/data/" + machine_user + "/" + data_source_name + "/work/filters_and_fields/" + report["report"] + "/history created")
                            logging.info("/data/" + machine_user + "/" + data_source_name + "/work/log/start_report_" + report["report"] + ".log created")
                            if data_destination["insert_to_db_req"]:
                                logging.info("Creating log file for insert_to_db to output to")
                                open("/data/" + machine_user + "/" + data_source_name + "/work/log/insert_to_db.log", 'a').close()
                                logging.info("/data/" + machine_user + "/" + data_source_name + "/work/log/insert_to_db.log created")
                                open("/data/" + machine_user + "/" + data_source_name + "/work/log/insert_to_db_spec.log", 'a').close()
                                logging.info("/data/" + machine_user + "/" + data_source_name + "/work/log/insert_to_db_spec.log created")
                            open("/data/" + machine_user + "/" + data_source_name + "/work/log/rm_completed.log", 'a').close()
                            logging.info("/data/" + machine_user + "/" + data_source_name + "/work/log/rm_completed.log created")
                            if "fields_file" in report:
                                logging.info("Saving a copy of fields file: {0} to the user's home directory")
                                logging.debug("executing command: cp {0}init/{1} {2}".format(project_config["source_dir"], report["fields_file"], "/data/" + machine_user + "/" + data_source_name +"/work/filters_and_fields/{0}/fields.json".format(report["report"])))   
                                subprocess.call(["cp", "{0}init/{1}".format(project_config["source_dir"], report["fields_file"]), "/data/" + machine_user + "/" + data_source_name +"/work/filters_and_fields/{0}/fields.json".format(report["report"])])
                            if data_destination["name"] in ["Redshift"]:
                                logging.info("Creating directory for aws: /data/{0}/.aws".format(machine_user))
                                logging.debug("Executing command: mkdir -p /data/{0}/.aws".format(machine_user))
                                subprocess.call(["mkdir", "-p", "/data/{0}/.aws".format(machine_user)])
                                logging.info("Saving aws credentials to: /data/{0}/.aws/credentials".format(machine_user))
                                with open("/data/{0}/.aws/credentials".format(machine_user), "w") as aws_creds_file:
                                    aws_creds_file.write("[default]\n")
                                    aws_creds_file.write("aws_access_key_id = {0}\n".format(data_destination["credentials"]["aws"]["access_key"]))
                                    aws_creds_file.write("aws_secret_access_key = {0}\n".format(data_destination["credentials"]["aws"]["secret_key"]))
                                logging.info("Saving aws location to: /data/{0}/.aws/config".format(machine_user))
                                with open("/data/{0}/.aws/config".format(machine_user), "w") as aws_config_file:
                                    aws_config_file.write("[default]\n")
                                    aws_config_file.write("region = {0}\n".format(data_destination["aws_location"]))
                                start_py_name = "start_{0}.py".format(data_destination["name"].lower()) 
                            elif "type" in report:
                                if report["type"] == "standard":
                                    start_py_name = "start_{0}.py".format(data_destination["name"].lower())
                                elif report["type"] == "custom":
                                    start_py_name = "start_spec_{0}.py".format(data_destination["name"].lower())
                            else:
                                start_py_name = "start_{0}.py".format(data_destination["name"].lower()) 
                            cron_file_write_string = ""
                            
                            if data_source_name == "FacebookAds" and False:
                                cron_file_write_string +=  "{0} {1} python3 {2}{3}/{4} --runtype=scheduled --report={5} --port={6}\n".format(report["cron_string"], machine_user, project_config["source_dir"], data_source_name, start_py_name, report["report"], port)
                                cron_file_write_string += "{0} {1} python3 {2}{3}/{4} --runtype=scheduled --report={5} --port={6}\n".format(report["cron_string"], machine_user, project_config["source_dir"], data_source_name, "generate_file_client.py", report["report"], port)
                                cron_file_write_string += "{0} {1} python3 {2}{3}/{4} --runtype=scheduled --report={5} --port={6}\n".format(report["cron_string"], machine_user, project_config["source_dir"], data_source_name, "poll_n_download.py", report["report"], port)
                            else:
                                cron_file_write_string +=  "{0} {1} python3 {2}{3}/{4} --runtype=scheduled --report={5}\n".format(report["cron_string"], machine_user, project_config["source_dir"], data_source_name, start_py_name, report["report"])
                            with open("/etc/cron.d/" + machine_user + "_" + data_source_name, "a") as cron_file:
                                cron_file.write(cron_file_write_string)
                            port += 1
                        with open("/etc/cron.d/{0}_{1}".format(machine_user, data_source_name), "a") as cron_file:
                            if ("async" in data_config_file_dict and data_config_file_dict["async"]) or not "async" in data_config_file_dict:
                                if data_destination["insert_to_db_req"]:
                                    if data_source_name not in ['Outbrain']:
                                        cron_file.write("*/5 * * * * " + machine_user + " python3 " + str(project_config["source_dir"]) + data_source_name + "/db/insert_to_db.py --runtype=scheduled\n")
                                        cron_file.write("*/5 * * * * " + machine_user + " python3 " + str(project_config["source_dir"]) + data_source_name + "/db/insert_to_db_spec.py --runtype=scheduled\n")
                                    else:
                                        cron_file.write("*/5 * * * * " + machine_user + " python3 " + str(project_config["source_dir"]) + "utils/insert_to_db.py --runtype=scheduled --data_source={data_source}\n".format(data_source=data_source_name))
                            if "delete_n_days" in client:
                                cron_file.write("0 0 * * * {0} python3 {1}init/delete_n_days.py --days={2} --datasource={3}\n".format(machine_user, project_config["source_dir"], client['delete_n_days'], data_source_name))
                            if "data_source_spec_config" in project_config and data_source_name in project_config["data_source_spec_config"]:
                                cron_file.write("*/{0} * * * * ".format(project_config["data_source_spec_config"][data_source_name]["token_refresh_frequency"]["value"]) + machine_user + " php -f" + str(project_config["source_dir"]) + data_source_name + "/tokenizer/generate.php {0} {1} {2}\n".format(data_config_file_dict["client_ID"], data_config_file_dict["client_secret"], data_config_file_dict["refresh_token"]))
                            # checking if email is setup
                            if os.path.isfile('/var/mail/{0}'.format(machine_user)):
                                cron_file.write('0 * * * * {machine_user} sh {project_source}utils/clear_mail_file.sh {machine_user} >> /data/{machine_user}/log/clear_mail_file.log\n'.format(machine_user=machine_user, data_source_name=data_source_name, project_source=project_config["source_dir"]))
                    else:
                        logging.warning("/etc/cron.allow and/or /etc/cron.deny file exists; handler for this is still being developed, thank you for your patience. Exiting!")
            """
            if data_source_name == "GoogleAds":
                logging.info("Setting up googleads.yaml file")      
                googleads_yaml_text = "adwords:\n"
                googleads_yaml_text += "\tdeveloper_token: {0}\n".format(data_config_file_dict["developer_token"])
                googleads_yaml_text += "\tclient_id: {0}\n".format(data_config_file_dict["client_id"])
                googleads_yaml_text += "\tclient_secret: {0}\n".format(data_config_file_dict["client_secret"])
            """
        logging.info("Changing owner of created dirs recursively")
        logging.debug("executing command: chown -R {0}:{0} /data/{0}".format(machine_user))
        subprocess.call(["chown", "-R", "{0}:{0}".format(machine_user), "/data/" + machine_user])

    # logging.info("============================")


logging.info("Completed")
logging.info("total time: " + str(int(time.time() - started_timestamp)) + " seconds")
# logging.info("========================================================")