# foo.py

#!/usr/bin/env python
#
# Copyright 2016 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""This example downloads an adgroup performance report for all child accounts.

To get report fields, run get_report_fields.py.

The LoadFromStorage method is pulling credentials and properties from a
"googleads.yaml" file. By default, it looks for this file in your home
directory. For more information, see the "Caching authentication information"
section of our README.

"""

import logging
import multiprocessing
from queue import Empty
import os
import sys
import csv
import time
import json
import googleads
import subprocess
sys.path.append(os.path.abspath(os.path.join(__file__,'..', '..')))
from utils import insert_to_db_mssql
# logging.basicConfig(level=logging.INFO)
# logging.getLogger('suds.transport').setLevel(logging.DEBUG)

# Timeout between retries in seconds.
BACKOFF_FACTOR = 5
# Maximum number of processes to spawn.
MAX_PROCESSES = multiprocessing.cpu_count()
# Maximum number of retries for 500 errors.
MAX_RETRIES = 5
# Maximum number of items to be sent in a single API response.
PAGE_SIZE = 100
# Directory to download the reports to.
# REPORT_DOWNLOAD_DIRECTORY = 'INSERT_REPORT_DOWNLOAD_DIRECTORY'


def main(client, report_download_directory, account_ids_lst, report_definition, **kwargs):
  # print(kwargs)
  # exit()
  data_destination = None if 'data_destination' not in kwargs else kwargs['data_destination']
  # Determine list of customer IDs to retrieve report for.
  input_queue = multiprocessing.Queue()
  for _ in account_ids_lst:
    input_queue.put(_)
  # input_queue = GetCustomerIDs(client)
  reports_succeeded = multiprocessing.Queue()
  reports_failed = multiprocessing.Queue()
  status_dict = {
    'success':[],
    'failure':[],
    'fields_super_lst':[],
  }
  # Create report definition.
  # report_definition = {
  #     'reportName': 'CAMPAIGN_PERFORMANCE_REPORT',
  #     'dateRangeType': 'LAST_7_DAYS',
  #     'reportType': 'CAMPAIGN_PERFORMANCE_REPORT',
  #     'downloadFormat': 'CSV',
  #     'selector': {
  #         'fields': ['CampaignId', 'Impressions', 'Clicks',
  #                    'Cost'],
  #     },
  # }

  queue_size = input_queue.qsize()
  num_processes = min(queue_size, MAX_PROCESSES)
  logging.info('Retrieving {0} reports with {1} processes:'.format(queue_size, num_processes))
  # if data_destination is not None and data_destination == 'mssql':
  #   from utils import insert_to_db_mssql
  # Start all the processes.
  processes = [ReportWorker(client, report_download_directory,
                            report_definition, input_queue, reports_succeeded,
                            reports_failed, dates=kwargs['dates'], report=kwargs['report'], s3_obj=None if 's3_obj' not in kwargs else kwargs['s3_obj'], report_run_activity_id=None if 'report_run_activity_id' not in kwargs else kwargs['report_run_activity_id'], log2db_obj=None if 'log2db_obj' not in kwargs else kwargs['log2db_obj'], table_prefix=None if 'table_prefix' not in kwargs else kwargs['table_prefix'], data_destination=data_destination)
               for _ in range(num_processes)]

  for process in processes:
    process.start()

  for process in processes:
    process.join()

  logging.info('Finished downloading reports with the following results:')
  while True:
    try:
      success = reports_succeeded.get(timeout=0.01)
      status_dict['success'].append(success)

    except Empty:
      break
    logging.info('\tReport for CustomerId "{0}" succeeded.'.format(success['customerId']))

  while True:
    try:
      failure = reports_failed.get(timeout=0.01)
      status_dict['failure'].append(failure)
    except Empty:
      break
    logging.info('\tReport for CustomerId "{0}" failed with error code "{1}" and '
           'message: {2}.'.format(failure['customerId'], failure['code'],
                             failure['message']))
  if 'fields_super_lst' in status_dict['success'][0]:
    status_dict['fields_super_lst'] = status_dict['success'][0]['fields_super_lst']
  return status_dict


class ReportWorker(multiprocessing.Process):
  """A worker Process used to download reports for a set of customer IDs."""

  _FILENAME_TEMPLATE = '%s_account_id_%d_from_%s_to_%s_%d.csv'
  _FILEPATH_TEMPLATE = '%s/%s'

  def __init__(self, client, report_download_directory, report_definition,
               input_queue, success_queue, failure_queue, **kwargs):
    """Initializes a ReportWorker.

    Args:
      client: An AdWordsClient instance.
      report_download_directory: A string indicating the directory where you
        would like to download the reports.
      report_definition: A dict containing the report definition that you would
        like to run against all customer IDs in the input_queue.
      input_queue: A Queue instance containing all of the customer IDs that
        the report_definition will be run against.
      success_queue: A Queue instance that the details of successful report
        downloads will be saved to.
      failure_queue: A Queue instance that the details of failed report
        downloads will be saved to.
    """
    super(ReportWorker, self).__init__()
    self.report_downloader = client.GetReportDownloader(version='v201802')
    self.report_download_directory = report_download_directory
    self.report_definition = report_definition
    self.input_queue = input_queue
    self.success_queue = success_queue
    self.failure_queue = failure_queue
    self.dates = kwargs['dates']
    self.report = kwargs['report']
    self.s3_obj = kwargs['s3_obj'] if 's3_obj' in kwargs else None
    self.log2db_obj = kwargs['log2db_obj'] if 'log2db_obj' in kwargs else None
    self.table_prefix = kwargs['table_prefix'] if 'table_prefix' in kwargs else None
    self.data_destination = kwargs['data_destination'] if 'data_destination' in kwargs else None
    # print(self.data_destination)
    # exit()
    self.report_run_activity_id = kwargs['report_run_activity_id'] if 'report_run_activity_id' in kwargs else None
    self.fields_super_lst = None

  def _DownloadReport(self, customer_id):
    filepath = self._FILEPATH_TEMPLATE % (self.report_download_directory,
                                          self._FILENAME_TEMPLATE % (self.report, customer_id, self.dates['from'], self.dates['to'], int(time.time())))
    retry_count = 0

    while True:
      logging.info('[{0}/{1}] Loading report for customer ID "{2}" into "{3}"...'.format(self.ident, retry_count, customer_id, filepath))
      try:
        with open(filepath, 'wb') as handler:
          self.report_downloader.DownloadReport(
              self.report_definition, output=handler,
              client_customer_id=customer_id, skip_report_header=True, skip_report_summary=True)
        TransformDlFiles(filepath, customer_id, self.log2db_obj, self.report_run_activity_id)
        return_this = {'customerId': customer_id}
        if self.fields_super_lst is None:
          self.fields_super_lst = subprocess.check_output(["head", "-n", "1", filepath]).decode("utf8").strip('\n').strip('\r').split(',')
        if len(subprocess.check_output(["head", "-n", "2", filepath]).decode("utf8").split("\n")) > 2:
          # file contains data other than headers, 
          if self.s3_obj is not None:
            # let's upload it to s3
            self.s3_obj.upload(filepath, 'GoogleAds', self.report, 'becker-datachannel')
            return_this['fileName'] = filepath
          if self.data_destination is not None and self.data_destination == 'mssql':
            downloaded_filepath = filepath.replace('processing', 'downloaded')
            os.rename(filepath, downloaded_filepath)
            db = insert_to_db_mssql.load_conn()
            insert_to_db_mssql.load('GoogleAds', downloaded_filepath.split('/')[-1], self.report_run_activity_id, self.log2db_obj, self.table_prefix + 'tmp_', db)
          return_this['fields_super_lst'] = self.fields_super_lst
        # print(return_this)
        if os.path.isfile(filepath):
          os.remove(filepath)
        return (True, return_this)
      except googleads.errors.AdWordsReportError as e:
        if e.code == 500 and retry_count < MAX_RETRIES:
          time.sleep(retry_count * BACKOFF_FACTOR)
        else:
          logging.info('Report failed for customer ID "{0}" with code "{1}" after "{2}" retries.'.format(customer_id, e.code, retry_count+1))
          return (False, {'customerId': customer_id, 'code': e.code,
                          'message': e.message})
      except Exception as e:
        logging.info('Report failed for customer ID "{0}".'.format(customer_id))
        logging.info('e: {0}'.format(e.__class__))
        return (False, {'customerId': customer_id, 'code': None,
                        'message': e.message})

  def run(self):
    while True:
      try:
        customer_id = self.input_queue.get(timeout=0.01)
      except Empty:
        break
      result = self._DownloadReport(customer_id)
      (self.success_queue if result[0] else self.failure_queue).put(result[1])


def GetCustomerIDs(client):
  """Retrieves all CustomerIds in the account hierarchy.

  Note that your configuration file must specify a client_customer_id belonging
  to an AdWords manager account.

  Args:
    client: an AdWordsClient instance.

  Raises:
    Exception: if no CustomerIds could be found.

  Returns:
    A Queue instance containing all CustomerIds in the account hierarchy.
  """
  # For this example, we will use ManagedCustomerService to get all IDs in
  # hierarchy that do not belong to MCC accounts.
  managed_customer_service = client.GetService('ManagedCustomerService',
                                               version='v201802')

  offset = 0

  # Get the account hierarchy for this account.
  selector = {'fields': ['CustomerId'],
              'predicates': [{
                  'field': 'CanManageClients',
                  'operator': 'EQUALS',
                  'values': [False]
              }],
              'paging': {
                  'startIndex': str(offset),
                  'numberResults': str(PAGE_SIZE)}}

  # Using Queue to balance load between processes.
  queue = multiprocessing.Queue()
  lst = []
  more_pages = True

  while more_pages:
    page = managed_customer_service.get(selector)

    if page and 'entries' in page and page['entries']:
      for entry in page['entries']:
        queue.put(entry['customerId'])
        lst.append({'id': entry['customerId']})
    else:
      raise Exception('Can\'t retrieve any customer ID.')
    offset += PAGE_SIZE
    selector['paging']['startIndex'] = str(offset)
    more_pages = offset < int(page['totalNumEntries'])
  # logging.info(json.dumps(lst, indent=2))
  return queue

def TransformDlFiles(file_name, account_id, log2db_obj, report_run_activity_id):
  source_file = file_name
  destination_file = '/'.join(file_name.split('/')[:-1]) + '/tmp_transform_' + file_name.split('/')[-1]
  csvReader = csv.reader(open(source_file))
  csvWriter = csv.writer(open(destination_file, 'w'))
  ctr = 0
  for row in csvReader:
    ctr += 1
    if ctr == 1:
      csvWriter.writerow(row + ['account_id'])
    else:
      csvWriter.writerow(row + [account_id])
  log2db_obj.log2report_run_activity_file_details(report_run_activity_id=report_run_activity_id, file_name=source_file, file_size=os.path.getsize(source_file))
  os.rename(destination_file, source_file)

if __name__ == '__main__':
  adwords_client = googleads.adwords.AdWordsClient.LoadFromStorage('/home/becker/GoogleAds/auth/googleads.yaml')
  main(adwords_client, '/home/becker/GoogleAds/data/processing')
