# start_redshift.py

"""
use google-adwords library for most of the heavy lifting

"""

import os
import sys
import time
import json
import glob
import logging
import argparse
import datetime
import traceback
import subprocess
from multiprocessing import Process
utils_path = os.path.abspath(os.path.join(__file__,'..', '..'))
sys.path.append(utils_path)
from utils import mailer
import fetch_save_upload
from googleads import adwords
from utils import insert_to_db_mssql

started_timestamp = time.time()


parser = argparse.ArgumentParser(description='Get report as per passed args')
parser.add_argument('--report', help='Report to be fetched.')
parser.add_argument('--loglevel', default='DEBUG' ,help='will be set to DEBUG if not explicitly passed.')
parser.add_argument('--runtype', default='manual' ,help='will be set to "manual" if not explicitly passed.')
parser.add_argument('--machine', default=subprocess.check_output(['uname','-a']).decode("utf-8").strip("\n") ,help='will be set to output of Linux command "uname -a" if not explicitly passed.')
args = parser.parse_args()


# get current logged in user
current_user = subprocess.check_output(["whoami"]).decode("utf-8").strip("\n")

data_source_name = 'GoogleAds'

# set logging
from utils import log2filestdout
loglevel = args.loglevel

log2filestdout.init(loglevel, path='/home/{0}/{1}/work/log/start_{2}.log'.format(current_user, data_source_name, args.report))

if os.path.isfile("/home/{current_user}/{data_source_name}/start_{report}.lock".format(current_user=current_user, data_source_name=data_source_name, report=args.report)):
    logging.info(".lock file exists, exiting")
    exit()

logging.info("Start!")
logging.info("Writing .lock file")
open("/home/{current_user}/{data_source_name}/start_{report}.lock".format(current_user=current_user, data_source_name=data_source_name, report=args.report), 'a').close()
from utils import log2db_mssql

log2db_obj = log2db_mssql.Log2DB(data_source_name=data_source_name, machine_name=args.machine, run_type=args.runtype)

if log2db_obj.db is None:
    logging.critical("Connection to logging database could not be established, exiting!")
    exit()


from utils import project_config

from utils import user_config
user_config.load(current_user)


data_destination = [ _ for _ in user_config.user_config["data_destination"] if _["active"] ][0]
conn_string = """dbname={0} host={1} port={2} user={3} password={4} 
                    connect_timeout=300""".format(
    data_destination["db_conn_db"], 
    data_destination["db_conn_host"],
    data_destination["db_conn_port"], 
    data_destination["db_conn_user"], 
    data_destination["db_conn_pass"],
)

from utils import reports_config
reports_config.load(current_user, data_source_name)          
from utils import header_to_db_row
header_to_db_row_dict = header_to_db_row._map(project_config.project_config["source_dir"] + data_source_name + "/db/header_to_db_row_map.json")
# print(json.dumps(header_to_db_row_dict[args.report], indent=2))
# exit()
# print(json.dumps(reports_config.reports_config, indent=2))
# exit()
report_config = [ _ for _ in reports_config.reports_config["reports"] if _["report"]== args.report][0]

report_run_id = log2db_obj.log2report_run(report_id=report_config['report_id'])

# print(json.dumps(reports_config, indent=2))
# exit()
logging.info("deleting stale files from /downloaded dir")
for f in glob.glob("/home/{0}/{1}/data/downloaded/{2}*.txt".format(
    current_user, 
    data_source_name, 
    args.report)):
    os.remove(f)


adwords_client = adwords.AdWordsClient.LoadFromStorage('/home/{0}/{1}/auth/googleads.yaml'.format(current_user, data_source_name))

report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=report_run_id, activity='start fetching files for all account ids in config file and processing them')

account_ids_lst = []

for account_id in report_config["filters"]["ids"]:
    account_ids_lst.append(account_id['id'])

# setting up dates
dates = {}
dates['from'] = str((datetime.date.today() - datetime.timedelta(report_config["frequency"]["value"])).strftime('%Y%m%d'))
dates['to'] = str((datetime.date.today()).strftime('%Y%m%d'))

logging.info('calling fetch_save_upload with account_ids_lst')
status_dict = fetch_save_upload.main(adwords_client, '/home/{0}/{1}/data/processing'.format(current_user, data_source_name, ),  account_ids_lst, {
      'reportName': args.report,
      # 'dateRangeType': 'LAST_30_DAYS',
      'dateRangeType': 'CUSTOM_DATE',
      'reportType': args.report,
      'downloadFormat': 'CSV',
      'selector': {
          'fields': [_['field'] for _ in report_config['fields'] ],
          'dateRange': {'min': dates['from'], 'max': dates['to']},
      },
  }, dates=dates, report=args.report, data_destination='mssql', report_run_activity_id=report_run_activity_id, log2db_obj=log2db_obj, table_prefix=reports_config.reports_config['table_prefix'])

err_str = ""
for failed in status_dict['failure']:
    err_str += 'Could not load data for report: {report} for customerId: {customer_id} and dates: {_from} to {to} with code: {code} and message: {msg}\n'.format(report=args.report, customer_id=failed['customerId'], _from=dates['from'], to=dates['to'], code=failed['code'], msg=failed['message'])
# send email
if err_str !='':
    logging.error(err_str)
    try:
        mailer.send(body=err_str, author=project_config.project_config['email']['error']['from'], to=project_config.project_config['email']['error']['to'], subject='Failed (Main thread): {0}'.format(args.report))
    except FileNotFoundError as e:
        logging.error(str(e))
        if "No such file or directory: '/usr/sbin/sendmail'" in str(e):
            logging.error('sendmail not configured')
    except:
        logging.error('unable to send email')

logging.info('files downloaded and loaded to _tmp table')
logging.info('deepcopy from _tmp table to table')

source_table = data_destination["db_conn_db"] + '.' + data_destination["db_conn_schema"] + '.[' + reports_config.reports_config['table_prefix'] + 'tmp_' + args.report.lower() + ']'
destination_table = data_destination["db_conn_db"] + '.' + data_destination["db_conn_schema"] + '.[' + reports_config.reports_config['table_prefix'] + args.report.lower() + ']'
col_str = ','.join([header_to_db_row_dict[args.report]['fields'][col]['db_column'] for col in header_to_db_row_dict[args.report]['fields']])

deepcopy_success = insert_to_db_mssql.deep_copy(source_table, destination_table, col_str, data_source_name, log2db_obj, report_run_activity_id)
if deepcopy_success:
    report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=report_run_id, activity='completed deepcopy successfully')
else:
    report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=report_run_id, activity='deepcopy failed')

report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=report_run_id, activity='complete fetching files for all account ids in config file and processing them')

logging.info('rming .lock file')
os.remove("/home/{current_user}/{data_source_name}/start_{report}.lock".format(current_user=current_user, data_source_name=data_source_name, report=args.report))
logging.info("Completed")
logging.info("total time: " + str(int(time.time() - started_timestamp)) + " seconds")
