# get_fbp_fields.py
import json

sql_insert = ""
fields_dct = {}
with open('fbp_in.txt') as in_file:
	for line in in_file.readlines():
		line = line.strip('\n')
		field = line.split(',')[0]
		if field not in fields_dct:
			fields_dct[field] = ''
		periods = line.split(',')[2:]
		if 'lifetime' in periods:
			print(field + '\tlifetime')
			fields_dct[field] += 'lifetime,'
			sql_insert += "INSERT INTO report_form_fields( display_name, datasource_id, report_id, field_id, field_type, field_name, tooltip_description, placeholder_text, csv_header_name, db_column_name, data_type, csv_sequence, sort_key, dist_key, created_at, updated_at, is_request, is_db, db_data_size, db_data_type, is_visible) VALUES( '{0}', 14, 145, 0, 'metric', '{0}', '', '', '{0}', '{0}', 'numeric', NULL, 0, 0, NULL, NULL, 1, 1, '11', 'integer', 1);\n".format(field)
		if 'days_28' in periods:
			print(field + '\tdays_28')
			fields_dct[field] += 'days_28,'
			# sql_insert += "INSERT INTO report_form_fields( display_name, datasource_id, report_id, field_id, field_type, field_name, tooltip_description, placeholder_text, csv_header_name, db_column_name, data_type, csv_sequence, sort_key, dist_key, created_at, updated_at, is_request, is_db, db_data_size, db_data_type, is_visible) VALUES( '{0}', 14, 144, 0, 'metric', '{0}', '', '', '{0}', '{0}', 'numeric', NULL, 0, 0, NULL, NULL, 1, 1, '11', 'integer', 1);\n".format(field)
		if 'day' in periods:
			print(field + '\tday')
			# sql_insert += "INSERT INTO report_form_fields( display_name, datasource_id, report_id, field_id, field_type, field_name, tooltip_description, placeholder_text, csv_header_name, db_column_name, data_type, csv_sequence, sort_key, dist_key, created_at, updated_at, is_request, is_db, db_data_size, db_data_type, is_visible) VALUES( '{0}', 14, 140, 0, 'metric', '{0}', '', '', '{0}', '{0}', 'numeric', NULL, 0, 0, NULL, NULL, 1, 1, '11', 'integer', 1);\n".format(field)
			fields_dct[field] += 'day,'
		if 'week' in periods:
			print(field + '\tweek')
			fields_dct[field] += 'week,'
			# sql_insert += "INSERT INTO report_form_fields( display_name, datasource_id, report_id, field_id, field_type, field_name, tooltip_description, placeholder_text, csv_header_name, db_column_name, data_type, csv_sequence, sort_key, dist_key, created_at, updated_at, is_request, is_db, db_data_size, db_data_type, is_visible) VALUES( '{0}', 14, 143, 0, 'metric', '{0}', '', '', '{0}', '{0}', 'numeric', NULL, 0, 0, NULL, NULL, 1, 1, '11', 'integer', 1);\n".format(field)

print(json.dumps(fields_dct, indent=2))
print(sql_insert)