# user_config.py

import json

user_config = None

def load(current_user):
    global user_config
    with open("/home/{0}/user_config.json".format(current_user)) as user_config_json:
        user_config = json.loads(user_config_json.read())