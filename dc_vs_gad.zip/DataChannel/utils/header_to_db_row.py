# header_to_db_row.py
import json

header_to_db_row_dict = {}

def _map(map_json_path):
	with open(map_json_path) as header_to_db_row_map_file:
	        header_to_db_row_map = json.loads(header_to_db_row_map_file.read())


	for report in header_to_db_row_map:
	    if not report["report"] in header_to_db_row_dict:
	        header_to_db_row_dict[report["report"]] = {
	        	"fields":{}, 
	        	"null_as":report["null_as"],
	        	
	        }
	       	if "create_table_script" in report:
	       		header_to_db_row_dict[report["report"]]["create_table_script"] = report["create_table_script"]
	    for field in report["fields"]:
	        header_to_db_row_dict[report["report"]]["fields"][field["csv_header"]] = {"db_column": field["db_column"]}
	        if "data_type" in field:
	            header_to_db_row_dict[report["report"]]["fields"][field["csv_header"]]["data_type"] = field["data_type"]

	return header_to_db_row_dict