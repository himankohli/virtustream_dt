# project_config.py

import os
import json

project_config = {}

filepath = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "project_config.json"))
with open(filepath) as project_config_json:
	    project_config = json.loads(project_config_json.read())