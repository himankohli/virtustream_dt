# reports_json.py

import json

reports_config = None

def load(current_user, data_source_name):
	global reports_config
	with open("/home/{0}/{1}/work/reports_config.json".format(current_user, data_source_name)) as reports_json_file:
		reports_config = json.loads(reports_json_file.read())