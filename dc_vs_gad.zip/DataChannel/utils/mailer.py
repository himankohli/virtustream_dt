# mailer.py

import logging
import traceback
from email.mime.text import MIMEText
from subprocess import Popen, PIPE

def send(**kwargs):
	msg = MIMEText(kwargs['body'])
	if 'from' in kwargs:
		msg["From"] = kwargs['author']
	msg["To"] = kwargs['to']
	if 'subject' in kwargs:
		msg["Subject"] = kwargs['subject']

	p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
	try:
		p.communicate(msg.as_bytes())
	except:
		logging.error('error: {0}'.format(traceback.format_exc()))
		return False
	return True