# insert_to_db_mssql.py

import os
import csv
import sys
import time
import math
import json
import base64
import pyodbc
import logging
import requests
import argparse
import datetime
import traceback
import subprocess


from utils import load_config

# current_user = None

def load(data_source, filename, report_run_activity_id, log2db_obj, table_prefix, db):
    global header_to_db_row_map, header_to_db_row_dict, report_meta, db_conn_schema, db_conn_db, current_user
    file = filename
    cursor = db.cursor() # cursor

    logging.info("Moving file in processing directory")
    os.rename("/home/{0}/{1}/data/downloaded/{2}".format(current_user, data_source, file) , "/home/{0}/{1}/data/processing/{2}".format(current_user, data_source, file))

    if report_meta is None:
        report_meta = load_config.load(project_config["source_dir"] + data_source + "/db/report_meta.json")

    if header_to_db_row_map is None:
        logging.info("Setting headers mapping")
        header_to_db_row_map = load_config.load(project_config["source_dir"] + data_source + "/db/header_to_db_row_map.json")
        for report in header_to_db_row_map:
            if not report["report"] in header_to_db_row_dict:
                header_to_db_row_dict[report["report"]] = {"fields":{}}
            for field in report["fields"]:
                header_to_db_row_dict[report["report"]]["fields"][field["csv_header"]] = {"db_column": field["db_column"]}
                if "data_type" in field:
                    header_to_db_row_dict[report["report"]]["fields"][field["csv_header"]]["data_type"] = field["data_type"]
    
    base_filter = report_meta['base_filter']
    csv_separator = report_meta['csv_separator']
    delete_filters = report_meta['delete_filters']
    report_name = file.split("_{0}_".format(base_filter))[0]
    report_details = [ _ for _ in header_to_db_row_map if _["report"] == report_name][0]
    table_name = db_conn_db + '.' + db_conn_schema + '.[' + table_prefix + report_details['report'].lower() + ']'
    delete_query = "DELETE FROM {0} where ".format(table_name)
    select_query = "SELECT count(*) FROM {0} where ".format(table_name)

    for param in delete_filters:
        # if 'data_type' in param and param['data_type'] in ['integer', 'numeric']:
        delete_query = delete_query + "[{0}] {1} '{2}' AND ".format(param["db_column"], param["operator"], file.split("_{0}_".format(param["file_param_name"]))[1].split("_")[0])
        select_query = select_query + "[{0}] {1} '{2}' AND ".format(param["db_column"], param["operator"], file.split("_{0}_".format(param["file_param_name"]))[1].split("_")[0])
    delete_query = delete_query.rstrip(" AND ")
    select_query = select_query.rstrip(" AND ")

    row_count = 0
    limit = 10000
    try:
        logging.info(select_query)
        cursor.execute(select_query)
        row_count = cursor.fetchone()[0]
    except:
        logging.error("Unable to select!")
        logging.error("Closing cursor object")
        cursor.close()
        logging.error("Exception: {0}\n".format(str(traceback.format_exc())))
        logging.info("breaking out")
        logging.info("moving error file to data/error")
        os.rename("/home/{0}/{1}/data/processing/{2}".format(current_user, data_source, file) , "/home/{0}/{1}/data/error/{2}".format(current_user, data_source, file))
        return None
        # break
    logging.info("COUNT of rows in db matching SELECT: {0}".format(row_count))
    
    if row_count > 0:
        n_delete = math.ceil(row_count / limit)
        for x in range(n_delete):
            sql = "{0};".format(delete_query)
            sql = sql.replace("DELETE FROM ", "DELETE TOP({0}) FROM ".format(limit))
            try:
                logging.info(sql)
                cursor.execute(sql)
                db.commit()
                # log2db_obj.log2report_run_activity_db_details(report_run_activity_id=report_run_activity_id, operation_type='DELETE', num_rows_affected=cursor.rowcount)
            except:
                logging.error("Unable to delete!")
                logging.error("Closing cursor object")
                cursor.close()
                logging.error("Exception: {0}\n".format(str(traceback.format_exc())))
                logging.error("breaking out")
                logging.info("moving error file to data/error")
                os.rename("/home/{0}/{1}/data/processing/{2}".format(current_user, data_source, file) , "/home/{0}/{1}/data/error/{2}".format(current_user, data_source, file))
                log2db_obj.log2report_run_activity_errors(report_run_activity_id=report_run_activity_id, error_code=None, error_description="Exception while DELETE: {msg}".format(msg=traceback.format_exc()))
                return None
    file_path = "/home/{0}/{1}/data/processing/{2}".format(current_user, data_source, file)
    logging.info("generate col_str by reading first line of file")
    col_str = subprocess.check_output(["head", "-n", "1", file_path]).decode("utf8").replace("\n","")
    logging.debug("col_str: {0}".format(col_str))

    db_cols = []
    # print(header_to_db_row_dict[report_name])
    # exit()
    db_columns = ",".join([header_to_db_row_dict[report_name]['fields'][column.strip(' ')]['db_column'] for column in col_str.replace("\n","").replace("\r","").split(csv_separator)])
    csv_row_count = 0
    with open(file_path) as csv_file:
        try:
            csv_reader = csv.reader(csv_file)
        except:
            logging.error("Exception while reading csv: {0}".format(str(traceback.format_exc())))
            logging.info("mving file to error dir")
            os.rename(file_path, "/home/{0}/{1}/data/error/{2}".format(current_user, data_source, file))
            return None

        ctr_ = -1
        sql = "INSERT INTO {0} ({1}) VALUES ".format(table_name ,db_columns)

        for line in csv_reader:
            ctr_ += 1
            if ctr_ > 0:
                sql_values = ""
                for i,col_name in enumerate(col_str.replace("\n","").replace("\r","").split(csv_separator)):
                    sql_value = line[i]
                    col_data_type = header_to_db_row_dict[report_name]['fields'][col_name.strip(' ')]['data_type'] if 'data_type' in header_to_db_row_dict[report_name]['fields'][col_name.strip(' ')] else 'string'
                    if sql_value == "" or (col_data_type in ['integer', 'numeric'] and sql_value.lower() == 'null') or sql_value == ' --':
                        sql_value = "NULL"
                        sql_values += "{0},".format(sql_value)
                        continue
                    if col_data_type == 'date':
                        sql_value = datetime.datetime.strptime(sql_value, '%m/%d/%Y').strftime("%Y-%m-%d")
                    if col_data_type not in ['numeric', 'integer']:
                        sql_values += "'{0}',".format(sql_value.replace("'","''"))
                    else:
                        sql_values += "{0},".format(sql_value.replace("'","''"))
                sql += "({0}),".format(sql_values[:-1])

                if ctr_ % 1000 == 0:
                    # print(sql)
                    # exit()
                    try:
                        logging.debug("processing batch, insert statements: {0}".format(ctr_))
                        sql = sql.strip(",") + ";"
                        # logging.info(sql)
                        cursor.execute(sql)
                        db.commit()
                        # log2db_obj.log2report_run_activity_db_details(report_run_activity_id=report_run_activity_id, operation_type='INSERT', num_rows_affected=cursor.rowcount)
                    except:
                        logging.error("exception while insert")
                        logging.error("sql: {0}".format(sql))
                        logging.critical("Exception: {0}".format(str(traceback.format_exc())))
                        logging.info("Moving file to error folder")
                        os.rename(file_path, "/home/{0}/{1}/data/error/{2}".format(current_user, data_source, file))
                        log2db_obj.log2report_run_activity_errors(report_run_activity_id=report_run_activity_id, error_code=None, error_description="Exception while INSERT: {msg}".format(msg=traceback.format_exc()))
                        return None
                    sql = "INSERT INTO {0} ({1}) VALUES ".format(table_name ,db_columns)
                    # sql = "INSERT INTO {0} ({1}) VALUES ".format(report_details["table_name"],db_columns)


        sql = sql.strip(",") + ";"
        if "VALUES ;" not in sql: # empty query
            try:
                logging.debug("processing batch, insert statements: {0}".format(ctr_))
                cursor.execute(sql)
                db.commit()
                # log2db_obj.log2report_run_activity_db_details(report_run_activity_id=report_run_activity_id, operation_type='INSERT', num_rows_affected=cursor.rowcount)
            except:
                logging.error("exception while insert")
                logging.error("sql: {0}".format(sql))
                logging.critical("Exception: {0}".format(str(traceback.format_exc())))
                # logging.info("Deleting .lock file")
                # subprocess.call(["rm","-f","/home/{0}/{1}/insert_to_db.lock".format(current_user, data_source_name)])
                logging.info("Moving file to error folder")
                os.rename(file_path, "/home/{0}/{1}/data/error/{2}".format(current_user, data_source, file))
                log2db_obj.log2report_run_activity_errors(report_run_activity_id=report_run_activity_id, error_code=None, error_description="Exception while INSERT: {msg}".format(msg=traceback.format_exc()))
                return None
    logging.info('rming file from local filesystem')
    os.remove(file_path)


def load_conn():
    global current_user, report_meta, project_config, user_config, header_to_db_row_map, header_to_db_row_dict, db_conn_db, db_conn_schema, db_conn_host, db_conn_user, db_conn_pass
    current_user = subprocess.check_output(["whoami"]).decode("utf-8").strip("\n")

    project_config = load_config.load(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "project_config.json")))
    user_config = load_config.load("/home/{0}/user_config.json".format(current_user))

    # load db conn params
    for data_destination in user_config["data_destination"]:
        if data_destination["active"]:
            db_conn_schema = data_destination["db_conn_schema"]
            db_conn_host = data_destination["db_conn_host"]
            db_conn_user = data_destination["db_conn_user"]
            db_conn_pass = data_destination["db_conn_pass"]
            db_conn_db = data_destination["db_conn_db"]
            break


    # init vars
    main_config_dict = None
    header_to_db_row_map = None
    header_to_db_row_dict = {}
    report_meta = None

    logging.info("Current logged in user is: {0}".format(current_user))
    logging.info("establishing connection to database")
    try:
        # db = MySQLdb.connect(db_conn_host, db_conn_user, db_conn_pass, db_conn_db, use_unicode=True, charset="utf8")
        db = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_conn_host+';DATABASE='+db_conn_db+';UID='+db_conn_user+';PWD='+ db_conn_pass, timeout=10)
        return db
        # cursor = db.cursor() # cursor
    except:
        logging.warning("unable to connect to database!")
        logging.error("Exception: {0}\n".format(str(traceback.format_exc())))
        logging.warning("exiting!")
        # logging.info("Deleting .lock file")
        # subprocess.call(["rm","-f","/home/" + current_user + "/" + data_source_name + "/insert_to_db.lock"])
        exit()


def deep_copy(source_table, destination_table, col_str, data_source, log2db_obj, report_run_activity_id):
    # start transaction
    # delete from destination_table
    # copy from source_table to destination_table
    # delete from source_table
    # end transaction

    project_config = load_config.load(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "project_config.json")))
    report_meta = load_config.load(project_config["source_dir"] + data_source + "/db/report_meta.json")
    # print(report_meta)
    # return True
    delete_filters = report_meta['delete_filters']

    db = load_conn()
    cursor = db.cursor()

    delete_sql = 'DELETE FROM {0} WHERE '.format(destination_table, source_table)

    for param in delete_filters:
        delete_sql = delete_sql + "[{db_column}] IN (SELECT DISTINCT {db_column} FROM {source}) AND ".format(db_column=param["db_column"], source=source_table)
    
    delete_sql = delete_sql.rstrip(" AND ")

    try:
        logging.debug(delete_sql)
        cursor.execute(delete_sql)
        logging.info("{rows} rows deleted!".format(rows=cursor.rowcount))
        log2db_obj.log2report_run_activity_db_details(report_run_activity_id=report_run_activity_id, operation_type='DELETE', num_rows_affected=cursor.rowcount)
    except:
        logging.error("Unable to delete!")
        logging.error("Closing cursor object")
        cursor.close()
        logging.error("Exception: {0}\n".format(str(traceback.format_exc())))
        logging.error("breaking out")
        logging.error("rolling back")
        db.rollback()
        return False

    copy_sql = 'INSERT INTO {0} ({2}) SELECT {2} FROM {1}'.format(destination_table, source_table, col_str)
    try:
        logging.debug(copy_sql)
        cursor.execute(copy_sql)
        logging.info("{rows} rows inserted!".format(rows=cursor.rowcount))
        log2db_obj.log2report_run_activity_db_details(report_run_activity_id=report_run_activity_id, operation_type='INSERT', num_rows_affected=cursor.rowcount)
    except:
        logging.error("Unable to copy!")
        logging.error("Closing cursor object")
        cursor.close()
        logging.error("Exception: {0}\n".format(str(traceback.format_exc())))
        logging.error("breaking out")
        logging.error("rolling back")
        db.rollback()
        return False
    
    delete_sql = 'DELETE FROM {0}'.format(source_table)
    try:
        logging.debug(delete_sql)
        cursor.execute(delete_sql)
        logging.info("{rows} rows deleted!".format(rows=cursor.rowcount))
    except:
        logging.error("Unable to delete!")
        logging.error("Closing cursor object")
        cursor.close()
        logging.error("Exception: {0}\n".format(str(traceback.format_exc())))
        logging.error("breaking out")
        logging.error("rolling back")
        db.rollback()
        return False
    
    db.commit()

    return True