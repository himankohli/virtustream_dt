# start_mssql.py

# initialize object according to report and start downloading files
    # authenticate whenever required
# call insert_to_db

import os
import sys
import time
import json
import glob
import boto3
import logging
import botocore
import argparse
import datetime
import psycopg2
import traceback
import subprocess
import psycopg2.extras
from multiprocessing import Process
utils_path = os.path.abspath(os.path.join(__file__,'..', '..'))
sys.path.append(utils_path)
from utils import mailer
from utils import insert_to_db_mssql
from utils import log2filestdout
from utils import log2db_mssql
from utils import load_config
from lib import base
from auth import auth


if __name__ == '__main__':

    started_timestamp = time.time()

    parser = argparse.ArgumentParser(description='Get report as per passed args')
    parser.add_argument('--report', help='Report to be fetched.')
    parser.add_argument('--loglevel', default='DEBUG' ,help='will default to "DEBUG" if not explicitly passed.')
    parser.add_argument('--runtype', default='manual' ,help='will default to "manual" if not explicitly passed.')
    parser.add_argument('--machine', default=subprocess.check_output(['hostname']).decode("utf-8").strip("\n") ,help='will default to output of Linux command "hostname" if not explicitly passed.')
    args = parser.parse_args()


    # get current logged in user
    current_user = subprocess.check_output(["whoami"]).decode("utf-8").strip("\n")

    data_source_name = 'SalesForcePardot'

    # set logging
    
    loglevel = args.loglevel

    log2filestdout.init(loglevel, path='/data/{0}/{1}/work/log/start_{2}.log'.format(current_user, data_source_name, args.report), maxBytes=1024*1024*5)

    log2db_obj = log2db_mssql.Log2DB(data_source_name=data_source_name, machine_name=args.machine, run_type=args.runtype)

    if log2db_obj.db is None:
        logging.critical("Connection to logging database could not be established, exiting!")
        exit()

    project_config = load_config.load(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "project_config.json")))
    
    if os.path.isfile("/data/{current_user}/{data_source_name}/start_{report}.lock".format(current_user=current_user, data_source_name=data_source_name, report=args.report)):
        logging.info(".lock file exists")
        # kill processgroup from state file
        state_data = None
        with open('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report)) as state_file_obj:
            state_data = json.loads(state_file_obj.read())
        output = ''
        try:
            output = subprocess.check_output(['kill', '-9', '-{0}'.format(state_data['group_pid'])]).decode("utf-8").strip("\n")
        except:
            logging.error('err while killing process group: {0}'.format(traceback.format_exc()))
        if 'report_run_id' in state_data:
            report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=state_data['report_run_id'], activity='run truncated')
            log2db_obj.log2report_run_activity_errors(report_run_activity_id=report_run_activity_id, error_code=None, error_description='run truncated')
        if 'start_deletion' in state_data and 'complete_deletion' not in state_data:
            report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=state_data['report_run_id'], activity='start_deletion exists but complete_deletion does not')
            log2db_obj.log2report_run_activity_errors(report_run_activity_id=report_run_activity_id, error_code=None, error_description='start_deletion exists but complete_deletion does not')
        logging.info('output: {0}'.format(output))
        # rm partially downloaded files in processing dir
        logging.info("rm partially downloaded files in /processing dir")
        for f in glob.glob("/data/{0}/{1}/data/processing/{2}*.txt".format(
            current_user, 
            data_source_name, 
            args.report)):
            os.remove(f)
        # rm lock file
        logging.info('rming .lock file')
        os.remove("/data/{current_user}/{data_source_name}/start_{report}.lock".format(current_user=current_user, data_source_name=data_source_name, report=args.report))
        # log as error
        err_str = 'report_run_id not found in state file'
        if 'report_run_id' in state_data:
            err_str = 'failed reports for report_run_id: {0}'.format(state_data['report_run_id'])
            logging.error(err_str)
        if err_str != '':
            # send email
            try:
                mailer.send(body=err_str, author=project_config['email']['error']['from'], to=project_config['email']['error']['to'], subject='Failed (Main thread): {0}'.format(args.report))
            except FileNotFoundError as e:
                logging.error(str(e))
                if "No such file or directory: '/usr/sbin/sendmail'" in str(e):
                    logging.error('sendmail not configured')
            except:
                logging.error(str(traceback.format_exc()))
                logging.error('unable to send email')
    logging.info("Start!")
    logging.info("Writing .lock file")
    open("/data/{current_user}/{data_source_name}/start_{report}.lock".format(current_user=current_user, data_source_name=data_source_name, report=args.report), 'a').close()
    
    
    
    reports_config  = load_config.load("/data/{0}/{1}/work/reports_config.json".format(current_user, data_source_name))
    report_config = [_ for _ in reports_config["reports"] if _["report"] == args.report][0]
    user_config  = load_config.load("/data/{0}/user_config.json".format(current_user))
    
    data_destination = [ _ for _ in user_config["data_destination"] if _["active"] ][0]

    report_run_id = log2db_obj.log2report_run(report_id=report_config['report_id'])

    report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=report_run_id, activity='begin request')
    
    state_data = {}
    if report_config['method'] == 'query':
        last_run_time = '1970-01-01 00:00:00'
        if os.path.isfile('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report)):
                    
            logging.info('reading last_run_time from state.json')
            with open('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report)) as state_file_obj:
                state_data = json.loads(state_file_obj.read())
                last_run_time = state_data['last_run_time']
            logging.info('writing prev_run_time to state.json')
            with open('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report), 'w') as state_file_obj:
                state_data['prev_run_time'] = last_run_time
                # print('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report))
                # print(json.dumps(state_data, indent=2))
                state_file_obj.write(json.dumps(state_data, indent=2))
        if report_config['delete_or_append'] == 'delete':
            last_run_time = '1970-01-01 00:00:00'
    # exit()
    os.setpgrp()
    state_data['group_pid'] = os.getpgrp()
    state_data['report_run_id'] = int(report_run_id)
    state_data['main_thread_pid'] = os.getpid()
    
    with open('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report), 'w') as state_file_obj:
        state_file_obj.write(json.dumps(state_data, indent=2))

    logging.info('truncate tmp_{0}{1}'.format(reports_config['table_prefix'], args.report))
    insert_to_db_mssql.delete_table(data_destination['db_conn_db'], data_destination['db_conn_schema'], 'tmp_{0}{1}'.format(reports_config['table_prefix'], args.report))
    logging.debug('init base class')
    base_obj = base.PardotBase(
        db_name=data_destination['db_conn_db'],
        schema=data_destination['db_conn_schema'],
        )
    max_tries = 3
    try_ctr = 0
    request_success = False
    num_rows_deleted = 0

    while try_ctr < max_tries and request_success is False:
        logging.info('trying {0} of {1}'.format(try_ctr+1, max_tries))
        if report_config['method'] == 'query':
            try:
                id_greater_than_value = 0
                fresh_data = False
                while True:
                    logging.info('fetching records greater than id_greater_than_value: {0}'.format(id_greater_than_value))
                    response = None
                    auth_ = False
                    try:
                        response = base_obj.query(
                                token=auth.get_token(
                                    current_user=current_user, 
                                    data_source_name=data_source_name,
                                    format_='json',
                                    email=report_config['email'],
                                    password=report_config['password'],
                                    user_key=report_config['user_key'],
                                    ),
                                user_key=report_config['user_key'],
                                object=report_config['object'],
                                sort_by=report_config['sort_by_key'],
                                filter_key=report_config['filter_key'],
                                filter_key_value=last_run_time,
                                id_greater_than_value=id_greater_than_value,
                                )    
                    except ValueError as e:
                        if str(e) == 'auth failed':
                            auth_ = True
                            logging.error('auth failed')
                            logging.info('regenerating api_key')
                            auth.gen_token(
                                format_='json',
                                current_user=current_user,
                                data_source_name=data_source_name,
                                email=report_config['email'],
                                password=report_config['password'],
                                user_key=report_config['user_key'],
                                )
                        elif str(e) == 'daily rate limit met':
                            logging.error('daily rate limit met')
                            break
                            
                    except:
                        logging.error('err while querying object in while True')
                        logging.error('err: {0}'.format(traceback.format_exc()))
                        break
                    if response is not None:
                        fresh_data = True
                        # print(json.dumps(response, indent=2))
                        # print(json.dumps(response))
                        # continue
                        logging.info('getting distinct_ids')
                        distinct_ids = base_obj.distinct_ids(data=response[report_config['result_key']])
                        logging.info('deleting distinct_ids from table')
                        
                        num_rows_deleted += base_obj.delete_distinct_ids(
                            distinct_ids=distinct_ids,
                            table=reports_config['table_prefix'] + args.report,
                            db_name=data_destination['db_conn_db'],
                            del_col='id',
                            schema_name=data_destination['db_conn_schema'],
                            data_destination=data_destination['name'],
                            )
                        # print('num_rows_deleted')
                        # print(num_rows_deleted)
                        base_obj.save_to_table(
                            data=response,
                            result_key=report_config['result_key'],
                            fields_lst=report_config['fields'],
                            db_name=data_destination['db_conn_db'],
                            schema_name=data_destination['db_conn_schema'],
                            table='tmp_' + reports_config['table_prefix'] + args.report,
                            # nested_objects=report_config['nested_objects'] if nested_objects in report_config else None
                            )
                        # calc max id in result
                        id_greater_than_value = insert_to_db_mssql.get_max_table(data_destination['db_conn_db'], data_destination['db_conn_schema'], 'tmp_{0}{1}'.format(reports_config['table_prefix'], args.report), report_config['sort_by_key'])
                    elif auth_:
                        logging.info('retrying last request with fresh api_key')
                    else:
                        logging.info('end of data reached, breaking out')
                        break
                request_success = True
            except ValueError as e:
                if str(e) == 'auth failed':
                    logging.error('auth failed')
                    logging.info('regenerating api_key')
                    auth.gen_token(
                        format_='json',
                        current_user=current_user,
                        data_source_name=data_source_name,
                        email=report_config['email'],
                        password=report_config['password'],
                        user_key=report_config['user_key'],
                        )
                elif str(e) == 'daily rate limit met':
                    logging.error('daily rate limit met')
                    break
            except:
                logging.error('err while querying object')
                logging.error('err: {0}'.format(traceback.format_exc()))
        elif report_config['method'] == 'stats':
            try:
                fresh_data = False
                logging.info('fetching {filter_id_col} from {ref_report} table'.format(
                    filter_id_col=report_config['filter_id_col'], 
                    ref_report=report_config['ref_report']
                    ))
                ref_state_data = None
                with open('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, report_config['ref_report'])) as state_file_obj:
                    ref_state_data = json.loads(state_file_obj.read())
                # print(ref_state_data)
                # exit()
                filters = base_obj.fetch_filters(
                    filter_id_col=report_config['filter_id_col'], 
                    table=reports_config['table_prefix'] + report_config['ref_report'],
                    state_data=ref_state_data
                    )
                # print(filters)
                # exit()
                for list_email in filters:
                    if list_email is not None:
                        logging.info('fetching stats for list_email_id: {0}'.format(list_email['id']))
                        response = None
                        auth_ = False
                        try:
                            response = base_obj.stats(
                                    token=auth.get_token(
                                        current_user=current_user, 
                                        data_source_name=data_source_name,
                                        format_='json',
                                        email=report_config['email'],
                                        password=report_config['password'],
                                        user_key=report_config['user_key'],
                                        ),
                                    user_key=report_config['user_key'],
                                    object=report_config['object'],
                                    id=list_email['id'],
                                    result_key=report_config['result_key'],
                                    )    
                        except ValueError as e:
                            if str(e) == 'auth failed':
                                auth_ = True
                                logging.error('auth failed')
                                logging.info('regenerating api_key')
                                auth.gen_token(
                                    format_='json',
                                    current_user=current_user,
                                    data_source_name=data_source_name,
                                    email=report_config['email'],
                                    password=report_config['password'],
                                    user_key=report_config['user_key'],
                                    )
                            elif str(e) == 'daily rate limit met':
                                logging.error('daily rate limit met')
                                break
                        except:
                            logging.error('err while querying object in while True')
                            logging.error('err: {0}'.format(traceback.format_exc()))
                            break
                        # print(json.dumps(response, indent=2))
                        if response is not None:
                            if 'err' in response:
                                logging.error(response['err'])
                            else:
                                fresh_data = True
                                for field in report_config['fields']:
                                    if 'post_fetch' in field and field['post_fetch']:
                                        response[report_config['result_key']][field['field']] = list_email['id']

                                # print(response)
                                # continue
                                
                                logging.info('getting distinct_ids')
                                distinct_ids = base_obj.distinct_ids(data=response[report_config['result_key']])
                                logging.info('deleting distinct_ids from table')
                                num_rows_deleted = base_obj.delete_distinct_ids(
                                    distinct_ids=distinct_ids,
                                    table=reports_config['table_prefix'] + args.report,
                                    del_col='list_email_id',
                                    db_name=data_destination['db_conn_db'],
                                    data_destination=data_destination['name'],
                                    schema_name=data_destination['db_conn_schema'],
                                    )
                                base_obj.save_to_table(
                                    data=response,
                                    result_key=report_config['result_key'],
                                    fields_lst=report_config['fields'],
                                    db_name=data_destination['db_conn_db'],
                                    method=report_config['method'],
                                    schema_name=data_destination['db_conn_schema'],
                                    table='tmp_' + reports_config['table_prefix'] + args.report,
                                    )
                        elif auth_:
                            logging.info('retrying last request with fresh api_key')
                        else:
                            logging.info('end of data reached, breaking out')
                            break
                request_success = True
            except ValueError as e:
                if str(e) == 'auth failed':
                    logging.error('auth failed')
                    logging.info('regenerating api_key')
                    auth.gen_token(
                        format_='json',
                        current_user=current_user,
                        data_source_name=data_source_name,
                        email=report_config['email'],
                        password=report_config['password'],
                        user_key=report_config['user_key'],
                        )
                elif str(e) == 'daily rate limit met':
                    logging.error('daily rate limit met')
                    # break
            except:
                logging.error('err while querying object')
                logging.error('err: {0}'.format(traceback.format_exc()))
        try_ctr += 1
    
    
    if fresh_data:
        logging.info('data loaded to tmp table')
        logging.info('running deepcopy now')
        report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=report_run_id, activity='running deepcopy')
        deepcopy_status = insert_to_db_mssql.deep_copy(
                'tmp_' + reports_config['table_prefix'] + args.report, 
                reports_config['table_prefix'] + args.report, 
                ','.join(_['field'] for _ in report_config['fields']),
                data_source_name,
                report_config['delete_or_append'],
                )
        # print('deepcopy_status')
        # print(deepcopy_status)
        if 'n_insert' in deepcopy_status:
            log2db_obj.log2report_run_activity_db_details(report_run_activity_id=report_run_activity_id, operation_type='INSERT', num_rows_affected=deepcopy_status['n_insert'])

        # if 'n_delete' in deepcopy_status:
        #     num_rows_deleted += deepcopy_status['n_delete']
        
        log2db_obj.log2report_run_activity_db_details(report_run_activity_id=report_run_activity_id, operation_type='DELETE', num_rows_affected=num_rows_deleted)


    report_run_activity_id = log2db_obj.log2report_run_activity(report_run_id=report_run_id, activity='run complete')

    logging.info('updating last_run_time to state.json file')
    state_data = None
    with open('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report)) as state_file_obj:
        state_data = json.loads(state_file_obj.read())
    with open('/data/{0}/{1}/work/filters_and_fields/{2}/state.json'.format(current_user, data_source_name, args.report), 'w') as state_file_obj:
        state_data['last_run_time'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        state_file_obj.write(json.dumps(state_data, indent=2))
    # 'last_run_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    logging.info('rming .lock file')
    os.remove("/data/{current_user}/{data_source_name}/start_{report}.lock".format(current_user=current_user, data_source_name=data_source_name, report=args.report))
    logging.info("Completed")
    logging.info("total time: " + str(int(time.time() - started_timestamp)) + " seconds")   