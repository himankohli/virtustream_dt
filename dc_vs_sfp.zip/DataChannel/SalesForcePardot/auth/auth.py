# auth.py

import os
import json
import logging
import requests

api_endpoint = 'https://pi.pardot.com/api/login/version/{api_version}'

def gen_token(**kwargs):
	payload = {
	'email': kwargs['email'],
	'password': kwargs['password'],
	'user_key': kwargs['user_key'],
	'format': kwargs['format_'],
	}
	try:
		response = requests.post(api_endpoint.replace('{api_version}', '3'), data=payload)
	except:
		logging.error('err while requesting the api_endpoint')
		logging.error('err: {0}'.format(traceback.format_exc()))
		return None

	try:
		response_json = response.json()
	except json.decoder.JSONDecodeError as e:
		logging.error('json.decoder.JSONDecodeError')
		logging.error('msg: {0}'.format(e))
	except:
		logging.error('err while parsing response to json')
		logging.error('err: {0}'.format(traceback.format_exc()))
	if 'err' in response_json:
		logging.error('gen_token failed on server')
		return None
	if 'api_key' in response_json:
		token = response_json['api_key']
		save_token(
			token=token, 
			current_user=kwargs['current_user'],
			data_source_name=kwargs['data_source_name'],
			)
		return token
	else:
		logging.error('api_key not in response_json')
		return None
	

def get_token(**kwargs):
	if not os.path.isfile('/data/{current_user}/{data_source_name}/auth/token.json'.format(current_user=kwargs['current_user'], data_source_name=kwargs['data_source_name'])):
		gen_token(
			format_='json',
            current_user=kwargs['current_user'],
            data_source_name=kwargs['data_source_name'],
            email=kwargs['email'],
            password=kwargs['password'],
            user_key=kwargs['user_key'],
            )
	with open('/data/{current_user}/{data_source_name}/auth/token.json'.format(current_user=kwargs['current_user'], data_source_name=kwargs['data_source_name'])) as token_file:
		return json.loads(token_file.read())['api_key']	

def save_token(**kwargs):
	with open('/data/{current_user}/{data_source_name}/auth/token.json'.format(current_user=kwargs['current_user'], data_source_name=kwargs['data_source_name']), 'w') as token_file:
		token_file.write(json.dumps({'api_key': kwargs['token']}))