# base.py

import os
import sys
import auth
import json
import logging
import requests
import traceback
utils_path = os.path.abspath(os.path.join(__file__,'..', '..'))
sys.path.append(utils_path)
from utils import insert_to_db_mssql
from utils import insert_to_db_redshift

class PardotBase:

	api_endpoint = 'https://pi.pardot.com/api/{object}/version/{api_version}/do/{method}'

	# db_name = None
	def __init__(self, **kwargs):
		self.db_name = kwargs['db_name']
		self.schema = kwargs['schema']

	def query(self, **kwargs):
		payload = {
		'user_key': kwargs['user_key'],
		'format': 'json',
		'api_key': kwargs['token'],
		'output': 'bulk',
		'sort_order': 'ascending',
		'sort_by': kwargs['sort_by'],
		'id_greater_than': kwargs['id_greater_than_value'],
		kwargs['filter_key']: kwargs['filter_key_value']
		}
		# print(payload)
		try:
			response = requests.post(self.api_endpoint.replace('{object}', kwargs['object']).replace('{api_version}', '3').replace('{method}', 'query'), data=payload)
		except:
			logging.error('err while requesting the api_endpoint')
			logging.error('err: {0}'.format(traceback.format_exc()))
			return None
		try:
			response_json = response.json()
		except json.decoder.JSONDecodeError as e:
			logging.error('json.decoder.JSONDecodeError')
			logging.error('msg: {0}'.format(e))
			logging.error(response.text)
			raise
		except:
			logging.error('err while parsing response to json')
			logging.error('err: {0}'.format(traceback.format_exc()))
		
		if 'err' in response_json:
			if response_json['err'] == 'Invalid API key or user key':
				logging.error('auth failed')
				raise ValueError('auth failed')
			elif response_json['err'] == 'Daily API rate limit met':
				logging.error('daily rate limit met')
				raise ValueError('daily rate limit met')
		# print(response_json)
		return self.flatten_dict(response=response_json['result'])

	def save_to_file(self, **kwargs):
		data = kwargs['data']
		if ('method' in kwargs and kwargs['method'] == 'stats') or type(data[kwargs['result_key']]) == dict:
			tmp = {}
			tmp[kwargs['result_key']] = []
			tmp[kwargs['result_key']].append(data[kwargs['result_key']])
			data = tmp
		for row in data[kwargs['result_key']]:
			with open(kwargs['file_name'], 'a') as file_obj:
				file_obj.write(json.dumps(row) + '\n')
				

	def save_to_table(self, **kwargs):
		data = kwargs['data']
		col_str = ','.join(_['field'] for _ in kwargs['fields_lst'])
		insert_sql = "INSERT INTO {db}.{schema}.{table} ({col_str}) VALUES ".format(
			table=kwargs['table'],
			col_str=col_str,
			db=kwargs['db_name'],
			schema=kwargs['schema_name'],
			)
		values_str = ''
		if ('method' in kwargs and kwargs['method'] == 'stats') or type(data[kwargs['result_key']]) == dict:
			tmp = {}
			tmp[kwargs['result_key']] = []
			tmp[kwargs['result_key']].append(data[kwargs['result_key']])
			data = tmp
		for row in data[kwargs['result_key']]:
			values_str += '('
			for field in kwargs['fields_lst']:
				# print('row')
				# print(row)
				# print("field['field']")
				# print(field['field'])
				# print('{0}: {1}'.format(field['field'], row[field['field']]))
				if field['field'] in row and row[field['field']] is not None:
					# print(field['field'])
					# print(row[field['field']])
					clean_val = "'{0}'".format(str(row[field['field']]).replace("'","''")) if field['data_type'] == 'string' else row[field['field']]
				else:
					clean_val = 'NULL'
				values_str += "{0}, ".format(clean_val)
			values_str = values_str.strip(', ')
			values_str += '), '
		values_str = values_str.strip(', ')
		insert_sql = insert_sql + values_str + ';'
		insert_to_db_mssql.insert_table(insert_sql)

	def stats(self, **kwargs):
		payload = {
		'user_key': kwargs['user_key'],
		'format': 'json',
		'api_key': kwargs['token'],
		'output': 'bulk',
		}
		
		api_endpoint = self.api_endpoint.format(
			object=kwargs['object'],
			api_version='3',
			method='stats',
			) + '/id/{0}'.format(kwargs['id'])
		
		try:
			response = requests.post(api_endpoint, data=payload)
		except:
			logging.error('err while requesting the api_endpoint')
			logging.error('err: {0}'.format(traceback.format_exc()))
			return None
		try:
			response_json = response.json()
		except json.decoder.JSONDecodeError as e:
			logging.error('json.decoder.JSONDecodeError')
			logging.error('msg: {0}'.format(e))
			logging.error(response.text)
			raise
		except:
			logging.error('err while parsing response to json')
			logging.error('err: {0}'.format(traceback.format_exc()))
		
		if 'err' in response_json:
			if response_json['err'] == 'Invalid API key or user key':
				print('auth failed')
				raise ValueError('auth failed')
		# print(response_json)
		# return response_json[kwargs['result_key']]
		return response_json

	
	def flatten_dict(self, **kwargs):
		response = kwargs['response']
		if response is None:
			return None
		tmp = None
		for result_key in response:
			if type(response[result_key]) == dict:
				tmp = {}
				tmp_row = {}
				for key in response[result_key]:
					if type(response[result_key][key]) == dict:
						for inner_dict_key in response[result_key][key]:
							if inner_dict_key == 'value':
								tmp[key] = response[result_key][key][inner_dict_key]
							else:
								tmp[key + '_' + inner_dict_key] = response[result_key][key][inner_dict_key]		
					else:
						tmp[key] = response[result_key][key]
			elif type(response[result_key]) == list:
				tmp = []
				for row in response[result_key]:
					tmp_row = {}
					for key in row:
						if type(row[key]) == dict:
							for inner_dict_key in row[key]:
								if inner_dict_key == 'value':
									tmp_row[key] = row[key][inner_dict_key]
								elif type(row[key][inner_dict_key]) == dict:
									for inner_dict_key_1 in row[key][inner_dict_key]:
										tmp_row[key + '_' + inner_dict_key + '_' + inner_dict_key_1] = row[key][inner_dict_key][inner_dict_key_1]
								else:
									tmp_row[key + '_' + inner_dict_key] = row[key][inner_dict_key]		
						else:
							tmp_row[key] = row[key]
					tmp.append(tmp_row)
		return {result_key:tmp}



	def fetch_filters(self, **kwargs):
		filters = insert_to_db_mssql.fetch_filters(
			filter_id_col=kwargs['filter_id_col'], 
            table=kwargs['table'],
            db_name=self.db_name,
            schema=self.schema,
            d=kwargs['state_data']['prev_run_time'],
            d1=kwargs['state_data']['last_run_time'],
            )
		return_this = []

		for filter_ in filters:
			tmp_obj = {'id': filter_[0]}
			return_this.append(tmp_obj)

		return return_this


	def distinct_ids(self, **kwargs):
		distinct_ids = []
		if type(kwargs['data']) is dict:
			field = 'list_email_id' if 'list_email_id' in kwargs['data'] else 'id'
			if kwargs['data'][field] not in distinct_ids:
				distinct_ids.append(kwargs['data'][field])
		elif type(kwargs['data']) is list:
			for row in kwargs['data']:
				if row['id'] not in distinct_ids:
					distinct_ids.append(row['id'])
		return distinct_ids

	
	def delete_distinct_ids(self, **kwargs):
		
		num_rows_affected = None

		delete_sql = "DELETE FROM {db}.{schema}.{table} WHERE {del_col} IN ({distinct_ids_str}) ;".format(
			table=kwargs['table'],
			distinct_ids_str=','.join([str(_) for _ in kwargs['distinct_ids']]),
			db=kwargs['db_name'],
			schema=kwargs['schema_name'],
			del_col=kwargs['del_col'],
			)
		if kwargs['data_destination'].lower() == 'mssql':
			num_rows_affected = insert_to_db_mssql.delete_table(
				kwargs['table'],
				kwargs['schema_name'],
				kwargs['table'],
				delete_sql,
				)
		elif kwargs['data_destination'] == 'redshift':
			pass
		else:
			logging.critical('data_destination: {data_destination} not supported yet!'.format(data_destination=kwargs['data_destination']))

		return num_rows_affected