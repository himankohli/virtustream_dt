-- create_table.sql

IF OBJECT_ID('pardot.dbo.sfp_Campaign', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_Campaign;

CREATE TABLE pardot.dbo.sfp_Campaign
(
   row_id      bigint identity   NOT NULL,
   cost        bigint,
   name        varchar(300),
   ts_created  datetime2         DEFAULT (getdate()),
   id          bigint
);

ALTER TABLE pardot.dbo.sfp_Campaign
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_Campaign TO dbo;

COMMIT;

IF OBJECT_ID('pardot.dbo.sfp_Form', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_Form;

CREATE TABLE pardot.dbo.sfp_Form
(
   row_id         bigint identity   NOT NULL,
   id             bigint,
   campaign_id    bigint,
   name           varchar(200),
   campaign_name  varchar(200),
   embedCode      varchar(200),
   created_at     datetime2,
   updated_at     datetime2,
   ts_created     datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_Form
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_Form TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_Prospect', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_Prospect;

CREATE TABLE pardot.dbo.sfp_Prospect
(
   row_id               int identity    NOT NULL,
   id                   int,
   campaign_id          int,
   user_id              int,
   salutation           varchar(1000),
   first_name           varchar(1000),
   last_name            varchar(1000),
   email                varchar(200),
   password             varchar(200),
   company              varchar(200),
   website              varchar(200),
   job_title            varchar(200),
   department           varchar(200),
   country              varchar(200),
   address_one          varchar(200),
   address_two          varchar(200),
   city                 varchar(200),
   state                varchar(200),
   territory            varchar(200),
   zip                  varchar(200),
   phone                varchar(200),
   fax                  varchar(200),
   source               varchar(200),
   annual_revenue       varchar(200),
   employees            varchar(200),
   industry             varchar(200),
   years_in_business    varchar(200),
   comments             varchar(200),
   notes                varchar(200),
   grade                varchar(200),
   recent_interaction   varchar(200),
   crm_lead_fid         varchar(200),
   crm_contact_fid      varchar(200),
   crm_owner_fid        varchar(200),
   crm_url              varchar(200),
   crm_account_fid      varchar(200),
   prospect_account_id  bigint,
   score                bigint,
   last_activity_at     datetime2,
   created_at           datetime2,
   updated_at           datetime2,
   crm_last_sync        datetime2,
   is_do_not_email      bit,
   is_do_not_call       bit,
   opted_out            bit,
   is_reviewed          bit,
   is_starred           bit,
   campaign_name        varchar(200),
   ts_created           datetime2       DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_Prospect
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_Prospect TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_Visitor', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_Visitor;

CREATE TABLE pardot.dbo.sfp_Visitor
(
   row_id              bigint identity   NOT NULL,
   id                  bigint,
   page_view_count     bigint,
   ip_address          varchar(200),
   hostname            varchar(200),
   campaign_parameter  varchar(200),
   medium_parameter    varchar(200),
   source_parameter    varchar(200),
   content_parameter   varchar(200),
   term_parameter      varchar(200),
   created_at          datetime2,
   updated_at          datetime2,
   ts_created          datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_Visitor
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_Visitor TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_emailStats', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_emailStats;

CREATE TABLE pardot.dbo.sfp_emailStats
(
   row_id                     bigint identity   NOT NULL,
   sent                       bigint,
   delivered                  bigint,
   unique_clicks              bigint,
   soft_bounced               bigint,
   hard_bounced               bigint,
   opt_outs                   bigint,
   spam_complaints            bigint,
   opens                      bigint,
   unique_opens               bigint,
   delivery_rate              varchar(10),
   opens_rate                 varchar(10),
   click_through_rate         varchar(10),
   unique_click_through_rate  varchar(10),
   opt_out_rate               varchar(10),
   spam_complaint_rate        varchar(10),
   ts_created                 datetime2         DEFAULT (getdate()),
   list_email_id              bigint,
   total_clicks               bigint,
   click_open_ratio           varchar(10)
);

ALTER TABLE pardot.dbo.sfp_emailStats
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_emailStats TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_lifecycleHistory', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_lifecycleHistory;

CREATE TABLE pardot.dbo.sfp_lifecycleHistory
(
   row_id             bigint identity   NOT NULL,
   id                 bigint,
   prospect_id        bigint,
   previous_stage_id  bigint,
   next_stage_id      bigint,
   seconds_elapsed    bigint,
   created_at         datetime2,
   ts_created         datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_lifecycleHistory
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_lifecycleHistory TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_lifecycleStage', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_lifecycleStage;

CREATE TABLE pardot.dbo.sfp_lifecycleStage
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   position    bigint,
   name        varchar(300),
   is_locked   bit,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_lifecycleStage
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_lifecycleStage TO dbo;

COMMIT;

IF OBJECT_ID('pardot.dbo.sfp_list', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_list;

CREATE TABLE pardot.dbo.sfp_list
(
   row_id          bigint identity   NOT NULL,
   id              bigint,
   name            varchar(300),
   title           varchar(300),
   description     varchar(300),
   is_public       bit,
   is_dynamic      bit,
   is_crm_visible  bit,
   created_at      datetime2,
   updated_at      datetime2,
   ts_created      datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_list
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_list TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_listMembership', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_listMembership;

CREATE TABLE pardot.dbo.sfp_listMembership
(
   row_id       bigint identity   NOT NULL,
   id           bigint,
   list_id      bigint,
   prospect_id  bigint,
   opted_out    bit,
   created_at   datetime2,
   updated_at   datetime2,
   ts_created   datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_listMembership
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_listMembership TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_prospectAccount', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_prospectAccount;

CREATE TABLE pardot.dbo.sfp_prospectAccount
(
   row_id                       bigint identity   NOT NULL,
   assigned_to_user_id          bigint,
   campaign_id                  bigint,
   campaign_name                varchar(200),
   assigned_to_user_email       varchar(200),
   billing_country              varchar(200),
   billing_address_two          varchar(200),
   shipping_zip                 varchar(200),
   description                  ntext,
   billing_zip                  varchar(200),
   website                      varchar(200),
   billing_state                varchar(200),
   assigned_to_user_account     varchar(200),
   type                         varchar(200),
   billing_city                 varchar(200),
   phone                        varchar(200),
   shipping_address_two         varchar(200),
   assigned_to_user_role        varchar(200),
   billing_address_one          varchar(200),
   shipping_address_one         varchar(200),
   shipping_state               varchar(200),
   ownership                    varchar(200),
   assigned_to_user_job_title   varchar(200),
   employees                    varchar(200),
   name                         varchar(200),
   industry                     varchar(200),
   annual_revenue               varchar(200),
   Customer_Account_Code        varchar(200),
   fax                          varchar(200),
   assigned_to_user_updated_at  varchar(200),
   shipping_country             varchar(200),
   rating                       varchar(200),
   assigned_to_user_last_name   varchar(200),
   ticker_symbol                varchar(200),
   number                       varchar(200),
   assigned_to_user_first_name  varchar(200),
   shipping_city                varchar(200),
   site                         varchar(200),
   sic                          varchar(200),
   id                           bigint,
   assigned_to_user_created_at  datetime2,
   created_at                   datetime2,
   updated_at                   datetime2,
   ts_created                   datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_prospectAccount
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_prospectAccount TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_tag', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_tag;

CREATE TABLE pardot.dbo.sfp_tag
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   name        varchar(200),
   created_at  datetime2,
   updated_at  datetime2,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_tag
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_tag TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_tagObject', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_tagObject;

CREATE TABLE pardot.dbo.sfp_tagObject
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   tag_id      bigint,
   object_id   bigint,
   type        varchar(200),
   created_at  datetime2,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_tagObject
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_tagObject TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_user', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_user;

CREATE TABLE pardot.dbo.sfp_user
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   account     bigint,
   email       varchar(200),
   first_name  varchar(200),
   last_name   varchar(200),
   job_title   varchar(200),
   role        varchar(200),
   created_at  datetime2,
   updated_at  datetime2,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.sfp_user
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_user TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.sfp_visitorActivity', 'U') IS NOT NULL DROP TABLE pardot.dbo.sfp_visitorActivity;

CREATE TABLE pardot.dbo.sfp_visitorActivity
(
   row_id                          bigint identity   NOT NULL,
   id                              bigint,
   visitor_id                      bigint,
   prospect_id                     bigint,
   type                            bigint,
   type_name                       varchar(100),
   details                         varchar(500),
   created_at                      datetime,
   ts_created                      datetime2         DEFAULT (getdate()),
   email_id                        bigint,
   email_template_id               bigint,
   list_email_id                   bigint,
   form_id                         bigint,
   form_handler_id                 bigint,
   site_search_query_id            bigint,
   landing_page_id                 bigint,
   paid_search_id_id               bigint,
   multivariate_test_variation_id  bigint,
   visitor_page_view_id            bigint,
   file_id                         bigint,
   campaign_id                     bigint
);

ALTER TABLE pardot.dbo.sfp_visitorActivity
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.sfp_visitorActivity TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_Campaign', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_Campaign;

CREATE TABLE pardot.dbo.tmp_sfp_Campaign
(
   row_id      bigint identity   NOT NULL,
   cost        bigint,
   name        varchar(300),
   ts_created  datetime2         DEFAULT (getdate()),
   id          bigint
);

ALTER TABLE pardot.dbo.tmp_sfp_Campaign
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_Campaign TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_Form', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_Form;

CREATE TABLE pardot.dbo.tmp_sfp_Form
(
   row_id         bigint identity   NOT NULL,
   id             bigint,
   campaign_id    bigint,
   name           varchar(200),
   campaign_name  varchar(200),
   embedCode      varchar(200),
   created_at     datetime2,
   updated_at     datetime2,
   ts_created     datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_Form
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_Form TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_Prospect', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_Prospect;

CREATE TABLE pardot.dbo.tmp_sfp_Prospect
(
   row_id               int identity    NOT NULL,
   id                   int,
   campaign_id          int,
   user_id              int,
   salutation           varchar(1000),
   first_name           varchar(1000),
   last_name            varchar(1000),
   email                varchar(200),
   password             varchar(200),
   company              varchar(200),
   website              varchar(200),
   job_title            varchar(200),
   department           varchar(200),
   country              varchar(200),
   address_one          varchar(200),
   address_two          varchar(200),
   city                 varchar(200),
   state                varchar(200),
   territory            varchar(200),
   zip                  varchar(200),
   phone                varchar(200),
   fax                  varchar(200),
   source               varchar(200),
   annual_revenue       varchar(200),
   employees            varchar(200),
   industry             varchar(200),
   years_in_business    varchar(200),
   comments             varchar(200),
   notes                varchar(200),
   grade                varchar(200),
   recent_interaction   varchar(200),
   crm_lead_fid         varchar(200),
   crm_contact_fid      varchar(200),
   crm_owner_fid        varchar(200),
   crm_url              varchar(200),
   crm_account_fid      varchar(200),
   prospect_account_id  bigint,
   score                bigint,
   last_activity_at     datetime2,
   created_at           datetime2,
   updated_at           datetime2,
   crm_last_sync        datetime2,
   is_do_not_email      bit,
   is_do_not_call       bit,
   opted_out            bit,
   is_reviewed          bit,
   is_starred           bit,
   campaign_name        varchar(200),
   ts_created           datetime2       DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_Prospect
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_Prospect TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_Visitor', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_Visitor;

CREATE TABLE pardot.dbo.tmp_sfp_Visitor
(
   row_id              bigint identity   NOT NULL,
   id                  bigint,
   page_view_count     bigint,
   ip_address          varchar(200),
   hostname            varchar(200),
   campaign_parameter  varchar(200),
   medium_parameter    varchar(200),
   source_parameter    varchar(200),
   content_parameter   varchar(200),
   term_parameter      varchar(200),
   created_at          datetime2,
   updated_at          datetime2,
   ts_created          datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_Visitor
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_Visitor TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_emailStats', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_emailStats;

CREATE TABLE pardot.dbo.tmp_sfp_emailStats
(
   row_id                     bigint identity   NOT NULL,
   sent                       bigint,
   delivered                  bigint,
   unique_clicks              bigint,
   soft_bounced               bigint,
   hard_bounced               bigint,
   opt_outs                   bigint,
   spam_complaints            bigint,
   opens                      bigint,
   unique_opens               bigint,
   delivery_rate              varchar(10),
   opens_rate                 varchar(10),
   click_through_rate         varchar(10),
   unique_click_through_rate  varchar(10),
   opt_out_rate               varchar(10),
   spam_complaint_rate        varchar(10),
   ts_created                 datetime2         DEFAULT (getdate()),
   list_email_id              bigint,
   total_clicks               bigint,
   click_open_ratio           varchar(10)
);

ALTER TABLE pardot.dbo.tmp_sfp_emailStats
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_emailStats TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_lifecycleHistory', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_lifecycleHistory;

CREATE TABLE pardot.dbo.tmp_sfp_lifecycleHistory
(
   row_id             bigint identity   NOT NULL,
   id                 bigint,
   prospect_id        bigint,
   previous_stage_id  bigint,
   next_stage_id      bigint,
   seconds_elapsed    bigint,
   created_at         datetime2,
   ts_created         datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_lifecycleHistory
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_lifecycleHistory TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_lifecycleStage', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_lifecycleStage;

CREATE TABLE pardot.dbo.tmp_sfp_lifecycleStage
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   position    bigint,
   name        varchar(300),
   is_locked   bit,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_lifecycleStage
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_lifecycleStage TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_list', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_list;

CREATE TABLE pardot.dbo.tmp_sfp_list
(
   row_id          bigint identity   NOT NULL,
   id              bigint,
   name            varchar(300),
   title           varchar(300),
   description     varchar(300),
   is_public       bit,
   is_dynamic      bit,
   is_crm_visible  bit,
   created_at      datetime2,
   updated_at      datetime2,
   ts_created      datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_list
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_list TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_listMembership', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_listMembership;

CREATE TABLE pardot.dbo.tmp_sfp_listMembership
(
   row_id       bigint identity   NOT NULL,
   id           bigint,
   list_id      bigint,
   prospect_id  bigint,
   opted_out    bit,
   created_at   datetime2,
   updated_at   datetime2,
   ts_created   datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_listMembership
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_listMembership TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_prospectAccount', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_prospectAccount;

CREATE TABLE pardot.dbo.tmp_sfp_prospectAccount
(
   row_id                       bigint identity   NOT NULL,
   assigned_to_user_id          bigint,
   campaign_id                  bigint,
   campaign_name                varchar(200),
   assigned_to_user_email       varchar(200),
   billing_country              varchar(200),
   billing_address_two          varchar(200),
   shipping_zip                 varchar(200),
   description                  ntext,
   billing_zip                  varchar(200),
   website                      varchar(200),
   billing_state                varchar(200),
   assigned_to_user_account     varchar(200),
   type                         varchar(200),
   billing_city                 varchar(200),
   phone                        varchar(200),
   shipping_address_two         varchar(200),
   assigned_to_user_role        varchar(200),
   billing_address_one          varchar(200),
   shipping_address_one         varchar(200),
   shipping_state               varchar(200),
   ownership                    varchar(200),
   assigned_to_user_job_title   varchar(200),
   employees                    varchar(200),
   name                         varchar(200),
   industry                     varchar(200),
   annual_revenue               varchar(200),
   Customer_Account_Code        varchar(200),
   fax                          varchar(200),
   assigned_to_user_updated_at  varchar(200),
   rating                       varchar(200),
   shipping_country             varchar(200),
   assigned_to_user_last_name   varchar(200),
   ticker_symbol                varchar(200),
   number                       varchar(200),
   assigned_to_user_first_name  varchar(200),
   shipping_city                varchar(200),
   site                         varchar(200),
   sic                          varchar(200),
   id                           bigint,
   assigned_to_user_created_at  datetime2,
   created_at                   datetime2,
   updated_at                   datetime2,
   ts_created                   datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_prospectAccount
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_prospectAccount TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_tag', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_tag;

CREATE TABLE pardot.dbo.tmp_sfp_tag
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   name        varchar(200),
   created_at  datetime2,
   updated_at  datetime2,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_tag
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_tag TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_tagObject', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_tagObject;

CREATE TABLE pardot.dbo.tmp_sfp_tagObject
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   tag_id      bigint,
   object_id   bigint,
   type        varchar(200),
   created_at  datetime2,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_tagObject
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_tagObject TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_user', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_user;

CREATE TABLE pardot.dbo.tmp_sfp_user
(
   row_id      bigint identity   NOT NULL,
   id          bigint,
   account     bigint,
   email       varchar(200),
   first_name  varchar(200),
   last_name   varchar(200),
   job_title   varchar(200),
   role        varchar(200),
   created_at  datetime2,
   updated_at  datetime2,
   ts_created  datetime2         DEFAULT (getdate())
);

ALTER TABLE pardot.dbo.tmp_sfp_user
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_user TO dbo;

COMMIT;
IF OBJECT_ID('pardot.dbo.tmp_sfp_visitorActivity', 'U') IS NOT NULL DROP TABLE pardot.dbo.tmp_sfp_visitorActivity;

CREATE TABLE pardot.dbo.tmp_sfp_visitorActivity
(
   row_id                          bigint identity   NOT NULL,
   id                              bigint,
   visitor_id                      bigint,
   prospect_id                     bigint,
   type                            bigint,
   type_name                       varchar(100),
   details                         varchar(500),
   created_at                      datetime,
   ts_created                      datetime2         DEFAULT (getdate()),
   email_id                        bigint,
   email_template_id               bigint,
   list_email_id                   bigint,
   form_id                         bigint,
   form_handler_id                 bigint,
   site_search_query_id            bigint,
   landing_page_id                 bigint,
   paid_search_id_id               bigint,
   multivariate_test_variation_id  bigint,
   visitor_page_view_id            bigint,
   file_id                         bigint,
   campaign_id                     bigint
);

ALTER TABLE pardot.dbo.tmp_sfp_visitorActivity
  ADD PRIMARY KEY CLUSTERED (row_id);

GRANT DELETE, REFERENCES, UPDATE, SELECT, INSERT ON pardot.dbo.tmp_sfp_visitorActivity TO dbo;

COMMIT;
