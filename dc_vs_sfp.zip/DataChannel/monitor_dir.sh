while sleep 1; 
	do 
		date
		ls -1 /data/jump450/YahooGemini/data/downloaded/ | wc -l && ls -1 /data/jump450/YahooGemini/data/completed/ | wc -l; 
		echo "***********************************"; 
	done
