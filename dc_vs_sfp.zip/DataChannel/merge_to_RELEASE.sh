git pull -vvv
git push -vvv
git checkout RELEASE
git pull -vvv
git merge dev
git push -vvv
git checkout dev
git status