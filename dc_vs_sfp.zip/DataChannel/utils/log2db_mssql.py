# log2db_mssql.py

__author__ = "Riju"
__credits__ = ["Sandeep"]
__maintainer__ = "Riju"
__email__ = "rijumone.choudhuri@decision-tree.com"
__status__ = "Development"

import os
import sys
import time
import pyodbc
import logging
import traceback
import subprocess
sys.path.append(os.path.abspath(os.path.join(__file__,'..')))
import load_config
from contextlib import closing

class Log2DB:
	
	current_user = subprocess.check_output(["whoami"]).decode("utf-8").strip("\n")
	project_config = load_config.load(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "project_config.json")))

	db = None
	data_source_name = None
	report_id = None


	def __init__(self, data_source_name, machine_name, run_type):
		self.data_source_name = data_source_name
		self.machine_name = machine_name
		self.run_type = run_type
		self.db = self.conn2db()

	def conn2db(self):
		try:
			return pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + self.project_config["db_log"]['host'] + ';DATABASE=' + self.project_config["db_log"]['db'] + ';UID=' + self.project_config["db_log"]['user'] + ';PWD=' + self.project_config["db_log"]['pass'], timeout=10)
		except:
			logging.error('unable to establish a connection to the logging database')
			logging.error('error: {error}'.format(error=traceback.format_exc()))
			return None

	def log2report_run(self, **kwargs):
		# what i need: report_id, machine_name, run_type
		# what i return: report_run_id
		
		lastrowid = None		
		db = self.conn2db()		
		sql = """INSERT INTO [log_report_run] ([report_id],[machine_name],[run_type]) VALUES (?, ?, ?)"""
		with closing(db.cursor()) as cursor:
			try:
				cursor.execute("""INSERT INTO [log_report_run] ([report_id],[machine_name],[run_type]) VALUES (?, ?, ?)""", (
					kwargs['report_id'],
					self.machine_name,
					self.run_type,
					))
				db.commit()
				cursor.execute('SELECT @@IDENTITY')
				lastrowid = cursor.fetchone()[0]
			except:
				logging.error('unable to insert into log_report_run')
				logging.error('error: {error}'.format(error=traceback.format_exc()))			
				logging.error('sql: {sql}'.format(sql=sql))			
		db.close()		
		return lastrowid


	def log2report_run_activity(self, **kwargs):
		# what i need: report_run_id, activity
		# what i return: report_run_activity_id

		lastrowid = None
		db = self.conn2db()
		sql = """INSERT INTO [log_report_run_activity] ([report_run_id],[activity]) VALUES (?, ?)"""
		with closing(db.cursor()) as cursor:
			try:
				cursor.execute(sql, (
					kwargs['report_run_id'],
					kwargs['activity'],
					))
				db.commit()
				cursor.execute('SELECT @@IDENTITY')
				lastrowid = cursor.fetchone()[0]
			except:
				logging.error('unable to insert into log_report_run_activity')
				logging.error('error: {error}'.format(error=traceback.format_exc()))			
				logging.error('sql: {sql}'.format(sql=sql))			
		db.close()
		return lastrowid


	def log2report_run_activity_file_details(self, **kwargs):
		# what i need: report_run_activity_id, file_name, file_size
		# what i return: report_run_activity_file_details_id

		lastrowid = None
		db = self.conn2db()
		sql = """INSERT INTO [log_report_run_activity_file_details] ([report_run_activity_id],[file_name],[file_size]) VALUES (?, ?, ?)"""
		with closing(db.cursor()) as cursor:
			try:
				cursor.execute(sql, (
					kwargs['report_run_activity_id'],
					kwargs['file_name'],
					kwargs['file_size'],
					))
				db.commit()
				cursor.execute('SELECT @@IDENTITY')
				lastrowid = cursor.fetchone()[0]
			except:
				logging.error('unable to insert into log_report_run_activity_file_details')
				logging.error('error: {error}'.format(error=traceback.format_exc()))			
				logging.error('sql: {sql}'.format(sql=sql))			
		db.close()
		return lastrowid


	def log2report_run_activity_db_details(self, **kwargs):
		# what i need: report_run_activity_id, operation_type, num_rows_affected
		# what i return: report_run_activity_db_details_id

		lastrowid = None
		db = self.conn2db()
		sql = """INSERT INTO [log_report_run_activity_db_details] ([report_run_activity_id],[operation_type],[num_rows_affected]) VALUES (?, ?, ?)"""
		with closing(db.cursor()) as cursor:
			try:
				cursor.execute(sql, (
					kwargs['report_run_activity_id'],
					kwargs['operation_type'],
					kwargs['num_rows_affected'],
					))
				db.commit()
				cursor.execute('SELECT @@IDENTITY')
				lastrowid = cursor.fetchone()[0]
			except:
				logging.error('unable to insert into log_report_run_activity_db_details')
				logging.error('error: {error}'.format(error=traceback.format_exc()))	
				logging.error('sql: {sql}'.format(sql=sql))					
		db.close()
		return lastrowid


	def log2report_run_activity_errors(self, **kwargs):
		# what i need: report_run_activity_id, error_code, error_description
		# what i return: log_report_run_activity_errors_id

		lastrowid = None
		db = self.conn2db()
		sql = """INSERT INTO [log_report_run_activity_errors] ([report_run_activity_id],[error_code],[error_description]) VALUES (?, ?, ?)"""
		with closing(db.cursor()) as cursor:
			try:
				cursor.execute(sql, (
					kwargs['report_run_activity_id'],
					kwargs['error_code'] if kwargs['error_code'] is not None else 'NULL' ,
					kwargs['error_description'],
					))
				db.commit()
				cursor.execute('SELECT @@IDENTITY')
				lastrowid = cursor.fetchone()[0]
			except:
				logging.error('unable to insert into log_report_run_activity_errors')
				logging.error('error: {error}'.format(error=traceback.format_exc()))			
				logging.error('sql: {sql}'.format(sql=sql))			
		db.close()
		return lastrowid


	def get_report_run_activity_id(self, **kwargs):
		# what i need: filename
		# what i return: report_run_activity_id

		report_run_activity_id = None
		db = self.conn2db()
		sql = """SELECT [report_run_activity_id] from [log_report_run_activity_file_details] WHERE file_name = ?"""
		with closing(db.cursor()) as cursor:
			try:
				cursor.execute(sql, (
					kwargs['file_name'],
					))
				report_run_activity_id = cursor.fetchone()

			except:
				logging.error('unable to fetch "report_run_activity_id" from "log_report_run_activity_file_details"')
				logging.error('error: {error}'.format(error=traceback.format_exc()))
				logging.error('sql: {sql}'.format(sql=sql))			
		db.close()
		return report_run_activity_id