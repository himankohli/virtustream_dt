import concurrent.futures
import math
import time
import traceback
import itertools

PRIMES = [
    112272535095293,
    112582705942171,
    112272535095293,
    115280095190773,
    115797848077099,
    1099726899285419]

def is_prime(n, f, b):
    print(f)
    print(b)
    if n % 2 == 0:
        return False

    sqrt_n = int(math.floor(math.sqrt(n)))
    for i in range(3, sqrt_n + 1, 2):
        if n % i == 0:
            return False
        time.sleep(0.1)
    return True

def main():
    with concurrent.futures.ProcessPoolExecutor() as executor:
        try:
            for number, prime in zip(PRIMES, executor.map(is_prime, PRIMES, itertools.repeat(12345678), itertools.repeat('foo'))):
                print('%d is prime: %s' % (number, prime))
        except concurrent.futures.process.BrokenProcessPool as e:
            print(e)
        except:
            print(traceback.format_exc())

if __name__ == '__main__':
    main()