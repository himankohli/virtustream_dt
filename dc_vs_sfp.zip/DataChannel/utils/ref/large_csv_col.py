# large_csv_col.py

import os
import csv
import time

started_timestamp = time.time()

spamReader = csv.reader(open('/'.join(os.path.abspath(os.path.join(__file__)).split('/')[:-1]) + '/KEYWORDS_PERFORMANCE_REPORT_account_id_454-818-7905_from_20180305_to_20180405_1522962002.csv'))
spamWriter = csv.writer(open('/'.join(os.path.abspath(os.path.join(__file__)).split('/')[:-1]) + '/KEYWORDS_PERFORMANCE_REPORT_account_id_454-818-7905_from_20180305_to_20180405_1522962002_target.csv', 'w'))

ctr = 0
for row in spamReader:
    ctr += 1
    print(ctr)
    # print(row)
    # print(type(row))
    # print(', '.join(row))
    if ctr == 1:
        spamWriter.writerow(row + ['AccountId'])
    else:
        spamWriter.writerow(row + ['454-818-7905'])


print("total time: " + str(int(time.time() - started_timestamp)) + " seconds")