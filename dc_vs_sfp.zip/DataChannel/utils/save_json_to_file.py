# save_json_to_file.py
import json

def save(json_obj, file_path):
	with open(file_path, 'a') as json_file:
		json_file.write("{0}\n".format(json.dumps(json_obj)))