# clear_mail_file.sh

df
printf "START\n"
stat --printf="%s" /var/mail/$1
printf "\n"
echo "" > /var/mail/$1
df
echo date
printf "\n"
printf "END\n"