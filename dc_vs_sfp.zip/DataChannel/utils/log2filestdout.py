# log2filestdout.py

import sys
import queue
import logging
import logging.handlers

def init(loglevel, path, format_str='%(asctime)s:%(levelname)s: %(message)s', timeformat='%m/%d/%Y %H:%M:%S', maxBytes=1024*1024*5):
    # logging basic configuration   
    root = logging.getLogger()
    # adding handler to stdout as well
    ch = logging.StreamHandler(sys.stdout)
    # adding rotation
    handler = logging.handlers.RotatingFileHandler(filename=path, maxBytes=maxBytes, backupCount=9)
    # defining the format
    formatter = logging.Formatter(format_str, timeformat)
    ch.setFormatter(formatter)
    handler.setFormatter(formatter)
    root.setLevel(loglevel)
    ch.setLevel(loglevel)
    
    # to log warnings                            
    warning_log = logging.handlers.RotatingFileHandler(filename=path.replace(".log","_warning.log"), maxBytes=maxBytes, backupCount=9)
    warning_log.setLevel(logging.WARNING)
    warning_log.setFormatter(formatter)
    
    # to log errors                            
    error_log = logging.handlers.RotatingFileHandler(filename=path.replace(".log","_error.log"), maxBytes=maxBytes, backupCount=9)
    error_log.setLevel(logging.ERROR)
    error_log.setFormatter(formatter)

    # to log critical                            
    critical_log = logging.handlers.RotatingFileHandler(filename=path.replace(".log","_critical.log"), maxBytes=maxBytes, backupCount=9)
    critical_log.setLevel(logging.CRITICAL)
    critical_log.setFormatter(formatter)


    root.addHandler(ch)
    root.addHandler(handler)
    root.addHandler(warning_log)
    root.addHandler(error_log)
    root.addHandler(critical_log)

def log(log_q):
    while True:
        try:
            log_item = log_q.get_nowait()
            if log_item is None:
                break
            else:
                if log_item['level'] == 'info':
                    logging.info(log_item['msg'])
                elif log_item['level'] == 'warning':
                    logging.warning(log_item['msg'])
                elif log_item['level'] == 'error':
                    logging.error(log_item['msg'])
                elif log_item['level'] == 'critical':
                    logging.critical(log_item['msg'])
        except queue.Empty:
            continue