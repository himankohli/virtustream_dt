# get_largest_int.py

import json
largest_int = 0
with open('/Users/rijumone/Downloads/insights_day_page_id_79979911177_since_2018-10-29_until_2019-01-29_1548703409.txt') as in_file:
	lines = in_file.readlines()
	# print(lines[0:5])
	for json_str in lines[0:1000000]:
		json_obj = json.loads(json_str)
		# print(json.dumps(json_obj, indent=2))
		for k in json_obj:
			if type(json_obj[k]) == int and json_obj[k] > largest_int:
				largest_int = json_obj[k]
				print(k)
				print(largest_int)