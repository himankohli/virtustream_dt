# load_config.py

import json

def load(path, type='json'):
	with open(path) as json_file:
		if type == 'json':
			return json.loads(json_file.read())
		else:
			return json_file.read()