CREATE TABLE dc_j450.zem_conversion_goals (
  Row_ID BIGINT NOT NULL IDENTITY(1,1),
  Agency_ID integer DEFAULT NULL,
  Account_ID integer DEFAULT NULL,
  Campaign_ID integer DEFAULT NULL,
  Ad_Group_ID integer DEFAULT NULL,
  Day date DEFAULT NULL,
  Conversion_Goal varchar(300) DEFAULT NULL,
  Day_1 decimal(20,2) DEFAULT NULL,
  Day_1_CPA decimal(20,2) DEFAULT NULL,
  Day_7 decimal(20,2) DEFAULT NULL,
  Day_7_CPA decimal(20,2) DEFAULT NULL,
  Day_30 decimal(20,2) DEFAULT NULL,
  Day_30_CPA decimal(20,2) DEFAULT NULL,
  Day_90 decimal(20,2) DEFAULT NULL,
  Day_90_CPA decimal(20,2) DEFAULT NULL,
  ts_created datetime DEFAULT CURRENT_TIMESTAMP,
  ts_updated datetime DEFAULT NULL,
  PRIMARY KEY (Row_ID))
  DISTKEY(Account_ID)
  compound sortkey(Account_ID, Day);