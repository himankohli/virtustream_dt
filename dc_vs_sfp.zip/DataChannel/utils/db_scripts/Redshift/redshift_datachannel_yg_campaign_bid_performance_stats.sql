CREATE TABLE dc_j450.yg_campaign_bid_performance_stats (
  Row_ID BIGINT NOT NULL IDENTITY(1,1),
  Advertiser_ID BIGINT DEFAULT NULL,
  Campaign_ID BIGINT DEFAULT NULL,
  Ad_Group_ID BIGINT DEFAULT NULL,
  Day date DEFAULT NULL,
  Supply_Type varchar(50) DEFAULT NULL,
  Group_or_Site varchar(50) DEFAULT NULL,
  Bid_Modifier decimal(20,10) DEFAULT NULL,
  Average_Bid decimal(20,10) DEFAULT NULL,
  Modified_Bid decimal(20,10) DEFAULT NULL,
  Impressions BIGINT DEFAULT NULL,
  Clicks BIGINT DEFAULT NULL,
  Conversions BIGINT DEFAULT NULL,
  Post_View_Conversions INTEGER DEFAULT NULL,
  Post_Click_Conversions INTEGER DEFAULT NULL,
  Cost decimal(20,10) DEFAULT NULL,
  CTR decimal(20,10) DEFAULT NULL,
  Average_CPC decimal(20,10) DEFAULT NULL,
  ts_created datetime DEFAULT CURRENT_TIMESTAMP,
  ts_updated datetime DEFAULT NULL,
  PRIMARY KEY (Row_ID))
  DISTKEY(Advertiser_ID)
  compound sortkey(Advertiser_ID, Day);
