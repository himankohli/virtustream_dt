import sys

# build sys.argv dict
args_dict = {}
for arg in sys.argv:
    if "--" in arg and "=" in arg:
        args_dict[arg.split("=")[0].replace("--","")] = arg.split("=")[1]
