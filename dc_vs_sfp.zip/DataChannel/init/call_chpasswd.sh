echo $1:$2 | sudo chpasswd
echo "password for $1 changed"