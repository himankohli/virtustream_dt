import os
import sys
import time
import json
import glob
import logging
import datetime
import subprocess
import logging.handlers

# build sys.argv dict
args_dict = {}
for arg in sys.argv:
	if "--" in arg and "=" in arg:
		args_dict[arg.split("=")[0].replace("--","")] = arg.split("=")[1]

# get logging level
loglevel = args_dict["loglevel"] if "loglevel" in args_dict else "DEBUG"

current_user = subprocess.check_output(["whoami"]).decode("utf-8").strip("\n")

# logging basic configuration	
root = logging.getLogger()
root.setLevel(loglevel)
# adding handler to stdout as well
ch = logging.StreamHandler(sys.stdout)
# adding rotation
handler = logging.handlers.RotatingFileHandler(filename='/data/{0}/{1}/work/log/delete_n_days.log'.format(current_user, args_dict["datasource"]), maxBytes=1024*1024*1, backupCount=9)
# defining the format
formatter = logging.Formatter('%(asctime)s : %(name)s : %(levelname)s : %(message)s','%m/%d/%Y %I:%M:%S %p')
ch.setFormatter(formatter)
handler.setFormatter(formatter)
ch.setLevel(loglevel)
root.addHandler(ch)
root.addHandler(handler)

# load project config 
project_config = {}
basepath = os.path.dirname(__file__)	# get dir of current file
filepath = os.path.abspath(os.path.join(basepath, "..", "project_config.json")) # "project_config.json" is one dir level up 
with open(filepath) as project_config_json:
	project_config = json.loads(project_config_json.read())

logging.info("Started")

delete_match = str((datetime.date.today() - datetime.timedelta(int(args_dict["days"]))).strftime('%Y-%m-%d'))

before_count = len(subprocess.check_output(["ls","-1","/data/{0}/{1}/data/completed/".format(current_user,args_dict["datasource"])]).decode("utf-8").split("\n"))
logging.info("files before: {0}".format(before_count))

# logging.debug("Executing command: rm -f /data/{0}/{1}/data/completed/*_to_{2}_*.csv".format(current_user, args_dict["datasource"], delete_match))
# logging.debug(subprocess.check_output(["ls", "/data/{0}/{1}/data/completed/*_to_{2}_*.csv".format(current_user,args_dict["datasource"],delete_match)]).decode("utf-8"))

for file in glob.glob("/data/{0}/{1}/data/completed/*_to_{2}_*.csv".format(current_user,args_dict["datasource"],delete_match)):
	os.remove(file)

after_count = len(subprocess.check_output(["ls","-1","/data/{0}/{1}/data/completed/".format(current_user,args_dict["datasource"])]).decode("utf-8").split("\n"))
logging.info("files after: {0}".format(after_count))
logging.info("files rm ed: {0}".format(before_count - after_count))
logging.info("Completed")
