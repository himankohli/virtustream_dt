

CREATE View [dbo].[v_Lost_From_Stage_Funnel] as 
with v_Won_Lost_LTM as (Select *,case when lost_FROM_stage='0% Lost (Closed/Lost)' then 1
when lost_from_stage='20% Raw Pipeline' then 2
when lost_from_stage='40% Qualified Pipeline' then 3
when lost_from_stage='60% Upside' then 4
when lost_from_stage='75% Strong Upside' then 5 
when lost_from_stage= '90% Commit' then 6
when lost_from_stage='100% Won (closed/won)' then 7
when lost_from_stage is null then 8 end as Lost_from_stage_rank from v_WonLost_LTM),
 Stage_info as (select distinct   lost_FROM_stage,
case when lost_FROM_stage='0% Lost (Closed/Lost)' then 1
when lost_FROM_stage='20% Raw Pipeline' then 2
when lost_FROM_stage='40% Qualified Pipeline' then 3
when lost_FROM_stage='60% Upside' then 4
when lost_FROM_stage ='75% Strong Upside' then 5 
when lost_FROM_stage = '90% Commit' then 6
when lost_FROM_stage ='100% Won (closed/won)' then 7
when lost_FROM_stage is null then 8 end as stage_rank from v_Won_Lost_LTM)
select a.opp_id,acc_name,opp_theatre__c,LOB,opp_segment__c,
opp_close_fiscal_quarter,IsWon,LTM_Flag,b.lost_FROM_stage,b.stage_rank,
a.Competitor,a.New_Acc,Opp_DealSize,
case when opp_dealSize< 100000
THEN '<$100K'
when opp_dealSize>= 100000 and opp_dealSize<250000
THEN '$100K-$250K'
when opp_dealSize>= 250000 and opp_dealSize<500000
THEN '$250K-$500K'
when opp_dealSize>= 500000 and opp_dealSize<1000000
THEN '$500K-$1M'
when opp_dealSize>= 1000000 and opp_dealSize<2500000
THEN '$1M-$2.5M'
when opp_dealSize >= 2500000
THEN '>$2.5M'
END as Deal_Size_Bucket, 1 as Cnt from v_Won_Lost_LTM a

 join Stage_info b
 on b.stage_rank<=a.Lost_from_stage_rank

