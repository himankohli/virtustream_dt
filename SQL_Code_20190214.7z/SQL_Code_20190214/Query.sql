
-------------------CHM for PLS Totals
SELECT SUM(revschd_booked_amount_final)
 FROM Product_Line_Snapshot_Totals_With_Rollover
 where ((stagename LIKE '100%' OR
 stagename LIKE '99%' OR
 stagename LIKE '90%' OR
 stagename LIKE '75%') OR (stagename NOT LIKE '0%' AND heatmap=1))
 AND fiscal_quarter='2019 Q2' and snapshot_type='WEEK 01'

 -------------- CHm for PLS
 SELECT SUM(revschd_booked_amount_final)
 FROM Product_Line_Snapshot
 where ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' OR
 opp_stagename LIKE '90%' OR
 opp_stagename LIKE '75%') OR (opp_stagename NOT LIKE '0%' AND opp_heat_map__c=1))
 AND opp_close_fiscal_quarter='2019 Q2' and snapshot_date='2018-06-15'
 --AND row_type='Totals'
 AND field_source IN ('SFDC', 'RolloverBookings')
 and product_quant_practice_group__c<>'Managed Services'  
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		u_PLS_wRollover_Waterfall

		 -------------- CHm for PLS
 SELECT SUM(revschd_booked_amount_final)
 FROM Product_Line_Snapshot
 where ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' OR
 opp_stagename LIKE '90%' OR
 opp_stagename LIKE '75%') OR (opp_stagename NOT LIKE '0%' AND opp_heat_map__c=1))
 AND opp_close_fiscal_quarter='2019 Q2' and snapshot_date='2018-06-15'
 --AND row_type='Rows'
 AND field_source IN ('SFDC', 'RolloverBookings')
 and product_quant_practice_group__c<>'Managed Services'  
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		AND isharddeleted=0

-----CHM (WEEK 01-DAY 01)
 select
 (SELECT SUM(revschd_forecast_amount__c) FROM Revenue_Schedule_Snapshot where 
 isharddeleted=0 AND ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' OR opp_stagename LIKE '90%' OR
 opp_stagename LIKE '75%') OR (opp_stagename NOT LIKE '0%' AND opp_heat_map__c=1))
and snapshot_type='DAY 01'
 AND field_source IN ('SFDC') and product_quant_practice_group__c='VEC'
 and product_quant_practice_group__c<>'Managed Services'  
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		AND revschd_fiscal_period__c IN ('FY 2019 Period 7','FY 2019 Period 8',
		'FY 2019 Period 9'))
		-
		( SELECT SUM(revschd_forecast_amount__c) FROM Revenue_Schedule_Snapshot where isharddeleted=0 AND ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' OR opp_stagename LIKE '90%' OR
 opp_stagename LIKE '75%') OR (opp_stagename NOT LIKE '0%' AND opp_heat_map__c=1))
and snapshot_type='WEEK 01'
 AND field_source IN ('SFDC') and product_quant_practice_group__c='VEC'
 and product_quant_practice_group__c<>'Managed Services'  
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		AND revschd_fiscal_period__c IN ('FY 2019 Period 7','FY 2019 Period 8',
		'FY 2019 Period 9'))
	
	-------------CHM from Raw Object
		SELECT SUM(r.Forecast_Amount__c/c.ConversionRate) FROM RevenueSchedule r LEFT JOIN CurrencyType c
		ON r.CurrencyIsoCode=c.IsoCode
		where r.isharddeleted=0 AND
		Period__c IN (SELECT CAST(date as date) FROM FiscalQuarters where fiscal_qtr='2019 Q2')
		AND Opportunity__c IN ( SELECT Id FROM Opportunity where  ((stagename LIKE '100%' OR
 stagename LIKE '99%' OR
 stagename LIKE '90%' OR
 stagename LIKE '75%') OR (stagename NOT LIKE '0%' AND heat_map__c=1)) AND ISNULL(type,'a') <>'CSP-Resell'
		AND ISNULL(type,'a') <> 'CSP-Sell Out')
		AND Product_Line__c IN (SELECT Id FROM ProductLine where  product__c IN
		(SELECT id FROM Product2 where  quant_practice_group__c<>'Managed Services'))

		-------------Thru 75% from Raw Object
		SELECT SUM(r.Forecast_Amount__c/c.ConversionRate) FROM RevenueSchedule r LEFT JOIN CurrencyType c
		ON r.CurrencyIsoCode=c.IsoCode
		where r.isharddeleted=0 AND
		Period__c IN (SELECT CAST(date as date) FROM FiscalQuarters where fiscal_qtr='2019 Q2')
		AND Opportunity__c IN ( SELECT Id FROM Opportunity where  ((stagename LIKE '100%' OR
 stagename LIKE '99%' OR stagename LIKE '90%' OR stagename LIKE '75%')) AND ISNULL(type,'a') <>'CSP-Resell'
		AND ISNULL(type,'a') <> 'CSP-Sell Out')
		AND Product_Line__c IN (SELECT Id FROM ProductLine where  product__c IN
		(SELECT id FROM Product2 where  quant_practice_group__c<>'Managed Services'))

		-------------Bookings from Raw Object
		SELECT SUM(r.Forecast_Amount__c/c.ConversionRate) FROM RevenueSchedule r LEFT JOIN CurrencyType c
		ON r.CurrencyIsoCode=c.IsoCode
		where r.isharddeleted=0 AND
		Period__c IN (SELECT CAST(date as date) FROM FiscalQuarters where fiscal_qtr='2019 Q2')
		AND Opportunity__c IN ( SELECT Id FROM Opportunity where  (stagename LIKE '100%' OR
 stagename LIKE '99%' ) AND ISNULL(type,'a') <> 'CSP-Sell Out')
		AND Product_Line__c IN (SELECT Id FROM ProductLine where  product__c IN
		(SELECT id FROM Product2 where  quant_practice_group__c<>'Managed Services'))


	-----Bookings (WEEK 01-DAY 01)	
 select
 (SELECT SUM(revschd_forecast_amount__c) FROM Revenue_Schedule_Snapshot where ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' ) )
and snapshot_type='DAY 01'
 AND field_source IN ('SFDC')
 and product_quant_practice_group__c<>'Managed Services'  
 AND ISNULL(opp_type,'a') <>'CSP-Resell'
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		AND revschd_fiscal_period__c IN ('FY 2019 Period 4','FY 2019 Period 5','FY 2019 Period 6'))
		-
		( SELECT SUM(revschd_forecast_amount__c) FROM Revenue_Schedule_Snapshot where ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%') )
and snapshot_type='WEEK 01'
 AND field_source IN ('SFDC')
 and product_quant_practice_group__c<>'Managed Services'  
 AND ISNULL(opp_type,'a') <>'CSP-Resell'
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		AND revschd_fiscal_period__c IN ('FY 2019 Period 4','FY 2019 Period 5','FY 2019 Period 6'))


		---------Bookings check for current Quarter -- most used---

		
SELECT field_source,SUM(revschd_booked_amount_final) FROM Product_Line_Snapshot
where isharddeleted=0 AND snapshot_type='WEEK 01' --AND field_source<>'POR'
AND opp_close_fiscal_quarter='2019 Q4'
AND ISNULL(opp_type,'a')<>'CSP Sell out'
AND (opp_stagename LIKE '99%' OR opp_stagename LIKE '100%')
AND product_quant_practice_group__c <> 'Managed Services'
GROUP BY field_source


SELECT
			SELECT SUM(pl.booked_amount__c/c.ConversionRate) FROM ProductLine pl LEFT JOIN CurrencyType c
		ON pl.CurrencyIsoCode=c.IsoCode
		where pl.isharddeleted=0 AND pl.Opportunity__c IN (SELECT id FROM Opportunity where  
		isharddeleted=0 AND (stagename LIKE '100%' OR
		stagename LIKE '99%' ) AND closedate between '2018-08-04' AND '2018-11-02'
		AND ISNULL(type,'a')<>'CSP Sell out')
		AND  product__c IN
		(SELECT id FROM Product2 where  quant_practice_group__c<>'Managed Services')
---Executive POR Data Query

SELECT SUM(q_1_bookings_value) FROM Executive_POR_Data
WHERE field_source='New Bookings' AND q_1_closedate='2018-10-06' (SELECT CAST(GETDATE() AS DATE))



			SELECT --TINo.Theater__c, o.Segment__c , pl.Quant_Segment_Practice_Group__c, 
			DISTINCT a.Dell_EMC_Segment__c FROM Opportunity o 
			LEFT JOIN ProductLine pl
			ON o.id=pl.Opportunity__c LEFT JOIN Account a ON o.AccountId=a.id where  
		o.isharddeleted=0 AND (stagename LIKE '100%' OR
		stagename LIKE '99%' ) AND closedate ='2018-09-24'
		AND ISNULL(o.type,'a')<>'CSP Sell out'
		
		

-------------- CHm for Waterfall

SELECT a.*, b.* FROM
 (SELECT pl_Id, revschd_booked_amount_final
 FROM u_PLS_wRollover_Waterfall
 where ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' OR
 opp_stagename LIKE '90%' OR
 opp_stagename LIKE '75%') OR (opp_stagename NOT LIKE '0%' AND opp_heat_map__c=1)) 
 AND opp_close_fiscal_quarter='2019 Q2' and snapshot_date='2018-06-15'
 AND row_type='Rows'
 AND field_source IN ('SFDC') ) a LEFT JOIN 
 ( SELECT pl_Id, revschd_booked_amount_final
 FROM VSASQLSTG01.Staging.dbo.u_PLS_wRollover_Waterfall
 where ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' OR
 opp_stagename LIKE '90%' OR
 opp_stagename LIKE '75%') OR (opp_stagename NOT LIKE '0%' AND opp_heat_map__c=1)) 
 AND opp_close_fiscal_quarter='2019 Q2' and snapshot_date='2018-06-15'
 AND row_type='Rows'
 AND field_source IN ('SFDC')) b
 ON a.pl_id=b.pl_id
 where abs(a.revschd_booked_amount_final-b.revschd_booked_amount_final)>1

 SELECT snapshot_type, revschd_booked_amount_final FROM Product_Line_Snapshot where pl_id='a0B3600000bgyHFEAY'
 and snapshot_date IN ('2018-08-01','2018-06-15')
  SELECT snapshot_type, revschd_booked_amount_final FROM VSASQLSTG01.Staging.dbo.Product_Line_Snapshot where pl_id='a0B3600000bgyHFEAY'  and snapshot_date IN ('2018-08-01','2018-06-15')

   SELECT isharddeleted FROM RevenueSchedule where product_line__c='a0B3600000bgyHFEAY'
 
  SELECT isharddeleted
  FROM VSASQLSTG01.Staging.dbo.RevenueSchedule where product_line__c='a0B3600000bgyHFEAY'  

		DELETE FROM Product_Line_Snapshot
		where snapshot_date='2018-06-15'

		EXEC product_line_snapshot_update

		SELECT * FROM Product_Line_Snapshot
		where snapshot_date='2018-06-15'
		

		EXEC sp_PLS_wRollover_Waterfall


			SELECT SUM(revschd_booked_amount_final)
 FROM u_PLS_wRollover_Waterfall
 where ((opp_stagename LIKE '100%' OR
 opp_stagename LIKE '99%' OR
 opp_stagename LIKE '90%' OR
 opp_stagename LIKE '75%') OR (opp_stagename NOT LIKE '0%' AND opp_heat_map__c=1)) AND revschd_booked_amount_final<>0
 AND opp_close_fiscal_quarter='2019 Q2' and snapshot_date='2018-06-15'
 AND row_type='Rows'
 AND field_source IN ('SFDC') 




 SELECT SUM(revschd_booked_amount_final) FROM Product_Line_Snapshot
 where snapshot_date='2018-06-15'
AND Field_Source IN ('SFDC' ,'RolloverBookings') and isharddeleted=0
		AND product_quant_practice_group__c<>'Managed Services'
		--AND ISNULL(opp_type,'a') <>'CSP-Resell'
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		AND opp_stagename NOT LIKE '0%' AND opp_segment__c='Public Sector'  

 SELECT SUM(revschd_booked_amount_final) FROM 
 Product_Line_Snapshot_Totals_With_Rollover
 where snapshot_date='2018-06-15' AND stagename NOT LIKE '0%'
AND segment='Public Sector'  

  SELECT opp_id, revschd_booked_amount_final, pl_id FROM u_PLS_wRollover_Waterfall
 where snapshot_date='2018-06-15'
AND Field_Source IN ('SFDC' ,'RolloverBookings')
AND product_quant_practice_group_previous<>'Managed Services'
AND opp_stagename NOT LIKE '0%'
AND opp_segment__c='Public Sector'  and opp_theatre__c='Americas' AND
product_quant_practice_group_previous='VEC'
AND opp_close_fiscal_quarter ='2019 Q3'
AND opp_stagename='20% Raw Pipeline'


SELECT opp_id, revschd_booked_amount_final, pl_id FROM u_PLS_wRollover_Waterfall
 where snapshot_date='2018-06-15'
AND row_type='Totals' AND opp_stagename NOT LIKE '0%' 
AND opp_segment__c='Public Sector'   and opp_theatre__c='Americas'
AND product_quant_practice_group_previous='VEC'
AND opp_close_fiscal_quarter ='2019 Q3'
AND opp_stagename='20% Raw Pipeline'

----------Check which thatre segment product combination is missing---


SELECT DISTINCT o.theater__c as theatre, o.Segment__c as segment,
pl.Quant_Segment_Practice_Group__c as product,
a.dell_emc_segment__c as classification,
SUBSTRING(o.Fiscal_Year_Quarter__c,4,7) as fiscal_quarter 
FROM Opportunity o LEFT JOIN 
(SELECT id, CASE 
		when substring(dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal'
		ELSE dell_emc_segment__c
	END  as dell_emc_segment__c FROM Account
	where isharddeleted=0) a ON o.accountid=a.id
LEFT JOIN ProductLine pl ON o.Id=pl.Opportunity__c
where o.isharddeleted=0 
AND pl.Quant_Segment_Practice_Group__c <> 'Managed Services'
AND SUBSTRING(o.Fiscal_Year_Quarter__c,4,7) BETWEEN '2018 Q1' AND '2019 Q4'
AND ISNULL(o.type,'a')<>'CSP-Sell Out'
AND
CONCAT(o.theater__c, o.Segment__c, 
a.dell_emc_segment__c, pl.Quant_Segment_Practice_Group__c,
 SUBSTRING(o.Fiscal_Year_Quarter__c,4,7)) 
NOT IN (SELECT CONCAT(theatre, segment, classification, product,
 fiscal_quarter) as w FROM c_POR_Data
where data_type='POR' AND por_type LIKE 'New%' AND product <> 'Managed Services'
GROUP BY theatre, segment, classification, product, fiscal_quarter)
ORDER BY 5,4,3,2,1
 
