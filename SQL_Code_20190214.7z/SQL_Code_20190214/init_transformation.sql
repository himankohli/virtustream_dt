 /*

[dbo].[init_transformation]:-
1. Limit the data at 12 AM, 8 AM , and 4 PM based on the run_time.
2. Flag hard delete based on the temp objects.

*/ 

ALTER PROCEDURE [dbo].[init_transformation]
AS
BEGIN
SET NOCOUNT ON

DECLARE @today DATETIME=(SELECT CAST(GETDATE() AS DATE))
DECLARE @run_time TIME=(SELECT FORMAT(GETDATE(),'HH:mm:ss'))
DECLARE @count INT
DECLARE @a INT
DECLARE @b INT



IF(@run_time>='08:00:00' AND @run_time<'16:00:00')

	BEGIN

	SET @today=DATEADD(HH, 8, @today)

	END


IF(@run_time>='16:00:00' AND @run_time<='23:59:59')
	BEGIN

	SET @today=DATEADD(HH, 16, @today)

	END


----------------Opportunity--------------------



DELETE  FROM Opportunity
WHERE id IN (SELECT opp_id  FROM Opportunity_check
WHERE SystemModstamp<@today)

INSERT INTO Opportunity
(
 id,
isdeleted,
accountid,
recordtypeid,
isprivate,
name,
description,
stagename,
amount,
probability,
expectedrevenue,
totalopportunityquantity,
closedate,
type,
nextstep,
leadsource,
isclosed,
iswon,
forecastcategory,
forecastcategoryname,
currencyisocode,
campaignid,
hasopportunitylineitem,
pricebook2id,
ownerid,
territory2id,
isexcludedfromterritory2filter,
createddate,
createdbyid,
lastmodifieddate,
lastmodifiedbyid,
systemmodstamp,
lastactivitydate,
lastvieweddate,
lastreferenceddate,
syncedquoteid,
contractid,
hasopenactivity,
hasoverduetask,
budget_confirmed__c,
discovery_completed__c,
roi_analysis_completed__c,
additional_account_relationship__c,
loss_reason__c,
additional_lead_sources__c,
case_safe_18_digit_id__c,
closed_acv_1__c,
closed_acv_2__c,
closed_tcv__c,
competitor__c,
count_of_contact_roles__c,
credit_amount__c,
credit_reason__c,
emc_federated_opportunity__c,
xpressnameconcat__c,
additional_influencing_partner__c,
forecasted__c,
gate__c,
heat_map__c,
legal_entity__c,
manager__c,
oppty_source_id_jim__c,
opportunity_number__c,
opportunity_segment__c,
opportunity_sub_segment__c,
primary_data_center__c,
sales_channel__c,
secondary_data_center__c,
segment__c,
sub_segment__c,
total_contract_value__c,
won_lost_comments__c,
acv_1__c,
acv_2__c,
count_of_product_lines__c,
lead_conversion_check__c,
emc_federation_company__c,
rollup_tcv__c,
revenue_end_date__c,
revenue_start_date__c,
country__c,
deal_structure_del__c,
emc_opportunity_number__c,
lead_partner_type__c,
lead_partner__c,
opportunity_conversion__c,
related_opportunity__c,
related_product_amount__c,
so_number__c,
theater__c,
third_party_products__c,
closed_acv1_new__c,
closed_acv2_new__c,
closed_tcv_new__c,
end_customer__c,
next_steps__c,
end_customer_ucid__c,
dell_technologies_business__c,
opportunity_age__c,
fiscal_year_quarter__c,
no_tforc__c,
total_product_lines__c,
total_product_lines_w_commit__c,
most_recent_5_next_steps__c,
vec_acv1__c,
vsc_acv1__c,
sw_acv1__c,
ms_acv1__c,
vertical__c,
sold_to__c,
end_customer_account_id__c,
sold_to_theater__c,
sold_to_account_id__c,
account_theater__c,
theater_formula__c,
rfp_opportunity__c,
pardot_campaign__c,
boomwire_checkbox__c,
primary_partner_role__c,
dell_technologies_role__c,
web_cpt_link__c,
differentiator__c,
secondary_competitor_1__c,
secondary_competitor_2__c,
application__c,
healthcare_cloud_offering__c,
approved_by__c,
approved_date__c,
gate_1__c,
gate_2__c,
gate_3__c,
gate_4__c,
signature_approval__c,
owner_role__c,
annual_contract_value_year_1__c,
revenue_annual_contract_value_year_1__c,
revenue_annual_contract_value_year_2__c,
revenue_annual_contract_value_year_3__c,
committed_contract_value__c,
booked_amount__c,
include_in_outlook__c,
Primary_Partner__c,
Primary_Partner_Type__c,
update_timestamp,
Forecast_Alignment__c
)
(SELECT opp_id,
isdeleted,
accountid,
recordtypeid,
isprivate,
name,
description,
stagename,
amount,
probability,
expectedrevenue,
totalopportunityquantity,
closedate,
type,
nextstep,
leadsource,
isclosed,
iswon,
forecastcategory,
forecastcategoryname,
currencyisocode,
campaignid,
hasopportunitylineitem,
pricebook2id,
ownerid,
territory2id,
isexcludedfromterritory2filter,
createddate,
createdbyid,
lastmodifieddate,
lastmodifiedbyid,
systemmodstamp,
lastactivitydate,
lastvieweddate,
lastreferenceddate,
syncedquoteid,
contractid,
hasopenactivity,
hasoverduetask,
budget_confirmed__c,
discovery_completed__c,
roi_analysis_completed__c,
additional_account_relationship__c,
loss_reason__c,
additional_lead_sources__c,
case_safe_18_digit_id__c,
closed_acv_1__c,
closed_acv_2__c,
closed_tcv__c,
competitor__c,
count_of_contact_roles__c,
credit_amount__c,
credit_reason__c,
emc_federated_opportunity__c,
xpressnameconcat__c,
additional_influencing_partner__c,
forecasted__c,
gate__c,
heat_map__c,
legal_entity__c,
manager__c,
oppty_source_id_jim__c,
opportunity_number__c,
opportunity_segment__c,
opportunity_sub_segment__c,
primary_data_center__c,
sales_channel__c,
secondary_data_center__c,
segment__c,
sub_segment__c,
total_contract_value__c,
won_lost_comments__c,
acv_1__c,
acv_2__c,
count_of_product_lines__c,
lead_conversion_check__c,
emc_federation_company__c,
rollup_tcv__c,
revenue_end_date__c,
revenue_start_date__c,
country__c,
deal_structure_del__c,
emc_opportunity_number__c,
lead_partner_type__c,
lead_partner__c,
opportunity_conversion__c,
related_opportunity__c,
related_product_amount__c,
so_number__c,
theater__c,
third_party_products__c,
closed_acv1_new__c,
closed_acv2_new__c,
closed_tcv_new__c,
end_customer__c,
next_steps__c,
end_customer_ucid__c,
dell_technologies_business__c,
opportunity_age__c,
fiscal_year_quarter__c,
no_tforc__c,
total_product_lines__c,
total_product_lines_w_commit__c,
most_recent_5_next_steps__c,
vec_acv1__c,
vsc_acv1__c,
sw_acv1__c,
ms_acv1__c,
NULL as vertical__c,
sold_to__c,
end_customer_account_id__c,
sold_to_theater__c,
sold_to_account_id__c,
account_theater__c,
theater_formula__c,
rfp_opportunity__c,
pardot_campaign__c,
boomwire_checkbox__c,
primary_partner_role__c,
dell_technologies_role__c,
web_cpt_link__c,
differentiator__c,
secondary_competitor_1__c,
secondary_competitor_2__c,
application__c,
healthcare_cloud_offering__c,
approved_by__c,
approved_date__c,
gate_1__c,
gate_2__c,
gate_3__c,
gate_4__c,
signature_approval__c,
owner_role__c,
annual_contract_value_year_1__c,
revenue_annual_contract_value_year_1__c,
revenue_annual_contract_value_year_2__c,
revenue_annual_contract_value_year_3__c,
committed_contract_value__c,
booked_amount__c,
include_in_outlook__c,
Primary_Partner__c,
Primary_Partner_Type__c,
update_timestamp,
Forecast_Alignment__c 
FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY opp_Id ORDER BY opp_Id) as rn FROM Opportunity_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)
 
UPDATE Opportunity
SET IsHardDeleted=1
WHERE Id NOT IN (SELECT opp_Id FROM Opportunity_temp)

UPDATE Opportunity
SET IsHardDeleted=0
WHERE Id  IN ( SELECT opp_Id FROM Opportunity_temp)
 
SELECT @a=COUNT(*) FROM Opportunity_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Opportunity WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Opportunity: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Opportunity'),@b)


----------------------------------------Account------------------------------



DELETE  FROM Account
WHERE id IN (SELECT acc_id  FROM Account_check
WHERE SystemModstamp<@today)

INSERT INTO Account
( id,
IsDeleted,
MasterRecordId,
Name,
Type,
RecordTypeId,
BillingStreet,
BillingCity,
BillingState,
BillingPostalCode,
BillingCountry,
BillingStateCode,
BillingCountryCode,
BillingLatitude,
BillingLongitude,
BillingGeocodeAccuracy,
BillingAddress,
ShippingStreet,
ShippingCity,
ShippingState,
ShippingPostalCode,
ShippingCountry,
ShippingStateCode,
ShippingCountryCode,
ShippingLatitude,
ShippingLongitude,
ShippingGeocodeAccuracy,
ShippingAddress,
Phone,
Fax,
AccountNumber,
Website,
PhotoUrl,
Sic,
Industry,
AnnualRevenue,
NumberOfEmployees,
Ownership,
TickerSymbol,
Description,
Rating,
Site,
CurrencyIsoCode,
ownerid,
createddate,
createdbyid,
lastmodifieddate,
lastmodifiedbyid,
systemmodstamp,
lastactivitydate,
lastvieweddate,
lastreferenceddate,
jigsaw,
jigsawcompanyid,
accountsource,
sicdesc,
architecture__c,
erp_application__c,
original_lead_source__c,
partner_tier__c,
payment_terms__c,
record_type_name_text__c,
segment__c,
sub_segment__c,
theater__c,
ucid__c,
billing_address_populated__c,
select_account_id__c,
account_id_18_digit__c,
dell_emc_alignment__c,
affinity_id__c,
account_region__c,
open_opportunties__c,
won_opportunities__c,
dell_emc_segment__c,
site_duns__c,
vertical__c,
theater_formula__c,
dell_emc_area__c,
gu_duns__c,
dell_emc_district__c,
total_opportunities__c,
industry__c,
ta_zipcode__c,
account_owner_active__c,
partner_type__c,
update_timestamp
)
(SELECT acc_id,
IsDeleted,
MasterRecordId,
Name,
Type,
RecordTypeId,
BillingStreet,
BillingCity,
BillingState,
BillingPostalCode,
BillingCountry,
BillingStateCode,
BillingCountryCode,
BillingLatitude,
BillingLongitude,
BillingGeocodeAccuracy,
BillingAddress,
ShippingStreet,
ShippingCity,
ShippingState,
ShippingPostalCode,
ShippingCountry,
ShippingStateCode,
ShippingCountryCode,
ShippingLatitude,
ShippingLongitude,
ShippingGeocodeAccuracy,
ShippingAddress,
Phone,
Fax,
AccountNumber,
Website,
PhotoUrl,
Sic,
Industry,
AnnualRevenue,
NumberOfEmployees,
Ownership,
TickerSymbol,
Description,
Rating,
Site,
CurrencyIsoCode,
ownerid,
createddate,
createdbyid,
lastmodifieddate,
lastmodifiedbyid,
systemmodstamp,
lastactivitydate,
lastvieweddate,
lastreferenceddate,
jigsaw,
jigsawcompanyid,
accountsource,
sicdesc,
architecture__c,
erp_application__c,
original_lead_source__c,
partner_tier__c,
payment_terms__c,
record_type_name_text__c,
segment__c,
sub_segment__c,
theater__c,
ucid__c,
billing_address_populated__c,
select_account_id__c,
account_id_18_digit__c,
dell_emc_alignment__c,
affinity_id__c,
account_region__c,
open_opportunties__c,
won_opportunities__c,
dell_emc_segment__c,
site_duns__c,
industry__c as vertical__c,
theater_formula__c,
dell_emc_area__c,
gu_duns__c,
dell_emc_district__c,
total_opportunities__c,
industry__c,
ta_zipcode__c,
account_owner_active__c,
partner_type__c,
update_timestamp
FROM Account_check
WHERE SystemModstamp<@today)

 
UPDATE [Account]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT acc_Id FROM Account_temp)

UPDATE [Account]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT acc_Id FROM Account_temp)
 
SELECT @a=COUNT(*) FROM Account_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Account  WHERE isharddeleted=0


INSERT INTO u_audit_log
values('Account: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Account'),@b)


-------------------------------Campaign--------------------------------


DELETE  FROM Campaign
WHERE id IN (SELECT campaign_id  FROM Campaign_check
WHERE SystemModstamp<@today)

INSERT INTO Campaign
(
Id,
IsDeleted,
Name,
ParentId,
Type,
Status,
StartDate,
EndDate,
CurrencyIsoCode,
ExpectedRevenue,
BudgetedCost,
ActualCost,
ExpectedResponse,
NumberSent,
IsActive,
Description,
NumberOfLeads,
NumberOfConvertedLeads,
NumberOfContacts,
NumberOfResponses,
NumberOfOpportunities,
NumberOfWonOpportunities,
AmountAllOpportunities,
AmountWonOpportunities,
OwnerId,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
LastViewedDate,
LastReferencedDate,
CampaignMemberRecordTypeId,
Update_Timestamp

)
(SELECT campaign_id,
IsDeleted,
Name,
ParentId,
Type,
Status,
StartDate,
EndDate,
CurrencyIsoCode,
ExpectedRevenue,
BudgetedCost,
ActualCost,
ExpectedResponse,
NumberSent,
IsActive,
Description,
NumberOfLeads,
NumberOfConvertedLeads,
NumberOfContacts,
NumberOfResponses,
NumberOfOpportunities,
NumberOfWonOpportunities,
AmountAllOpportunities,
AmountWonOpportunities,
OwnerId,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
LastViewedDate,
LastReferencedDate,
CampaignMemberRecordTypeId,
Update_Timestamp  FROM 
 (SELECT *, ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY campaign_id) as rn FROM Campaign_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

 
UPDATE [Campaign]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT campaign_Id FROM Campaign_temp)


UPDATE [Campaign]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT DISTINCT campaign_Id FROM Campaign_temp)
 
SELECT @a=COUNT(*) FROM Campaign_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Campaign  WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Campaign: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Campaign'),@b)

-----------------------------------CampaignMember-------------------------

DELETE  FROM CampaignMember
WHERE id IN (SELECT campmem_id  FROM CampaignMember_check
WHERE SystemModstamp<@today)

INSERT INTO CampaignMember
(
Id,
IsDeleted,
CampaignId,
LeadId,
ContactId,
Status,
HasResponded,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
FirstRespondedDate,
CurrencyIsoCode,
Salutation,
Name,
FirstName,
LastName,
Title,
Street,
City,
State,
PostalCode,
Country,
Email,
Phone,
Fax,
MobilePhone,
Description,
DoNotCall,
HasOptedOutOfEmail,
HasOptedOutOfFax,
LeadSource,
CompanyOrAccount,
Type,
LeadOrContactId,
LeadOrContactOwnerId,
Update_Timestamp
)
(SELECT campmem_id,
IsDeleted,
CampaignId,
LeadId,
ContactId,
Status,
HasResponded,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
FirstRespondedDate,
CurrencyIsoCode,
Salutation,
Name,
FirstName,
LastName,
Title,
Street,
City,
State,
PostalCode,
Country,
Email,
Phone,
Fax,
MobilePhone,
Description,
DoNotCall,
HasOptedOutOfEmail,
HasOptedOutOfFax,
LeadSource,
CompanyOrAccount,
Type,
LeadOrContactId,
LeadOrContactOwnerId,
Update_Timestamp
FROM CampaignMember_check
WHERE SystemModstamp<@today)
 
UPDATE [CampaignMember]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT campmem_id FROM CampaignMember_temp)

UPDATE [CampaignMember]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT campmem_id FROM CampaignMember_temp)
 
SELECT @a=COUNT(*) FROM CampaignMember_check
WHERE SystemModstamp<@today 

SELECT @b=COUNT(id) FROM CampaignMember WHERE isharddeleted=0

INSERT INTO u_audit_log
values('CampaignMember: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='CampaignMember'),@b)

-----------------------------------Contact-------------------------------------

DELETE  FROM Contact
WHERE id IN (SELECT contact_id  FROM Contact_check
WHERE SystemModstamp<@today)

INSERT INTO Contact
(
Id,
IsDeleted,
MasterRecordId,
AccountId,
LastName,
FirstName,
Salutation,
MiddleName,
Name,
RecordTypeId,
OtherStreet,
OtherCity,
OtherState,
OtherPostalCode,
OtherCountry,
OtherStateCode,
OtherCountryCode,
OtherLatitude,
OtherLongitude,
OtherGeocodeAccuracy,
OtherAddress,
MailingStreet,
MailingCity,
MailingState,
MailingPostalCode,
MailingCountry,
MailingStateCode,
MailingCountryCode,
MailingLatitude,
MailingLongitude,
MailingGeocodeAccuracy,
MailingAddress,
Phone,
Fax,
MobilePhone,
HomePhone,
OtherPhone,
AssistantPhone,
ReportsToId,
Email,
Title,
Department,
AssistantName,
LeadSource,
Birthdate,
Description,
CurrencyIsoCode,
OwnerId,
HasOptedOutOfEmail,
HasOptedOutOfFax,
DoNotCall,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
LastCURequestDate,
LastCUUpdateDate,
LastViewedDate,
LastReferencedDate,
EmailBouncedReason,
EmailBouncedDate,
IsEmailBounced,
PhotoUrl,
Jigsaw,
JigsawContactId,
pi__campaign__c,
pi__comments__c,
pi__conversion_date__c,
pi__conversion_object_name__c,
pi__conversion_object_type__c,
pi__created_date__c,
pi__first_activity__c,
pi__first_search_term__c,
pi__first_search_type__c,
pi__first_touch_url__c,
pi__grade__c,
pi__last_activity__c,
pi__notes__c,
pi__pardot_hard_bounced__c,
pi__score__c,
pi__url__c,
pi__utm_campaign__c,
pi__utm_content__c,
pi__utm_medium__c,
pi__utm_source__c,
pi__utm_term__c,
Active__c,
Do_Not_Email__c,
Preferred_Contact_Method__c,
Record_Type_Name_Text__c,
Unique_Identifier__c,
isActiveText__c,
pi__Needs_Score_Synced__c,
Pursuit_Team_Role__c,
WM4SF3__WalkMe_Engagement_Score__c,
Signature_Approver__c,
Update_Timestamp,
Contact_In_Qualification__c  ,
 Contact_Qualified__c ,
Contact_Requires_Action__c 

)
(SELECT contact_id,
IsDeleted,
MasterRecordId,
AccountId,
LastName,
FirstName,
Salutation,
MiddleName,
Name,
RecordTypeId,
OtherStreet,
OtherCity,
OtherState,
OtherPostalCode,
OtherCountry,
OtherStateCode,
OtherCountryCode,
OtherLatitude,
OtherLongitude,
OtherGeocodeAccuracy,
OtherAddress,
MailingStreet,
MailingCity,
MailingState,
MailingPostalCode,
MailingCountry,
MailingStateCode,
MailingCountryCode,
MailingLatitude,
MailingLongitude,
MailingGeocodeAccuracy,
MailingAddress,
Phone,
Fax,
MobilePhone,
HomePhone,
OtherPhone,
AssistantPhone,
ReportsToId,
Email,
Title,
Department,
AssistantName,
LeadSource,
Birthdate,
Description,
CurrencyIsoCode,
OwnerId,
HasOptedOutOfEmail,
HasOptedOutOfFax,
DoNotCall,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
LastCURequestDate,
LastCUUpdateDate,
LastViewedDate,
LastReferencedDate,
EmailBouncedReason,
EmailBouncedDate,
IsEmailBounced,
PhotoUrl,
Jigsaw,
JigsawContactId,
pi__campaign__c,
pi__comments__c,
pi__conversion_date__c,
pi__conversion_object_name__c,
pi__conversion_object_type__c,
pi__created_date__c,
pi__first_activity__c,
pi__first_search_term__c,
pi__first_search_type__c,
pi__first_touch_url__c,
pi__grade__c,
pi__last_activity__c,
pi__notes__c,
pi__pardot_hard_bounced__c,
pi__score__c,
pi__url__c,
pi__utm_campaign__c,
pi__utm_content__c,
pi__utm_medium__c,
pi__utm_source__c,
pi__utm_term__c,
Active__c,
Do_Not_Email__c,
Preferred_Contact_Method__c,
Record_Type_Name_Text__c,
Unique_Identifier__c,
isActiveText__c,
pi__Needs_Score_Synced__c,
Pursuit_Team_Role__c,
WM4SF3__WalkMe_Engagement_Score__c,
Signature_Approver__c,
Update_Timestamp,
Contact_In_Qualification__c  ,
 Contact_Qualified__c ,
Contact_Requires_Action__c 
FROM Contact_check
WHERE SystemModstamp<@today)

 
UPDATE [Contact]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT contact_id FROM Contact_temp)

UPDATE [Contact]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT contact_id FROM Contact_temp)
 
SELECT @a=COUNT(*) FROM Contact_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Contact WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Contact: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Contact'),@b)

---------------------------------Lead------------------------------------



DELETE  FROM Lead
WHERE id IN (SELECT lead_id  FROM Lead_check
WHERE SystemModstamp<@today)

INSERT INTO Lead
(
Id,
IsDeleted,
MasterRecordId,
LastName,
FirstName,
Salutation,
MiddleName,
Name,
RecordTypeId,
Title,
Company,
Street,
City,
State,
PostalCode,
Country,
StateCode,
CountryCode,
Latitude,
Longitude,
GeocodeAccuracy,
Address,
Phone,
MobilePhone,
Fax,
Email,
Website,
PhotoUrl,
Description,
LeadSource,
Status,
Industry,
Rating,
CurrencyIsoCode,
AnnualRevenue,
NumberOfEmployees,
OwnerId,
HasOptedOutOfEmail,
IsConverted,
ConvertedDate,
ConvertedAccountId,
ConvertedContactId,
ConvertedOpportunityId,
IsUnreadByOwner,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
DoNotCall,
HasOptedOutOfFax,
LastViewedDate,
LastReferencedDate,
LastTransferDate,
Jigsaw,
JigsawContactId,
EmailBouncedReason,
EmailBouncedDate,
pi__campaign__c,
pi__comments__c,
pi__conversion_date__c,
pi__conversion_object_name__c,
pi__conversion_object_type__c,
pi__created_date__c,
pi__first_activity__c,
pi__first_search_term__c,
pi__first_search_type__c,
pi__first_touch_url__c,
pi__grade__c,
pi__last_activity__c,
pi__notes__c,
pi__pardot_hard_bounced__c,
pi__score__c,
pi__url__c,
pi__utm_campaign__c,
pi__utm_content__c,
pi__utm_medium__c,
pi__utm_source__c,
pi__utm_term__c,
Architecture__c,
Authority__c,
Business_Opportunity_Description__c,
Cloud_Status__c,
Current_Service_Provider__c,
Do_Not_Email__c,
Lead_Conversion_Check__c,
ERP_Application__c,
Estimated_Revenue__c,
Federation_Customer__c,
How_did_you_hear_about_Virtustream__c,
Lead_Age_Days__c,
Need__c,
Number_of_Servers__c,
Original_Lead_Source__c,
Owner__c,
Partner_Company__c,
Phone_2__c,
Planned_Workload__c,
Related_Opportunity_Amount__c,
Related_Opportunity__c,
SAP_App__c,
SAP_Cloud__c,
SAP_HANA_Status__c,
Segment__c,
Source_Campaign__c,
Sub_Segment__c,
Time_frame__c,
Twitter_Handle__c,
Unqualified_Reason__c,
Virtualization_Level__c,
Area_of_Interest__c,
pi__Needs_Score_Synced__c,
pi__Pardot_Last_Scored_At__c,
EMC_Federation_Company__c,
Dell_Technologies_Business__c,
Partner_Email__c,
Tech_Target_QSO__c,
Employee_Range__c,
Lead_Origin__c,
WM4SF3__WalkMe_Engagement_Score__c,
Briefing_Center_Location__c,
Briefing_Consultant__c,
Customer_Theater__c,
Briefing_Venue__c,
StartDate__c,
Briefing_Event_ID__c,
Briefing_Location_Theater__c,
Briefing_Status__c,
EBC_Activity__c,
Related_Account_Name__c,
Related_Account_Owner__c,
Virtustream_on_the_Agenda__c,
Topic_Name__c,
Session_Name__c,
Fiscal_Year_Quarter__c,
Customer_State__c,
Update_Timestamp,
Assigned_to_Sales__c ,
Lead_In_Qualification__c ,
Lead_Requires_Action__c

)
(SELECT lead_id,
IsDeleted,
MasterRecordId,
LastName,
FirstName,
Salutation,
MiddleName,
Name,
RecordTypeId,
Title,
Company,
Street,
City,
State,
PostalCode,
Country,
StateCode,
CountryCode,
Latitude,
Longitude,
GeocodeAccuracy,
Address,
Phone,
MobilePhone,
Fax,
Email,
Website,
PhotoUrl,
Description,
LeadSource,
Status,
Industry,
Rating,
CurrencyIsoCode,
AnnualRevenue,
NumberOfEmployees,
OwnerId,
HasOptedOutOfEmail,
IsConverted,
ConvertedDate,
ConvertedAccountId,
ConvertedContactId,
ConvertedOpportunityId,
IsUnreadByOwner,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
DoNotCall,
HasOptedOutOfFax,
LastViewedDate,
LastReferencedDate,
LastTransferDate,
Jigsaw,
JigsawContactId,
EmailBouncedReason,
EmailBouncedDate,
pi__campaign__c,
pi__comments__c,
pi__conversion_date__c,
pi__conversion_object_name__c,
pi__conversion_object_type__c,
pi__created_date__c,
pi__first_activity__c,
pi__first_search_term__c,
pi__first_search_type__c,
pi__first_touch_url__c,
pi__grade__c,
pi__last_activity__c,
pi__notes__c,
pi__pardot_hard_bounced__c,
pi__score__c,
pi__url__c,
pi__utm_campaign__c,
pi__utm_content__c,
pi__utm_medium__c,
pi__utm_source__c,
pi__utm_term__c,
Architecture__c,
Authority__c,
Business_Opportunity_Description__c,
Cloud_Status__c,
Current_Service_Provider__c,
Do_Not_Email__c,
Lead_Conversion_Check__c,
ERP_Application__c,
Estimated_Revenue__c,
Federation_Customer__c,
How_did_you_hear_about_Virtustream__c,
Lead_Age_Days__c,
Need__c,
Number_of_Servers__c,
Original_Lead_Source__c,
Owner__c,
Partner_Company__c,
Phone_2__c,
Planned_Workload__c,
Related_Opportunity_Amount__c,
Related_Opportunity__c,
SAP_App__c,
SAP_Cloud__c,
SAP_HANA_Status__c,
Segment__c,
Source_Campaign__c,
Sub_Segment__c,
Time_frame__c,
Twitter_Handle__c,
Unqualified_Reason__c,
Virtualization_Level__c,
Area_of_Interest__c,
pi__Needs_Score_Synced__c,
pi__Pardot_Last_Scored_At__c,
EMC_Federation_Company__c,
Dell_Technologies_Business__c,
Partner_Email__c,
Tech_Target_QSO__c,
Employee_Range__c,
Lead_Origin__c,
WM4SF3__WalkMe_Engagement_Score__c,
Briefing_Center_Location__c,
Briefing_Consultant__c,
Customer_Theater__c,
Briefing_Venue__c,
StartDate__c,
Briefing_Event_ID__c,
Briefing_Location_Theater__c,
Briefing_Status__c,
EBC_Activity__c,
Related_Account_Name__c,
Related_Account_Owner__c,
Virtustream_on_the_Agenda__c,
Topic_Name__c,
Session_Name__c,
Fiscal_Year_Quarter__c,
Customer_State__c,
Update_Timestamp,
Assigned_to_Sales__c ,
Lead_In_Qualification__c ,
Lead_Requires_Action__c
FROM Lead_check
WHERE SystemModstamp<@today)

UPDATE [Lead]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT lead_id FROM Lead_temp)

UPDATE [Lead]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT lead_id FROM Lead_temp)
 
SELECT @a=COUNT(*) FROM Lead_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Lead WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Lead: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Lead'),@b)

-------------------------OpportunityTeamMember---------------------------




DELETE  FROM OpportunityTeamMember
WHERE id IN (SELECT otm_id  FROM OpportunityTeamMember_check
WHERE SystemModstamp<@today)

INSERT INTO OpportunityTeamMember
(id,
OpportunityId,
UserId,
Name,
PhotoUrl,
Title,
TeamMemberRole,
OpportunityAccessLevel,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsDeleted,
Added_through__c,
Update_Timestamp
)
(SELECT otm_id,
OpportunityId,
UserId,
Name,
PhotoUrl,
Title,
TeamMemberRole,
OpportunityAccessLevel,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsDeleted,
Added_through__c,
Update_Timestamp
 FROM OpportunityTeamMember_check
 WHERE SystemModstamp<@today)
  
 UPDATE [OpportunityTeamMember]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT otm_id FROM OpportunityTeamMember_temp)

UPDATE [OpportunityTeamMember]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT otm_id FROM OpportunityTeamMember_temp)
 
SELECT @a=COUNT(*) FROM OpportunityTeamMember_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM OpportunityTeamMember WHERE isharddeleted=0

INSERT INTO u_audit_log
values('OpportunityTeamMember: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='OpportunityTeamMember'),@b)

---------------------------OpportunityFieldHistory---------------------------------


DELETE  FROM OpportunityFieldHistory
WHERE id IN (SELECT ofh_id  FROM OpportunityFieldHistory_check
WHERE CreatedDate<@today)

INSERT INTO OpportunityFieldHistory
(
Id,
IsDeleted,
OpportunityId,
CreatedById,
CreatedDate,
Field,
OldValue,
NewValue,
Update_Timestamp
)
(SELECT ofh_id,
IsDeleted,
OpportunityId,
CreatedById,
CreatedDate,
Field,
OldValue,
NewValue,
Update_Timestamp
FROM (SELECT *, 
ROW_NUMBER() OVER (PARTITION BY ofh_id ORDER BY ofh_id) as rn FROM OpportunityFieldHistory_check 
WHERE CreatedDate<@today) a
where a.rn=1
)


  
SELECT @a=COUNT(*) FROM OpportunityFieldHistory_check
WHERE CreatedDate<@today

SELECT @b=COUNT(id) FROM OpportunityFieldHistory

INSERT INTO u_audit_log
values('OpportunityFieldHistory: Object updated',1,GETDATE(),@a,
NULL, @b)

------------------------------Product2-----------------------------


DELETE  FROM Product2
WHERE id IN (SELECT product_id  FROM Product2_check
WHERE SystemModstamp<@today)

INSERT INTO Product2
(
Id,
Name,
ProductCode,
Description,
IsActive,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
Family,
CurrencyIsoCode,
IsDeleted,
LastViewedDate,
LastReferencedDate,
Quant_Practice_Group__c,
Product_ID_18_Digit__c,
Update_Timestamp
)
(SELECT product_id,
Name,
ProductCode,
Description,
IsActive,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
Family,
CurrencyIsoCode,
IsDeleted,
LastViewedDate,
LastReferencedDate,
Quant_Practice_Group__c,
Product_ID_18_Digit__c,
Update_Timestamp
FROM (SELECT *, 
ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY product_id) as rn FROM Product2_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

 
UPDATE [Product2]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT product_id FROM Product2_temp)

UPDATE [Product2]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT product_id FROM Product2_temp)
 
SELECT @a=COUNT(*) FROM Product2_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Product2 WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Product2: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Product2'),@b)

-------------------------------ProductLine----------------------------

DELETE  FROM ProductLine
WHERE id IN (SELECT pl_id  FROM ProductLine_check
WHERE SystemModstamp<@today)

INSERT INTO ProductLine
(
Id,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastViewedDate,
LastReferencedDate,
Opportunity__c,
Generate_Schedule__c,
Initial_Revenue__c,
Initial_Start_Date__c,
Initial_Term__c,
Job_Code__c,
Notes__c,
Practice_Line__c,
Product__c,
Service_Line__c,
Spread_Type__c,
Unique_Identifier__c,
ACV_Year_1__c,
ACV_Year_2__c,
Product_Line_Sales_Projection__c,
Revenue_Schedule_End_Date__c,
Start_Date__c,
TCV__c,
Term__c,
Quant_Segment_Practice_Group__c,
xPressConcatTheaterPracticeProb__c,
Capacity__c,
CurQCDiff__c,
Gateway__c,
Use_Case__c,
ACV_Year_3__c,
ACV_Year_4__c,
ACV_Year_5__c,
Closed_ACV1__c,
Closed_ACV2__c,
Closed_Total_Amount__c,
xPressConcatProbOppTheater__c,
xPressConcatProbOppTheaterLink__c,
Opportunity_Won__c,
Initial_Start_Period__c,
Committed_Term_Months__c,
Are_there_committed_terms__c,
Committed_Amount__c,
CCV_Year_1__c,
CCV_Year_2__c,
CCV_Year_3__c,
CCV_3_Year_Amount__c,
WBSE__c,
ACV_3_Year_Amount__c,
Quant_Segment_Practice_Group_WF__c,
Other_Gateway__c,
Account_Name_PL__c,
Owner_Name_PL__c,
--Bookings_Amount__c,
Product_Line_ID_18_Digit__c,
Product_ID_18_Digit__c,
Annual_Contact_Value_Year_1__c,
Booked_Amount_Override__c,
Booked_Amount__c,
Booked_CCV__c,
Committed_Contract_Value__c,
Total_Contract_Value__c,
Booked_ACV_Year_1__c,
Booked_CCV_Year_1__c,
Booked_CCV_Year_2__c,
Booked_CCV_Year_3__c,
Booked_TCV__c,
Update_Timestamp

)
(SELECT pl_id,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastViewedDate,
LastReferencedDate,
Opportunity__c,
Generate_Schedule__c,
Initial_Revenue__c,
Initial_Start_Date__c,
Initial_Term__c,
Job_Code__c,
Notes__c,
Practice_Line__c,
Product__c,
Service_Line__c,
Spread_Type__c,
Unique_Identifier__c,
ACV_Year_1__c,
ACV_Year_2__c,
Product_Line_Sales_Projection__c,
Revenue_Schedule_End_Date__c,
Start_Date__c,
TCV__c,
Term__c,
Quant_Segment_Practice_Group__c,
xPressConcatTheaterPracticeProb__c,
Capacity__c,
CurQCDiff__c,
Gateway__c,
Use_Case__c,
ACV_Year_3__c,
ACV_Year_4__c,
ACV_Year_5__c,
Closed_ACV1__c,
Closed_ACV2__c,
Closed_Total_Amount__c,
xPressConcatProbOppTheater__c,
xPressConcatProbOppTheaterLink__c,
Opportunity_Won__c,
Initial_Start_Period__c,
Committed_Term_Months__c,
Are_there_committed_terms__c,
Committed_Amount__c,
CCV_Year_1__c,
CCV_Year_2__c,
CCV_Year_3__c,
CCV_3_Year_Amount__c,
WBSE__c,
ACV_3_Year_Amount__c,
Quant_Segment_Practice_Group_WF__c,
Other_Gateway__c,
Account_Name_PL__c,
Owner_Name_PL__c,
--Bookings_Amount__c,
Product_Line_ID_18_Digit__c,
Product_ID_18_Digit__c,
Annual_Contact_Value_Year_1__c,
Booked_Amount_Override__c,
Booked_Amount__c,
Booked_CCV__c,
Committed_Contract_Value__c,
Total_Contract_Value__c,
Booked_ACV_Year_1__c,
Booked_CCV_Year_1__c,
Booked_CCV_Year_2__c,
Booked_CCV_Year_3__c,
Booked_TCV__c,
Update_Timestamp 
FROM (SELECT *, 
ROW_NUMBER() OVER (PARTITION BY pl_id ORDER BY pl_id) as rn FROM ProductLine_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

UPDATE [ProductLine]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT pl_id FROM ProductLine_temp)

UPDATE [ProductLine]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT pl_id FROM ProductLine_temp)
 
SELECT @a=COUNT(*) FROM ProductLine_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM ProductLine WHERE isharddeleted=0

INSERT INTO u_audit_log
values('ProductLine: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='ProductLine'),@b)

-------------------------RevenueSchedule----------------------------

DELETE  FROM RevenueSchedule
WHERE id IN (SELECT revschd_id  FROM RevenueSchedule_check
WHERE SystemModstamp<@today)

INSERT INTO RevenueSchedule
(
Id,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastViewedDate,
LastReferencedDate,
Product_Line__c,
ACV_1__c,
ACV_2__c,
Actual__c,
Credit_Amount__c,
Forecast_Amount__c,
Forecast_Report__c,
Include_in_ACV_1__c,
Include_in_ACV_2__c,
Note__c,
Opportunity_Close_Date__c,
Opportunity__c,
Period__c,
Practice_Line_Name__c,
Projection__c,
Service_Line_Name__c,
Unique_Identifier__c,
Account_Name__c,
Opportunity_Number__c,
ACV_10__c,
ACV_11__c,
ACV_3__c,
ACV_4__c,
ACV_5__c,
ACV_6__c,
ACV_7__c,
ACV_8__c,
ACV_9__c,
Include_in_ACV_10__c,
Include_in_ACV_11__c,
Include_in_ACV_3__c,
Include_in_ACV_4__c,
Include_in_ACV_5__c,
Include_in_ACV_6__c,
Include_in_ACV_7__c,
Include_in_ACV_8__c,
Include_in_ACV_9__c,
LOAD_Matching_Field__c,
LOAD_Matching_Object__c,
LOAD_Matching_Value__c,
LOAD_Practice_Line__c,
LOAD_Service_Line__c,
Fiscal_Period__c,
Committed_Amount__c,
Committed_Term_Months__c,
Include_in_CCV_1__c,
Include_in_CCV_2__c,
Include_in_CCV_3__c,
Period_Count_Number__c,
Period_Count__c,
Product_Line_Initial_Start_Date__c,
Opportunity_Stage_WF__c,
Stage__c,
Revenue_Schedule_ID_18_Digit__c,
Booked_Amount__c,
Booked_Committed_Amount__c,
WorkFlow_Helper__c,
Update_Timestamp
)
(SELECT revschd_id,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastViewedDate,
LastReferencedDate,
Product_Line__c,
ACV_1__c,
ACV_2__c,
Actual__c,
Credit_Amount__c,
Forecast_Amount__c,
Forecast_Report__c,
Include_in_ACV_1__c,
Include_in_ACV_2__c,
Note__c,
Opportunity_Close_Date__c,
Opportunity__c,
Period__c,
Practice_Line_Name__c,
Projection__c,
Service_Line_Name__c,
Unique_Identifier__c,
Account_Name__c,
Opportunity_Number__c,
ACV_10__c,
ACV_11__c,
ACV_3__c,
ACV_4__c,
ACV_5__c,
ACV_6__c,
ACV_7__c,
ACV_8__c,
ACV_9__c,
Include_in_ACV_10__c,
Include_in_ACV_11__c,
Include_in_ACV_3__c,
Include_in_ACV_4__c,
Include_in_ACV_5__c,
Include_in_ACV_6__c,
Include_in_ACV_7__c,
Include_in_ACV_8__c,
Include_in_ACV_9__c,
LOAD_Matching_Field__c,
LOAD_Matching_Object__c,
LOAD_Matching_Value__c,
LOAD_Practice_Line__c,
LOAD_Service_Line__c,
Fiscal_Period__c,
Committed_Amount__c,
Committed_Term_Months__c,
Include_in_CCV_1__c,
Include_in_CCV_2__c,
Include_in_CCV_3__c,
Period_Count_Number__c,
Period_Count__c,
Product_Line_Initial_Start_Date__c,
Opportunity_Stage_WF__c,
Stage__c,
Revenue_Schedule_ID_18_Digit__c,
Booked_Amount__c,
Booked_Committed_Amount__c,
WorkFlow_Helper__c,
Update_Timestamp  
FROM (SELECT *, 
ROW_NUMBER() OVER (PARTITION BY revschd_id ORDER BY revschd_id) as rn FROM RevenueSchedule_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

UPDATE [RevenueSchedule]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT revschd_id FROM RevenueSchedule_temp)

UPDATE [RevenueSchedule]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT revschd_id FROM RevenueSchedule_temp)
 
SELECT @a=COUNT(*) FROM RevenueSchedule_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM RevenueSchedule WHERE isharddeleted=0

INSERT INTO u_audit_log
values('RevenueSchedule: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='RevenueSchedule'),@b)

-----------------------RevenueScheduleHistory------------------------


DELETE  FROM RevenueScheduleHistory
WHERE id IN (SELECT rfh_id  FROM RevenueScheduleHistory_check
WHERE CreatedDate<@today)

INSERT INTO RevenueScheduleHistory
(
Id,
IsDeleted,
ParentId,
CreatedById,
CreatedDate,
Field,
OldValue,
NewValue,
Update_Timestamp
)
(SELECT rfh_id,
IsDeleted,
ParentId,
CreatedById,
CreatedDate,
Field,
OldValue,
NewValue,
Update_Timestamp  
FROM (SELECT *, 
ROW_NUMBER() OVER (PARTITION BY rfh_id ORDER BY rfh_id) as rn FROM RevenueScheduleHistory_check 
WHERE CreatedDate<@today) a
where a.rn=1
)


SELECT @a=COUNT(*) FROM RevenueScheduleHistory_check
WHERE CreatedDate<@today

SELECT @b=COUNT(id) FROM RevenueScheduleHistory

INSERT INTO u_audit_log
values('RevenueScheduleHistory: Object updated',1,GETDATE(),@a,
NULL, @b)

-------------------Territory2--------------------
/*
 
DELETE  FROM Territory2
WHERE id IN (SELECT id  FROM Territory2_check
WHERE SystemModstamp<@today)

INSERT INTO Territory2
(
Id,
Name,
Territory2TypeId,
Territory2ModelId,
ParentTerritory2Id,
Description,
AccountAccessLevel,
OpportunityAccessLevel,
CaseAccessLevel,
ContactAccessLevel,
CurrencyIsoCode,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
DeveloperName,
Update_Timestamp
)
(SELECT Id,
Name,
Territory2TypeId,
Territory2ModelId,
ParentTerritory2Id,
Description,
AccountAccessLevel,
OpportunityAccessLevel,
CaseAccessLevel,
ContactAccessLevel,
CurrencyIsoCode,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
DeveloperName,
Update_Timestamp
FROM Territory2_check
WHERE SystemModstamp<@today)

UPDATE [Territory2]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT Id FROM Territory2_temp)

UPDATE [Territory2]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT Id FROM Territory2_temp)

SELECT @a=COUNT(*) FROM Territory2_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Territory2 WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Territory2: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Territory2'),@b)
 */
-------------------User--------------------


DELETE  FROM [User]
WHERE id IN (SELECT [user_id]  FROM User_check
WHERE SystemModstamp<@today
)


INSERT INTO [User]
(
Id,
Username,
LastName,
FirstName,
MiddleName,
Name,
CompanyName,
Division,
Department,
Title,
Street,
City,
State,
PostalCode,
Country,
StateCode,
CountryCode,
Latitude,
Longitude,
GeocodeAccuracy,
Address,
Email,
EmailPreferencesAutoBcc,
EmailPreferencesAutoBccStayInTouch,
EmailPreferencesStayInTouchReminder,
SenderEmail,
SenderName,
Signature,
StayInTouchSubject,
StayInTouchSignature,
StayInTouchNote,
Phone,
Fax,
MobilePhone,
Alias,
CommunityNickname,
BadgeText,
IsActive,
TimeZoneSidKey,
UserRoleId,
LocaleSidKey,
ReceivesInfoEmails,
ReceivesAdminInfoEmails,
EmailEncodingKey,
DefaultCurrencyIsoCode,
CurrencyIsoCode,
ProfileId,
UserType,
LanguageLocaleKey,
EmployeeNumber,
DelegatedApproverId,
ManagerId,
LastLoginDate,
LastPasswordChangeDate,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
OfflineTrialExpirationDate,
OfflinePdaTrialExpirationDate,
UserPermissionsMarketingUser,
UserPermissionsOfflineUser,
UserPermissionsAvantgoUser,
UserPermissionsCallCenterAutoLogin,
UserPermissionsMobileUser,
UserPermissionsSFContentUser,
UserPermissionsKnowledgeUser,
UserPermissionsInteractionUser,
UserPermissionsSupportUser,
ForecastEnabled,
UserPreferencesActivityRemindersPopup,
UserPreferencesEventRemindersCheckboxDefault,
UserPreferencesTaskRemindersCheckboxDefault,
UserPreferencesReminderSoundOff,
UserPreferencesDisableAllFeedsEmail,
UserPreferencesDisableFollowersEmail,
UserPreferencesDisableProfilePostEmail,
UserPreferencesDisableChangeCommentEmail,
UserPreferencesDisableLaterCommentEmail,
UserPreferencesDisProfPostCommentEmail,
UserPreferencesContentNoEmail,
UserPreferencesContentEmailAsAndWhen,
UserPreferencesApexPagesDeveloperMode,
UserPreferencesHideCSNGetChatterMobileTask,
UserPreferencesDisableMentionsPostEmail,
UserPreferencesDisMentionsCommentEmail,
UserPreferencesHideCSNDesktopTask,
UserPreferencesHideChatterOnboardingSplash,
UserPreferencesHideSecondChatterOnboardingSplash,
UserPreferencesDisCommentAfterLikeEmail,
UserPreferencesDisableLikeEmail,
UserPreferencesSortFeedByComment,
UserPreferencesDisableMessageEmail,
UserPreferencesDisableBookmarkEmail,
UserPreferencesDisableSharePostEmail,
UserPreferencesEnableAutoSubForFeeds,
UserPreferencesDisableFileShareNotificationsForApi,
UserPreferencesShowTitleToExternalUsers,
UserPreferencesShowManagerToExternalUsers,
UserPreferencesShowEmailToExternalUsers,
UserPreferencesShowWorkPhoneToExternalUsers,
UserPreferencesShowMobilePhoneToExternalUsers,
UserPreferencesShowFaxToExternalUsers,
UserPreferencesShowStreetAddressToExternalUsers,
UserPreferencesShowCityToExternalUsers,
UserPreferencesShowStateToExternalUsers,
UserPreferencesShowPostalCodeToExternalUsers,
UserPreferencesShowCountryToExternalUsers,
UserPreferencesShowProfilePicToGuestUsers,
UserPreferencesShowTitleToGuestUsers,
UserPreferencesShowCityToGuestUsers,
UserPreferencesShowStateToGuestUsers,
UserPreferencesShowPostalCodeToGuestUsers,
UserPreferencesShowCountryToGuestUsers,
UserPreferencesHideS1BrowserUI,
UserPreferencesDisableEndorsementEmail,
UserPreferencesPathAssistantCollapsed,
UserPreferencesCacheDiagnostics,
UserPreferencesShowEmailToGuestUsers,
UserPreferencesShowManagerToGuestUsers,
UserPreferencesShowWorkPhoneToGuestUsers,
UserPreferencesShowMobilePhoneToGuestUsers,
UserPreferencesShowFaxToGuestUsers,
UserPreferencesShowStreetAddressToGuestUsers,
UserPreferencesLightningExperiencePreferred,
ContactId,
AccountId,
CallCenterId,
Extension,
FederationIdentifier,
AboutMe,
FullPhotoUrl,
SmallPhotoUrl,
DigestFrequency,
DefaultGroupNotificationFrequency,
LastViewedDate,
LastReferencedDate,
BannerPhotoUrl,
IsProfilePhotoActive,
pi__Can_View_Not_Assigned_Prospects__c,
pi__Pardot_Api_Key__c,
pi__Pardot_User_Id__c,
pi__Pardot_User_Key__c,
pi__Pardot_User_Role__c,
ByPassClose_Won_Opportunity__c,
Region__c,
TA_Role__c,
User_ID_18_Digit__c,
Update_Timestamp

)
(SELECT [user_Id],
Username,
LastName,
FirstName,
MiddleName,
Name,
CompanyName,
Division,
Department,
Title,
Street,
City,
State,
PostalCode,
Country,
StateCode,
CountryCode,
Latitude,
Longitude,
GeocodeAccuracy,
Address,
Email,
EmailPreferencesAutoBcc,
EmailPreferencesAutoBccStayInTouch,
EmailPreferencesStayInTouchReminder,
SenderEmail,
SenderName,
Signature,
StayInTouchSubject,
StayInTouchSignature,
StayInTouchNote,
Phone,
Fax,
MobilePhone,
Alias,
CommunityNickname,
BadgeText,
IsActive,
TimeZoneSidKey,
UserRoleId,
LocaleSidKey,
ReceivesInfoEmails,
ReceivesAdminInfoEmails,
EmailEncodingKey,
DefaultCurrencyIsoCode,
CurrencyIsoCode,
ProfileId,
UserType,
LanguageLocaleKey,
EmployeeNumber,
DelegatedApproverId,
ManagerId,
LastLoginDate,
LastPasswordChangeDate,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
OfflineTrialExpirationDate,
OfflinePdaTrialExpirationDate,
UserPermissionsMarketingUser,
UserPermissionsOfflineUser,
UserPermissionsAvantgoUser,
UserPermissionsCallCenterAutoLogin,
UserPermissionsMobileUser,
UserPermissionsSFContentUser,
UserPermissionsKnowledgeUser,
UserPermissionsInteractionUser,
UserPermissionsSupportUser,
ForecastEnabled,
UserPreferencesActivityRemindersPopup,
UserPreferencesEventRemindersCheckboxDefault,
UserPreferencesTaskRemindersCheckboxDefault,
UserPreferencesReminderSoundOff,
UserPreferencesDisableAllFeedsEmail,
UserPreferencesDisableFollowersEmail,
UserPreferencesDisableProfilePostEmail,
UserPreferencesDisableChangeCommentEmail,
UserPreferencesDisableLaterCommentEmail,
UserPreferencesDisProfPostCommentEmail,
UserPreferencesContentNoEmail,
UserPreferencesContentEmailAsAndWhen,
UserPreferencesApexPagesDeveloperMode,
UserPreferencesHideCSNGetChatterMobileTask,
UserPreferencesDisableMentionsPostEmail,
UserPreferencesDisMentionsCommentEmail,
UserPreferencesHideCSNDesktopTask,
UserPreferencesHideChatterOnboardingSplash,
UserPreferencesHideSecondChatterOnboardingSplash,
UserPreferencesDisCommentAfterLikeEmail,
UserPreferencesDisableLikeEmail,
UserPreferencesSortFeedByComment,
UserPreferencesDisableMessageEmail,
UserPreferencesDisableBookmarkEmail,
UserPreferencesDisableSharePostEmail,
UserPreferencesEnableAutoSubForFeeds,
UserPreferencesDisableFileShareNotificationsForApi,
UserPreferencesShowTitleToExternalUsers,
UserPreferencesShowManagerToExternalUsers,
UserPreferencesShowEmailToExternalUsers,
UserPreferencesShowWorkPhoneToExternalUsers,
UserPreferencesShowMobilePhoneToExternalUsers,
UserPreferencesShowFaxToExternalUsers,
UserPreferencesShowStreetAddressToExternalUsers,
UserPreferencesShowCityToExternalUsers,
UserPreferencesShowStateToExternalUsers,
UserPreferencesShowPostalCodeToExternalUsers,
UserPreferencesShowCountryToExternalUsers,
UserPreferencesShowProfilePicToGuestUsers,
UserPreferencesShowTitleToGuestUsers,
UserPreferencesShowCityToGuestUsers,
UserPreferencesShowStateToGuestUsers,
UserPreferencesShowPostalCodeToGuestUsers,
UserPreferencesShowCountryToGuestUsers,
UserPreferencesHideS1BrowserUI,
UserPreferencesDisableEndorsementEmail,
UserPreferencesPathAssistantCollapsed,
UserPreferencesCacheDiagnostics,
UserPreferencesShowEmailToGuestUsers,
UserPreferencesShowManagerToGuestUsers,
UserPreferencesShowWorkPhoneToGuestUsers,
UserPreferencesShowMobilePhoneToGuestUsers,
UserPreferencesShowFaxToGuestUsers,
UserPreferencesShowStreetAddressToGuestUsers,
UserPreferencesLightningExperiencePreferred,
ContactId,
AccountId,
CallCenterId,
Extension,
FederationIdentifier,
AboutMe,
FullPhotoUrl,
SmallPhotoUrl,
DigestFrequency,
DefaultGroupNotificationFrequency,
LastViewedDate,
LastReferencedDate,
BannerPhotoUrl,
IsProfilePhotoActive,
pi__Can_View_Not_Assigned_Prospects__c,
pi__Pardot_Api_Key__c,
pi__Pardot_User_Id__c,
pi__Pardot_User_Key__c,
pi__Pardot_User_Role__c,
ByPassClose_Won_Opportunity__c,
Region__c,
TA_Role__c,
User_ID_18_Digit__c,
Update_Timestamp 
FROM (SELECT *, 
ROW_NUMBER() OVER (PARTITION BY [user_Id] ORDER BY [user_Id]) as rn FROM User_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)


 
UPDATE [User]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT user_id FROM User_temp)

UPDATE [User]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT user_id FROM User_temp)
 
SELECT @a=COUNT(*) FROM User_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM [User] WHERE isharddeleted=0

INSERT INTO u_audit_log
values('User: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='User'),@b)



-------------------UserRole--------------------

DECLARE @z INT=(SELECT COUNT(userrole_id)  FROM UserRole_check 
WHERE SystemModstamp BETWEEN (SELECT DATEADD(dd,-1,@today))AND @today)
IF(@z<>0)
BEGIN
INSERT INTO u_audit_log
values('UserRole: Warning - User Role Changes Detected',0,GETDATE(),NULL,NULL,NULL)

EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'VSASQLSTG01',
    @recipients = 'angad@forecastera.com; himanshu.kohli@virtustream.com; rajat.gupta@virtustream.com',
    @subject = 'VS Sales BI Project: Live Env. Warning - User Role Changes Detected',
    @body = 'There have been changes or additions to the current set of User Roles. Please confirm and make appropriate changes to the Role Heirarchy Data.';

END


DELETE  FROM UserRole
WHERE id IN (SELECT userrole_id  FROM UserRole_check
WHERE SystemModstamp<@today)

INSERT INTO UserRole
(
Id,
Name,
ParentRoleId,
RollupDescription,
OpportunityAccessForAccountOwner,
CaseAccessForAccountOwner,
ContactAccessForAccountOwner,
ForecastUserId,
MayForecastManagerShare,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
DeveloperName,
PortalAccountId,
PortalType,
PortalAccountOwnerId,
Update_Timestamp
)
(SELECT userrole_id,
Name,
ParentRoleId,
RollupDescription,
OpportunityAccessForAccountOwner,
CaseAccessForAccountOwner,
ContactAccessForAccountOwner,
ForecastUserId,
MayForecastManagerShare,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
DeveloperName,
PortalAccountId,
PortalType,
PortalAccountOwnerId,
Update_Timestamp  
FROM (SELECT *, 
ROW_NUMBER() OVER (PARTITION BY userrole_id ORDER BY userrole_id) as rn FROM UserRole_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

 
UPDATE [UserRole]
SET IsHardDeleted=1
WHERE Id NOT IN (SELECT userrole_id FROM UserRole_temp)

UPDATE [UserRole]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT userrole_id FROM UserRole_temp)
 
SELECT @a=COUNT(*) FROM UserRole_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM UserRole WHERE isharddeleted=0


INSERT INTO u_audit_log
values('UserRole: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='UserRole'),@b)



-------------------Fiscal_Period__c--------------------

DELETE  FROM Fiscal_Period__c
WHERE id IN (SELECT fp_id  FROM Fiscal_Period__c_check
WHERE SystemModstamp<@today)


INSERT INTO Fiscal_Period__c
(
Id,
OwnerId,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastViewedDate,
LastReferencedDate,
End_Date__c,
Fiscal_Quarter__c,
Mid_of_Month__c,
Start_Date__c,
Update_Timestamp
)
(SELECT fp_id,
OwnerId,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastViewedDate,
LastReferencedDate,
End_Date__c,
Fiscal_Quarter__c,
Mid_of_Month__c,
Start_Date__c,
Update_Timestamp
FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY fp_id ORDER BY fp_id) as rn FROM Fiscal_Period__c_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

UPDATE [Fiscal_Period__c]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT fp_id FROM Fiscal_Period_temp)

UPDATE [Fiscal_Period__c]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT fp_id FROM Fiscal_Period_temp)
 

  SELECT @a=COUNT(*) FROM Fiscal_Period__c_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Fiscal_Period__c WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Fiscal_Period__c: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Fiscal_Period__c'),@b)

-------------------CurrencyType--------------------


DELETE  FROM CurrencyType
WHERE id IN (SELECT curr_id  FROM CurrencyType_check
WHERE SystemModstamp<@today)


INSERT INTO CurrencyType
(
Id,
IsoCode,
ConversionRate,
DecimalPlaces,
IsActive,
IsCorporate,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
Update_Timestamp
)
(SELECT curr_id,
IsoCode,
ConversionRate,
DecimalPlaces,
IsActive,
IsCorporate,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
Update_Timestamp 
FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY curr_id ORDER BY curr_id) as rn FROM CurrencyType_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

UPDATE [CurrencyType]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT curr_id FROM CurrencyType_temp)

UPDATE [CurrencyType]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT curr_id FROM CurrencyType_temp)
 
  SELECT @a=COUNT(*) FROM CurrencyType_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM CurrencyType WHERE isharddeleted=0

INSERT INTO u_audit_log
values('CurrencyType: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='CurrencyType'),@b)

-----------------------Sales_Credit_Detail--------------------------

DELETE  FROM Sales_Credit_Detail
WHERE id IN (SELECT sc_id  FROM Sales_Credit_Detail_check
WHERE SystemModstamp<@today)

INSERT INTO Sales_Credit_Detail
(
Id,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
Sales_Credit__c,
Product_Line__c,
Booked_ACV_Year_1__c,
Booked_Amount__c,
Booked_CCV__c,
Booked_TCV__c,
Committed_Term__c,
Credit_Percentage__c,
Employee_Number__c,
Opportunity_Number__c,
Opportunity__c,
Practice_Line__c,
Product_Line_Name__c,
Quant_Segment__c,
Sales_Credit_Group__c,
Service_Line__c,
Team_Member__c,
Team_Role__c,
Update_Timestamp

)
(SELECT sc_id,
IsDeleted,
Name,
CurrencyIsoCode,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
LastActivityDate,
Sales_Credit__c,
Product_Line__c,
Booked_ACV_Year_1__c,
Booked_Amount__c,
Booked_CCV__c,
Booked_TCV__c,
Committed_Term__c,
Credit_Percentage__c,
Employee_Number__c,
Opportunity_Number__c,
Opportunity__c,
Practice_Line__c,
Product_Line_Name__c,
Quant_Segment__c,
Sales_Credit_Group__c,
Service_Line__c,
Team_Member__c,
Team_Role__c,
Update_Timestamp 
FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY sc_id ORDER BY sc_id) as rn FROM Sales_Credit_Detail_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

 
UPDATE [Sales_Credit_Detail]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT sc_id FROM Sales_Credit_Detail_temp)

UPDATE [Sales_Credit_Detail]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT sc_id FROM Sales_Credit_Detail_temp)
 
  SELECT @a=COUNT(*) FROM Sales_Credit_Detail_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Sales_Credit_Detail WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Sales_Credit_Detail: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Sales_Credit_Detail'),@b)


----------------------------------Task--------------------------------

DELETE  FROM Task
WHERE id IN (SELECT task_id  FROM Task_check
WHERE SystemModstamp<@today)

INSERT INTO Task
(Id,
WhoId,
WhatId,
WhoCount,
WhatCount,
Subject,
ActivityDate,
Status,
Priority,
IsHighPriority,
OwnerId,
Description,
CurrencyIsoCode,
IsDeleted,
AccountId,
IsClosed,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsArchived,
CallDurationInSeconds,
CallType,
CallDisposition,
CallObject,
ReminderDateTime,
IsReminderSet,
RecurrenceActivityId,
IsRecurrence,
RecurrenceStartDateOnly,
RecurrenceEndDateOnly,
RecurrenceTimeZoneSidKey,
RecurrenceType,
RecurrenceInterval,
RecurrenceDayOfWeekMask,
RecurrenceDayOfMonth,
RecurrenceInstance,
RecurrenceMonthOfYear,
RecurrenceRegeneratedType,
TaskSubtype,
Update_Timestamp
)
(SELECT task_id,
WhoId,
WhatId,
WhoCount,
WhatCount,
Subject,
ActivityDate,
Status,
Priority,
IsHighPriority,
OwnerId,
Description,
CurrencyIsoCode,
IsDeleted,
AccountId,
IsClosed,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsArchived,
CallDurationInSeconds,
CallType,
CallDisposition,
CallObject,
ReminderDateTime,
IsReminderSet,
RecurrenceActivityId,
IsRecurrence,
RecurrenceStartDateOnly,
RecurrenceEndDateOnly,
RecurrenceTimeZoneSidKey,
RecurrenceType,
RecurrenceInterval,
RecurrenceDayOfWeekMask,
RecurrenceDayOfMonth,
RecurrenceInstance,
RecurrenceMonthOfYear,
RecurrenceRegeneratedType,
TaskSubtype,
Update_Timestamp
FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY task_id ORDER BY task_id) as rn FROM Task_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)
 
 
UPDATE [Task]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT task_id FROM Task_temp)

UPDATE [Task]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT task_id FROM Task_temp)
 
  SELECT @a=COUNT(*) FROM Task_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM Task WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Task: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Task'),@b)

----------------------------------Event--------------------------------

DELETE  FROM Event
WHERE id IN (SELECT event_id  FROM Event_check
WHERE SystemModstamp<@today)

INSERT INTO [Event]
(Id,
WhoId,
WhatId,
WhoCount,
WhatCount,
Subject,
Location,
ActivityDateTime,
ActivityDate,
DurationInMinutes,
StartDateTime,
EndDateTime,
Description,
AccountId,
OwnerId,
CurrencyIsoCode,
Type,
IsPrivate,
ShowAs,
IsDeleted,
IsChild,
IsGroupEvent,
GroupEventType,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsArchived,
RecurrenceActivityId,
IsRecurrence,
RecurrenceStartDateTime,
RecurrenceEndDateOnly,
RecurrenceTimeZoneSidKey,
RecurrenceType,
RecurrenceInterval,
RecurrenceDayOfWeekMask,
RecurrenceDayOfMonth,
RecurrenceInstance,
RecurrenceMonthOfYear,
ReminderDateTime,
IsReminderSet,
EventSubtype,
Update_Timestamp

)
(SELECT event_id,
WhoId,
WhatId,
WhoCount,
WhatCount,
Subject,
Location,
ActivityDateTime,
ActivityDate,
DurationInMinutes,
StartDateTime,
EndDateTime,
Description,
AccountId,
OwnerId,
CurrencyIsoCode,
Type,
IsPrivate,
ShowAs,
IsDeleted,
IsChild,
IsGroupEvent,
GroupEventType,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsArchived,
RecurrenceActivityId,
IsRecurrence,
RecurrenceStartDateTime,
RecurrenceEndDateOnly,
RecurrenceTimeZoneSidKey,
RecurrenceType,
RecurrenceInterval,
RecurrenceDayOfWeekMask,
RecurrenceDayOfMonth,
RecurrenceInstance,
RecurrenceMonthOfYear,
ReminderDateTime,
IsReminderSet,
EventSubtype,
Update_Timestamp
FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY event_id) as rn FROM Event_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

 
UPDATE [Event]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT event_id FROM Event_temp)

UPDATE [Event]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT event_id FROM Event_temp)
 
 SELECT @a=COUNT(*) FROM Event_check
WHERE SystemModstamp<@today

SELECT @b=COUNT(id) FROM [Event] WHERE isharddeleted=0

INSERT INTO u_audit_log
values('Event: Object updated',1,GETDATE(),@a,
(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='Event'),@b)


----------------------------OpportunityContactRole-------------------------

DELETE  FROM [OpportunityContactRole]
WHERE id IN (SELECT ocr_id  FROM OpportunityContactRole_check
WHERE SystemModstamp<@today)

INSERT INTO [OpportunityContactRole]
(
Id,
OpportunityId,
ContactId,
Role,
IsPrimary,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsDeleted,
Update_Timestamp
)
(SELECT ocr_id,
OpportunityId,
ContactId,
Role,
IsPrimary,
CreatedDate,
CreatedById,
LastModifiedDate,
LastModifiedById,
SystemModstamp,
IsDeleted,
Update_Timestamp
FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY ocr_id ORDER BY ocr_id) as rn FROM OpportunityContactRole_check 
WHERE SystemModstamp<@today) a
where a.rn=1
)

 
UPDATE [OpportunityContactRole]
SET IsHardDeleted=1
WHERE Id NOT IN ( SELECT ocr_id FROM OpportunityContactRole_temp)

UPDATE [OpportunityContactRole]
SET IsHardDeleted=0
WHERE Id  IN ( SELECT ocr_id FROM OpportunityContactRole_temp)
 
		  SELECT @a=COUNT(*) FROM OpportunityContactRole_check
		WHERE SystemModstamp<@today

		SELECT @b=COUNT(id) FROM [OpportunityContactRole] WHERE isharddeleted=0

		INSERT INTO u_audit_log
		values('OpportunityContactRole: Object updated',1,GETDATE(),@a,
		(SELECT TOP 1 Row_Count FROM Row_Count WHERE ObjectName='OpportunityContactRole'),@b)

	INSERT INTO u_audit_log
	values('Import Completed',1,GETDATE(),NULL,NULL,NULL)
END


