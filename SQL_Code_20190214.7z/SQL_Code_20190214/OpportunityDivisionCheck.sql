SELECT DISTINCT p.opp_Name, p.m3_role_name , o.[person region] FROM Product_Line_Snapshot p LEFT JOIN 
(SELECT * FROM OutboundReportPreview
WHERE fiscal_quarter='2019 Q3' AND version=2) o
ON p.user_employeenumber=o.employee_id
where p.snapshot_type='DAY 01' AND p.field_source='SFDC'  AND
(p.opp_stagename LIKE '75%' OR
p.opp_stagename LIKE '90%' OR
p.opp_stagename LIKE '99%' OR
p.opp_stagename LIKE '100%')
AND p.opp_close_fiscal_quarter='2019 Q3'


--SELECT DISTINCT fiscal_quarter, version from OutboundReportPreview