CREATE VIEW v_Cust_qtr
AS 



WITH fiscal_quarter_rank as
(SELECT [fiscal_qtr], CAST(MIN(date) as date) as [start_date], 
CASE WHEN fiscal_qtr=(SELECT fiscal_qtr FROM [dbo].[FiscalQuarters] WHERE [date]=(CAST(getdate() AS DATE)))
THEN CAST(getdate() AS DATE)
ELSE CAST(MAX(date) as date) END as end_date 
, substring(fiscal_qtr,1,4) as fiscal_year,
row_number() over (order by [fiscal_qtr]) as rank
FROM [dbo].[FiscalQuarters]
	GROUP BY [fiscal_qtr]),
	start_quarter as (SELECT fiscal_qtr from fiscal_quarter_rank
	WHERE rank=(SELECT rank-10 from fiscal_quarter_rank WHERE fiscal_qtr=
	(SELECT fiscal_qtr FROM [dbo].[FiscalQuarters] WHERE [date]=(CAST(getdate() AS DATE))))),
	end_quarter as (SELECT fiscal_qtr from fiscal_quarter_rank
	WHERE rank=(SELECT rank+9 from fiscal_quarter_rank 
	WHERE fiscal_qtr=(SELECT fiscal_qtr FROM [dbo].[FiscalQuarters] 
	WHERE [date]=(CAST(getdate() AS DATE)))))


	
SELECT *, CASE 
		WHEN (stagename like '99%' or stagename like '100%') 
		AND fiscal_qtr>=fiscalquarter
		and end_date < opp_revenue_end_date__c
		then 1
		else 0
		END
	 as active_revenue_flag,
	 
	  CASE 
		WHEN 
		stagename not like '0%' and stagename not like '99%' 
		and stagename not like '100%' 
		and fiscalquarter=fiscal_qtr
		THEN 1
		ELSE 0
		END
	 as cq_new_logo_pipeline_flag,
	 (SELECT MIN([start_date]) FROM
		fiscal_quarter_rank where fiscal_year=
		(SELECT fiscal_year from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr)) as cy_start_date,
	 (SELECT [start_date] FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-1 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr)) as stlq_start_date,
	(SELECT end_date FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-1 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr)) as stlq_end_date,
	(SELECT [start_date] FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-4 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr)) as stly_start_date,
	(SELECT end_date FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-4 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr)) as stly_end_date,
	CASE WHEN 
		(stagename like '99%' or stagename like '100%') 
		AND opp_closedate<=(SELECT end_date FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-1 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr))
		and 
		(SELECT end_date FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-1 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr))< opp_revenue_end_date__c
		then 1
		else 0
		end
	 as stlq_active_revenue_flag,
		CASE WHEN 
		(stagename like '99%' or stagename like '100%') 
		AND opp_closedate<=(SELECT end_date FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-4 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr))
		and 
		(SELECT end_date FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-4 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr))< opp_revenue_end_date__c
		then 1
		else 0
		end
	 as stly_active_revenue_flag,
	  CASE 
		WHEN 
		(stagename like '99%' or stagename like '100%') 
		and  fiscalquarter=fiscal_qtr
		THEN 1
		ELSE 0
		END
	 as new_logo_flag,
	 CASE WHEN (stagename like '99%' or stagename like '100%') 
		 and 
	(SELECT  distinct substring(fiscal_qtr,1,4) from fiscalquarters
	 WHERE date=opp_closedate)=fiscal_year
		then 1
		else 0
		end
	 as cy_new_logo_flag,
	 CASE 
		when 
		(stagename like '99%' or stagename like '100%') 
		and
		fiscalquarter=(SELECT fiscal_qtr FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-1 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr))
		

		then 1
		else 0
		end
	 as stlq_new_logo_flag,

	  CASE 
		when 
		(stagename like '99%' or stagename like '100%') 
		and
		fiscalquarter=(SELECT fiscal_qtr FROM
		fiscal_quarter_rank where rank=
		(SELECT rank-4 from fiscal_quarter_rank  f
	WHERE f.fiscal_qtr=a.fiscal_qtr))
		
		then 1
		else 0
		end as stly_new_logo_flag
	  FROM
(SELECT fiscal_qtr, CAST(MIN(date) as date) as [start_date], 
CASE WHEN fiscal_qtr=(SELECT fiscal_qtr FROM [dbo].[FiscalQuarters] WHERE [date]=(CAST(getdate() AS DATE)))
THEN CAST(getdate() AS DATE) ELSE CAST(MAX(date) as date) END as end_date,
 substring(fiscal_qtr,1,4) as fiscal_year
FROM FiscalQuarters
where fiscal_qtr BETWEEN (SELECT fiscal_qtr FROM start_quarter) 
AND (SELECT fiscal_qtr FROM end_quarter) 
GROUP BY fiscal_qtr) a 

CROSS JOIN 
	(SELECT  opphead.acc_id as account_id,
	opphead.acc_name as account_name,
	opphead.acc_billingcountry as account_billingcountry,
	opphead.acc_billingcity as account_billingcity,
	opphead.acc_segment as account_segment,
	opphead.acc_ownername as account_ownername,
	opphead.user_name as user_name,
	opphead.acc_theater__c as account_theatre,
	opphead.acc_vertical__c as account_vertical,
	opphead.opp_theater__c as opp_theatre, 
	opphead.opp_segment__c  opp_segment,
	opphead.acc_dell_emc_segment__c as account_dell_emc_segment,
	opphead.acc_managername as managername,
	(SELECT MIN(opp_closedate) from opportunity_header
	WHERE acc_id=opphead.acc_id and 
	(opp_stagename like '99%' or opp_stagename like '100%')) as customer_since,
	(SELECT MAX(primarycontactid) from opportunity_header WHERE acc_id=opphead.acc_id) as primarycontact,

	(SELECT sum(revschd_forecast_amount__c) FROM [dbo].[Revenue_Schedule_Detail]
	 WHERE valid_flag=1 AND (stage__c like '100%' or stage__c like '99%') AND
	SUBSTRING(revschd_fiscal_period__c,4,4)=(SELECT  SUBSTRING(fiscal_qtr,1,4) from [dbo].[FiscalQuarters]
	WHERE date=(SELECT getdate())) and pl_id=revsc.pl_id) as annual_revenue,

	opphead.opp_id as opp_id,
	opphead.opp_stagename as stagename,
	opphead.opp_close_fiscal_quarter as fiscalquarter,

	opphead.opp_name as opp_name,
	revsc.lob as lob,

	stuff((SELECT ','+ lob from (SELECT distinct o.opp_id ,
	rev.lob from opportunity_header o
	LEFT JOIN
	(SELECT pl_id, 
	MAX(product_quant_practice_group__c) as lob,
	max(pl_opportunity__c) as pl_opportunity__c FROM revenue_schedule_detail
	WHERE  valid_flag=1 group by pl_id) rev
	on o.opp_id=rev.pl_opportunity__c
	) m
	WHERE m.opp_id=opphead.opp_id
	FOR XML PATH (''), type).value('.','nvarchar(max)'),1,1,'')
	as lob_concat,

	revsc.pl_id as pl_id,
	revsc.pl_annual_contact_value_year_1__c as pl_annual_contact_value_year_1__c,
	revsc.pl_committed_contract_value__c as pl_committed_contract_value__c,
	CASE WHEN pl_id IS NOT NULL THEN revsc.pl_total_contract_value__c 
	ELSE opphead.opp_amount
	END as pl_total_contract_value__c,

	CAST(opphead.opp_closedate as DATE) as opp_closedate,

	CASE WHEN (opphead.opp_stagename like '0%' or opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%')
	THEN 
		CASE 
			WHEN  opphead.opp_createddate> opphead.opp_closedate
			THEN 0
			ELSE DATEDIFF(WEEK, opphead.opp_createddate, opphead.opp_closedate)
		END
	ELSE 
		DATEDIFF(WEEK, opphead.opp_createddate, GETDATE()) 
	END as deal_age,
	opphead.opp_heat_map__c as opp_heatmap,
	SUBSTRING(opphead.opp_stagename,1,CHARINDEX('%', opphead.opp_stagename)) as probability,

	(SELECT CAST(MAX([date]) as DATE) FROM [FiscalQuarters]
	WHERE Fiscal_Period=rev_start.Fiscal_Period)
	as opp_revenue_start_date__c,

	(SELECT CAST(MAX([date]) as DATE) FROM [FiscalQuarters]
	WHERE Fiscal_Period=rev_end.Fiscal_Period)
	
	 as opp_revenue_end_date__c,

	(SELECT MAX(a.fiscal_period)  FROM [dbo].[FiscalQuarters] a
	WHERE a.date=CAST(GETDATE() as date)) as current_fiscal_period,

 
	opphead.opp_competitor__c as opp_competitor__c,
	opphead.opp_loss_reason__c as opp_loss_reason__c,
	opphead.lost_from_stage as lost_from_stage,
	revsc.pl_booked_amount__c as booked_amount_with_override,
	 revsc.revschd_actual__c as revschd_actual__c,
	 revsc.revschd_projection__c as revschd_projection__c,

	 (SELECT CAST(getdate() AS DATE)) as [current_date],

	 CASE WHEN revschd_count<>0 THEN 1
	 ELSE 0
	 END as revschd_flag
	from opportunity_header opphead
	
	--LEFT JOIN ProductLine pl ON opphead.opp_id=pl.opportunity__c
	--LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN
	(SELECT pl_id, max(pl_annual_contact_value_year_1__c) as pl_annual_contact_value_year_1__c,
	max(pl_committed_contract_value__c) as pl_committed_contract_value__c,
	max(pl_total_contract_value__c) as pl_total_contract_value__c,
	MAX(product_quant_practice_group__c) as lob,
	SUM(revschd_booked_amount_final) as pl_booked_amount__c,
	max(pl_opportunity__c) as pl_opportunity__c, max(stage__c) as stage__c,
	sum(revschd_actual__c) as revschd_actual__c,
	sum(revschd_projection__c) as revschd_projection__c,
	count(*) as revschd_count
	FROM revenue_schedule_detail
	WHERE  valid_flag=1 group by pl_id) revsc
	on opphead.opp_id=revsc.pl_opportunity__c
	LEFT JOIN
	(SELECT o.opp_id,fp.fiscal_period FROM FiscalQuarters fp JOIN (SELECT pl_opportunity__c as opp_id, MIN(period__c) as min_period
	from revenue_schedule_detail WHERE valid_flag=1
	GROUP BY pl_opportunity__c) o 
	ON fp.date=o.min_period) rev_start
	ON opphead.opp_id=rev_start.opp_id
	LEFT JOIN
	(SELECT o.opp_id,fp.fiscal_period FROM FiscalQuarters fp JOIN (SELECT pl_opportunity__c as opp_id, 
	MAX(period__c) as max_period
	from revenue_schedule_detail WHERE valid_flag=1
	GROUP BY pl_opportunity__c) o 
	ON fp.date=o.max_period) rev_end
	ON opphead.opp_id=rev_end.opp_id
	WHERE ISNULL(revsc.lob,'a')<>'Managed Services')
 b
 
 



--SELECT * FROM v_Cust_qtr
--where fiscal_qtr='2019 Q4'