/** 

It drops and re-create all the tables required for Marketing dashboards

**/

CREATE PROCEDURE [dbo].[sp_Marketing]

AS
BEGIN

IF  EXISTS(SELECT [name] FROM sys.tables WHERE [name]='CampaignPipeline_Channel')
DROP TABLE [dbo].[CampaignPipeline_Channel]


SELECT cam.Name as CampaignName,o.Id as oppurtunityId,Co.Email,cam.Type as CampaigType,
HasResponded,o.name as oppurtunityName,StageName,
Lead_Partner_Type__c,IsClosed,ac.type as AccountType,co.name as ContactName,
o.Type as OppType,ac.Name as AccountName,o.AccountId as AccountID,co.Id as ContactID,
o.CloseDate as oppCloseDate,ocr.Role as ROle,cm.CreatedDate as CampaignCreatedDate,
sum(Total_Contract_Value__c)/sum(ct.ConversionRate) as tcv 

INTO

 CampaignPipeline_Channel from Campaign cam
join CampaignMember cm on cam.id=cm.CampaignId
join contact co on co.Id=cm.ContactId
join account ac on ac.Id=co.AccountId
join Opportunity o on o.AccountId=ac.Id
join OpportunityContactRole ocr on ocr.OpportunityId=o.id and ocr.ContactId=co.Id
join CurrencyType ct on ct.IsoCode=o.CurrencyIsoCode
Where( (HasResponded=1 and StageName not in('0% Lost (Closed/Lost)') and o.Type not in('Renewal')
and (Lead_Partner_Type__c is not null or co.Email  like '%@sap.com%' or co.email  like '%@ey.com%'
or co.email  like '%@emc.com%' or co.email  like '%@dell.com%'
 or co.email  like '%virtustream.com%'
or co.email  like '%sapns2.com%')) and IsClosed <>1)

 group by cam.Name,Co.Email,cam.Type ,HasResponded,o.name,StageName,Lead_Partner_Type__c,
 IsClosed,ac.type,o.Id ,ac.type,co.name,o.Type,ac.Name,o.AccountId,o.CloseDate,co.id,ocr.role,cm.CreatedDate

 ----------------------------------------------------------------------------------------------

 IF  EXISTS(SELECT name FROM sys.tables WHERE name='u_CampaignMember')
DROP TABLE [dbo].[u_CampaignMember] 


SELECT c.name as campaignname,a.CreatedDate,c.Type as campaigntype,u.name as LeadOwner,
SUBSTRING(fiscal_qtr, 1, 4) as Year,
SUBSTRING(fiscal_qtr, 5, 3) as Quarter,
a.LeadOrContactOwnerId,
[Fiscal_Period] as FiscalPeriod,
sum(a.contact) as Contact,
Sum(a.Lead) as lead
 INTO [u_CampaignMember] from  (Select  CampaignID, LeadOrContactOwnerId,

 Sum(CASE WHEN TYPE='Contact' THEN 1 ELSE 0 END) as Contact, 
Sum(CASE WHEN TYPE='Lead' THEN 1 ELSE 0 END) as Lead ,cast(CreatedDate as date) createdDate from CampaignMember 

cm
group by Campaignid, LeadOrContactOwnerId, CAST(CreatedDate as Date)) a join Campaign c on a.CampaignId=c.Id
left join [User] u on a.LeadOrContactOwnerId= u.Id
join FiscalQuarters fq on cast(a.CreatedDate as date)=cast(fq.date as date)
group by a.LeadOrContactOwnerId, c.name,a.CreatedDate,c.Type,u.name ,SUBSTRING(fiscal_qtr, 1, 4),SUBSTRING

(fiscal_qtr, 5, 3),[Fiscal_Period]
--------------------------------------------------------------------------------------------
IF  EXISTS(SELECT name FROM sys.tables WHERE name='CampaignPipeline_Prospect')
DROP TABLE [dbo].[CampaignPipeline_Prospect]


SELECT cam.Name as CampaignName,o.Id as oppurtunityId,Co.Email,cam.Type as CampaigType,
HasResponded,o.name as oppurtunityName,StageName,
Lead_Partner_Type__c,IsClosed,ac.type as AccountType,co.name as ContactName,
o.Type as OppType,ac.Name as AccountName,o.AccountId as AccountID,co.Id as ContactID,
o.CloseDate as oppCloseDate,ocr.Role as ROle,cm.CreatedDate as CampaignCreatedDate,

sum(Total_Contract_Value__c)/sum(ct.ConversionRate) as tcv
into CampaignPipeline_Prospect from Campaign cam
join CampaignMember cm on cam.id=cm.CampaignId
join contact co on co.Id=cm.ContactId
join account ac on ac.Id=co.AccountId
join Opportunity o on o.AccountId=ac.Id
join OpportunityContactRole ocr on ocr.OpportunityId=o.id and ocr.ContactId=co.Id
join CurrencyType ct on ct.IsoCode=o.CurrencyIsoCode

 group by cam.Name,Co.Email,cam.Type ,HasResponded,o.name,StageName,Lead_Partner_Type__c,
 IsClosed,ac.type,o.Id ,ac.type,co.name,o.Type,ac.Name,o.AccountId,
 o.CloseDate,co.id,ocr.role,cm.CreatedDate

 -------------------------------------------------------------------------------------------------
IF  EXISTS(SELECT name FROM sys.tables WHERE name='LeadActivity')
DROP TABLE [dbo].[LeadActivity]

SELECT a.Status as LeadStatus,
a.id as leadid,
ta.Subject as Subject,
ta.ActivityDate as Date,
ta.Status as Status,
ta.LastModifiedDate as lastModifiedDate,
ta.TaskSubtype as TaskSubtype,
a.FirstName as FirstName,
a.LastName as lastName,
a.Email as Email,
u.Name as AssignedName,
'Task' as Type,

SUBSTRING(fiscal_qtr, 1, 4) as Year,
SUBSTRING(fiscal_qtr, 5, 3) as Quarter,
SUBSTRING(Fiscal_Period, 9,9) as FiscalPeriod


INTO LeadActivity


 FROM Lead a
 LEFT JOIN Task ta on a.id= ta.WhoId
 
 LEFT JOIN [User] u on ta.OwnerId=u.Id
 INNER JOIN FiscalQuarters fq on cast(ta.ActivityDate as date)=cast(fq.date as date)
 UNION

 SELECT a.Status as LeadStatus,
 a.id as leadid,
ta.Subject as Subject,
ta.ActivityDate as Date,
case when cast(ta.LastModifiedDate as date)> cast(GETDATE() as date) then 'Completed' else 'Open' end as 

Status,
ta.LastModifiedDate as lastModifiedDate,
ta.EventSubtype as TaskSubtype,
a.FirstName as FirstName,
a.LastName as lastName,
a.Email as Email,

u.Name as AssignedName,
'Event' as Type,
SUBSTRING(fiscal_qtr, 1, 4) as Year,
SUBSTRING(fiscal_qtr, 5, 3) as Quarter,
SUBSTRING(Fiscal_Period, 9, 9) as FiscalPeriod

 FROM Lead a
 LEFT JOIN Event ta on a.id= ta.WhoId
 LEFT JOIN FiscalQuarters fq on cast(ta.LastModifiedDate as date)=cast(fq.date as date)
 INNER JOIN [User] u on ta.OwnerId=u.Id

END


 

 