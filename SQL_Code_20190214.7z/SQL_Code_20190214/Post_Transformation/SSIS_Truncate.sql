/**

Truncates the date in all the Production tables before moving the updated data from 
VSASQLSTG01 to VSASQLPRD01

**/


ALTER PROCEDURE [dbo].[trunc_tables]
AS BEGIN
--TRUNCATE TABLE [dbo].[u_PLS_wRollover_Waterfall]
--TRUNCATE TABLE [dbo].[Revenue_Schedule_Snapshot]
--TRUNCATE TABLE [dbo].[Latest_PLS_Totals]
TRUNCATE TABLE [dbo].[Product_Line_Snapshot]
TRUNCATE TABLE [dbo].[Product_Line_Snapshot_Totals]
--TRUNCATE TABLE [dbo].[Product_Line_Snapshot_Totals_With_Rollover]
TRUNCATE TABLE [dbo].[RolloverBookings_Data]
TRUNCATE TABLE [dbo].[Opportunity_Header]
TRUNCATE TABLE [dbo].[u_audit_log]
--TRUNCATE TABLE [dbo].[Executive_Por_data]
TRUNCATE TABLE [dbo].[FiscalQuarters]
TRUNCATE TABLE [dbo].[POR_Data]
TRUNCATE TABLE [dbo].[Quota_Data]
TRUNCATE TABLE [dbo].[Revenue_Schedule_Detail]
TRUNCATE TABLE [dbo].[u_Account]
TRUNCATE TABLE [dbo].[u_Customer]
TRUNCATE TABLE [dbo].[u_Dell_EMC_POR_Data]
TRUNCATE TABLE [dbo].[User Role Based Hierarchy]
--TRUNCATE TABLE [dbo].[u_googleanalytics]
TRUNCATE TABLE [dbo].[f_partner_classification]
END

ALTER PROCEDURE [dbo].[trunc_marketing_tables]
AS 
BEGIN
--TRUNCATE TABLE [dbo].[u_CampaignMember]
TRUNCATE TABLE [dbo].[CampaignPipeline_Prospect]
TRUNCATE TABLE [dbo].[LeadActivity]
TRUNCATE TABLE [dbo].[CampaignPipeline_Channel]

TRUNCATE TABLE [dbo].[gad_ad_performance_report]
TRUNCATE TABLE [dbo].[gad_campaign_performance_report]
TRUNCATE TABLE [dbo].[gad_keywords_performance_report]
TRUNCATE TABLE [dbo].[gad_video_performance_report]

END


----------UAT-------------------

ALTER PROCEDURE [dbo].[trunc_tables]
AS BEGIN
--TRUNCATE TABLE [dbo].[u_PLS_wRollover_Waterfall]
TRUNCATE TABLE [dbo].[Revenue_Schedule_Snapshot]
--TRUNCATE TABLE [dbo].[Latest_PLS_Totals]
TRUNCATE TABLE [dbo].[Product_Line_Snapshot]
TRUNCATE TABLE [dbo].[Product_Line_Snapshot_Totals]
TRUNCATE TABLE [dbo].[Product_Line_Snapshot_Totals_With_Rollover]
TRUNCATE TABLE [dbo].[RolloverBookings_Data]
TRUNCATE TABLE [dbo].[Opportunity_Header]
TRUNCATE TABLE [dbo].[u_audit_log]
--TRUNCATE TABLE [dbo].[Executive_Por_data]
TRUNCATE TABLE [dbo].[FiscalQuarters]
TRUNCATE TABLE [dbo].[POR_Data]
TRUNCATE TABLE [dbo].[Quota_Data]
TRUNCATE TABLE [dbo].[Revenue_Schedule_Detail]
TRUNCATE TABLE [dbo].[u_Account]
TRUNCATE TABLE [dbo].[u_Customer]
TRUNCATE TABLE [dbo].[u_Dell_EMC_POR_Data]
TRUNCATE TABLE [dbo].[User Role Based Hierarchy]
--TRUNCATE TABLE [dbo].[u_googleanalytics]
TRUNCATE TABLE [dbo].[f_partner_classification]

--TRUNCATE TABLE [dbo].[u_CampaignMember]
TRUNCATE TABLE [dbo].[CampaignPipeline_Prospect]
TRUNCATE TABLE [dbo].[LeadActivity]
TRUNCATE TABLE [dbo].[CampaignPipeline_Channel]

/*TRUNCATE TABLE [dbo].[gad_ad_performance_report]
TRUNCATE TABLE [dbo].[gad_campaign_performance_report]
TRUNCATE TABLE [dbo].[gad_keywords_performance_report]
TRUNCATE TABLE [dbo].[gad_video_performance_report]
*/
END


