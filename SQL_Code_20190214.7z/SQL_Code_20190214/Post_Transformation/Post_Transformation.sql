/**

Triggers SSIS job that moves the data from Staging to Production, and insert an entry in Audit table
to mark completion of Production Movement.

**/
CREATE PROCEDURE [dbo].[post_transformation]
AS
BEGIN
	
DECLARE @pass INT

	Select @pass=Count(*)  From Staging.dbo.u_audit_log 
	Where Staging.dbo.u_audit_log.Import_ts >
	 (Select DateAdd(HH, -4, GetDate())) And 
	 Staging.dbo.u_audit_log.Object_Name = 'P2 Execution Completed'


	 IF(@pass>0)
	 BEGIN
	DECLARE @execution_id BIGINT


EXEC [SSISDB].[catalog].[create_execution] @package_name=N'VS_SalesBI_Package1 (1).dtsx',
 @execution_id=@execution_id OUTPUT, @folder_name=N'Post_transformation',
  @project_name=N'VS_SalesBI_Post_Transformation', @use32bitruntime=False, @reference_id=Null

DECLARE @var0 smallint = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=50,
 @parameter_name=N'LOGGING_LEVEL', @parameter_value=@var0

EXEC [SSISDB].[catalog].[start_execution] @execution_id


	DECLARE @loop INT=6
	DECLARE @cnt INT

	WHILE(@loop>0)
	BEGIN

		WAITFOR DELAY '00:05';

		SELECT @cnt=COUNT(*) FROM [SSISDB].[catalog].[event_messages] em
		where em.operation_id=@execution_id
		AND em.event_name NOT LIKE '%Validate%'
		AND em.message LIKE '%finished%'
		

		IF(@cnt=28)
		BEGIN
			INSERT INTO [dbo].[u_audit_log]
			values('Production Movement Completed',1,GETDATE(),NULL, NULL, NULL)

			BREAK;

		END
	END
	END
END


EXEC [dbo].[post_transformation]

DROP PROCEDURE [dbo].[post_transformation]
