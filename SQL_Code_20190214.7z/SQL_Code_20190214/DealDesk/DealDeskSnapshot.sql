ALTER PROCEDURE sp_DealDesk_Snapshot
AS
BEGIN


	DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))

	IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='da_stats_snapshot')
	BEGIN
	
	CREATE TABLE [dbo].da_stats_snapshot(
	[id] [int] NOT NULL,
	[ds_OpportunityID] [nvarchar](255) NOT NULL,
	[ds_DealDeskAnalyst] [nvarchar](255) NULL,
	[ds_WebCPTLink] [nvarchar](255) NULL,
	[ds_SystemEngineer] [nvarchar](255) NULL,
	[ds_Sales_Rep] [nvarchar](255) NULL,
	[ds_DealDeskName] [nvarchar](255) NOT NULL,
	[ds_PrimaryOption] [nvarchar](255) NULL,
	[ds_Primary_DC] [nvarchar](255) NULL,
	[ds_Secondary_DC] [nvarchar](255) NULL,
	[ds_PriceList] [nvarchar](255) NULL,
	[ds_AMS_OTC_Revenue] [float] NULL,
	[ds_AMS_OTC_Cost] [float] NULL,
	[ds_AMS_OTC_Margin] [float] NULL,
	[ds_IaaS_OTC_Revenue] [float] NULL,
	[ds_IaaS_OTC_Cost] [float] NULL,
	[ds_IaaS_OTC_Margin] [float] NULL,
	[ds_CSNS_OTC_Revenue] [float] NULL,
	[ds_CSNS_OTC_Cost] [float] NULL,
	[ds_CSNS_OTC_Margin] [float] NULL,
	[ds_Onboarding_Revenue] [float] NULL,
	[ds_Onboarding_Cost] [float] NULL,
	[ds_Onboarding_Margin] [float] NULL,
	[ds_TCV] [float] NULL,
	[ds_TCC] [float] NULL,
	[ds_TCV_Margin_Percent] [float] NULL,
	[ds_ACV] [float] NULL,
	[ds_ACC] [float] NULL,
	[ds_ACV_Margin_Percent] [float] NULL,
	[ds_CCV] [float] NULL,
	[ds_CCC] [float] NULL,
	[ds_CCV_Margin_Percent] [float] NULL,
	[ds_Steady_State_MRR] [float] NULL,
	[ds_Steady_State_MRC] [float] NULL,
	[ds_Steady_State_MRR_Margin_Percent] [float] NULL,
	[ds_AMS_Revenue] [float] NULL,
	[ds_AMS_Cost] [float] NULL,
	[ds_AMS_Margin_Percent] [float] NULL,
	[ds_CSNS_Revenue] [float] NULL,
	[ds_CSNS_Cost] [float] NULL,
	[ds_CSNS_Margin_Percent] [float] NULL,
	[ds_IaaS_Revenue] [float] NULL,
	[ds_IaaS_Cost] [float] NULL,
	[ds_IaaS_Margin_Percent] [float] NULL,
	[ds_CDMS_Revenue] [float] NULL,
	[ds_CDMS_Cost] [float] NULL,
	[ds_CDMS_Margin_Percent] [float] NULL,
	[ds_CDMS_MRR] [float] NULL,
	[ds_CDMS_MRC] [float] NULL,
	[ds_cdms_level] [nvarchar](255) NULL,
	[ds_deal_term] [float] NULL,
	[ds_gpl_version] [nvarchar](255) NULL,
	[ds_Currency] [varchar](255) NULL,
	[ds_closed_deal] [nvarchar](255) NULL,
	[CreatedTimeStamp] [datetime2](3) NOT NULL,
	[LastModified] [datetime2](3) NOT NULL,
	[ds_IsHec] [varchar](255) NULL,
	snapshot_type [nvarchar](255),
	snapshot_date DATE
	)
	END


	IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='da_sku_quantities_snapshot')
	BEGIN

	CREATE  TABLE [dbo].da_sku_quantities_snapshot(
	[id] [int]  NOT NULL,
	[da_id] [int] NOT NULL,
	[sku_id] [int] NOT NULL,
	[phase_id] [int] NOT NULL,
	[phase_discount] [float] NULL,
	[phase_quantity] [float] NULL,
	snapshot_type [nvarchar](255),
	snapshot_date DATE
) 

	END

	IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='da_cust_price_list_snapshot')
	BEGIN

	
	CREATE  TABLE [dbo].da_cust_price_list_snapshot(
	[id] [int]  NOT NULL,
	[sf_account_id] [nvarchar](18) NULL,
	[customer_name] [nvarchar](255) NOT NULL,
	[year] [int] NULL,
	[ext_sku] [nvarchar](255) NOT NULL,
	[ext_price] [float] NOT NULL,
	[currency] [nvarchar](10) NOT NULL,
	[sap_id] [nvarchar](255) NULL,
	snapshot_type [nvarchar](255),
	snapshot_date DATE
) 

	END

	IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='da_skus_snapshot')
	BEGIN

	
CREATE  TABLE [dbo].da_skus_snapshot(
	[id] [int]  NOT NULL,
	[da_id] [int] NOT NULL,
	[sku] [nvarchar](255) NOT NULL,
	[sku_list_price] [float] NULL,
	[sku_ext_price_y1] [float] NULL,
	[sku_ext_price_y2] [float] NULL,
	[sku_ext_price_y3] [float] NULL,
	[sku_ext_price_y4] [float] NULL,
	[sku_ext_price_y5] [float] NULL,
	[sku_ext_price_y6] [float] NULL,
	[sku_cost] [float] NULL,
	[sku_discount_y1] [float] NULL,
	[sku_discount_y2] [float] NULL,
	[sku_discount_y3] [float] NULL,
	[sku_discount_y4] [float] NULL,
	[sku_discount_y5] [float] NULL,
	[sku_discount_y6] [float] NULL,
	snapshot_type [nvarchar](255),
	snapshot_date DATE
)

	END


	IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='da_phases_snapshot')
	BEGIN

	
	CREATE TABLE [dbo].da_phases_snapshot(
	[id] [int] NOT NULL,
	[da_id] [int] NOT NULL,
	[phase_duration] [int] NOT NULL,
	[phase_number] [int] NOT NULL,
	[phase_is_steady_state] [int] NOT NULL,
	snapshot_type [nvarchar](255),
	snapshot_date DATE
	) 

	END


	

	--DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))
	DELETE FROM   da_stats_snapshot 
	WHERE (Snapshot_Date<DATEADD(DD,-7,@today) AND Snapshot_type LIKE 'DAY%')
	OR Snapshot_Date<DATEADD(DD,-699,@today)

	DELETE FROM   da_sku_quantities_snapshot 
	WHERE (Snapshot_Date<DATEADD(DD,-7,@today) AND Snapshot_type LIKE 'DAY%')
	OR Snapshot_Date<DATEADD(DD,-699,@today)

	DELETE FROM   da_cust_price_list_snapshot 
	WHERE (Snapshot_Date<DATEADD(DD,-7,@today) AND Snapshot_type LIKE 'DAY%')
	OR Snapshot_Date<DATEADD(DD,-699,@today)

	DELETE FROM   da_skus_snapshot 
	WHERE (Snapshot_Date<DATEADD(DD,-7,@today) AND Snapshot_type LIKE 'DAY%')
	OR Snapshot_Date<DATEADD(DD,-699,@today)

	DELETE FROM   da_phases_snapshot 
	WHERE (Snapshot_Date<DATEADD(DD,-7,@today) AND Snapshot_type LIKE 'DAY%')
	OR Snapshot_Date<DATEADD(DD,-699,@today)

	DECLARE @cnti INT=7
	DECLARE @day INT=1
	DECLARE @snap_date DATE
	SET @snap_date=@today

	WHILE @cnti>0

	BEGIN

	
	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_stats_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'DAY%')
	BEGIN
	INSERT INTO da_stats_snapshot
	SELECT [id]
      ,[ds_OpportunityID]
      ,[ds_DealDeskAnalyst]
      ,[ds_WebCPTLink]
      ,[ds_SystemEngineer]
      ,[ds_Sales_Rep]
      ,[ds_DealDeskName]
      ,[ds_PrimaryOption]
      ,[ds_Primary_DC]
      ,[ds_Secondary_DC]
      ,[ds_PriceList]
      ,[ds_AMS_OTC_Revenue]
      ,[ds_AMS_OTC_Cost]
      ,[ds_AMS_OTC_Margin]
      ,[ds_IaaS_OTC_Revenue]
      ,[ds_IaaS_OTC_Cost]
      ,[ds_IaaS_OTC_Margin]
      ,[ds_CSNS_OTC_Revenue]
      ,[ds_CSNS_OTC_Cost]
      ,[ds_CSNS_OTC_Margin]
      ,[ds_Onboarding_Revenue]
      ,[ds_Onboarding_Cost]
      ,[ds_Onboarding_Margin]
      ,[ds_TCV]
      ,[ds_TCC]
      ,[ds_TCV_Margin_Percent]
      ,[ds_ACV]
      ,[ds_ACC]
      ,[ds_ACV_Margin_Percent]
      ,[ds_CCV]
      ,[ds_CCC]
      ,[ds_CCV_Margin_Percent]
      ,[ds_Steady_State_MRR]
      ,[ds_Steady_State_MRC]
      ,[ds_Steady_State_MRR_Margin_Percent]
      ,[ds_AMS_Revenue]
      ,[ds_AMS_Cost]
      ,[ds_AMS_Margin_Percent]
      ,[ds_CSNS_Revenue]
      ,[ds_CSNS_Cost]
      ,[ds_CSNS_Margin_Percent]
      ,[ds_IaaS_Revenue]
      ,[ds_IaaS_Cost]
      ,[ds_IaaS_Margin_Percent]
      ,[ds_CDMS_Revenue]
      ,[ds_CDMS_Cost]
      ,[ds_CDMS_Margin_Percent]
      ,[ds_CDMS_MRR]
      ,[ds_CDMS_MRC]
      ,[ds_cdms_level]
      ,[ds_deal_term]
      ,[ds_gpl_version]
      ,[ds_Currency]
      ,[ds_closed_deal]
      ,[CreatedTimeStamp]
      ,[LastModified]
      ,[ds_IsHec]
      ,NULL as [snapshot_type]
      ,@snap_date as [snapshot_date]
  FROM [dbo].[da_stats]
	END

	UPDATE  da_stats_snapshot
	SET Snapshot_type =(SELECT CONCAT('DAY 0',@day)) WHERE Snapshot_Date=@snap_date 
	AND  (Snapshot_type  LIKE 'DAY%' OR Snapshot_type IS NULL)

	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_sku_quantities_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'DAY%')
	BEGIN
	INSERT INTO da_sku_quantities_snapshot
	SELECT [id]
      ,[da_id]
      ,[sku_id]
      ,[phase_id]
      ,[phase_discount]
      ,[phase_quantity]
      ,NULL as [snapshot_type]
      ,@snap_date as [snapshot_date]
  FROM [dbo].[da_sku_quantities]
	
	END

	UPDATE  da_sku_quantities_snapshot
	SET Snapshot_type =(SELECT CONCAT('DAY 0',@day)) 
	WHERE Snapshot_Date=@snap_date 
	AND  (Snapshot_type  LIKE 'DAY%' OR Snapshot_type IS NULL)

	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_cust_price_list_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'DAY%')
	BEGIN
	INSERT INTO da_cust_price_list_snapshot
	SELECT *, NULL, @snap_date FROM [da_cust_price_list]
	END

	UPDATE  da_cust_price_list_snapshot
	SET Snapshot_type =(SELECT CONCAT('DAY 0',@day)) WHERE Snapshot_Date=@snap_date 
	AND  (Snapshot_type  LIKE 'DAY%' OR Snapshot_type IS NULL)

	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_skus_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'DAY%')
	BEGIN
	INSERT INTO da_skus_snapshot
	SELECT *, NULL, @snap_date FROM [da_skus]
	END

	UPDATE  da_skus_snapshot
	SET Snapshot_type =(SELECT CONCAT('DAY 0',@day)) WHERE Snapshot_Date=@snap_date 
	AND  (Snapshot_type  LIKE 'DAY%' OR Snapshot_type IS NULL)

	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_phases_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'DAY%')
	BEGIN
	INSERT INTO da_phases_snapshot
	SELECT *, NULL, @snap_date FROM [da_phases]
	END

	UPDATE  da_phases_snapshot
	SET Snapshot_type =(SELECT CONCAT('DAY 0',@day)) WHERE Snapshot_Date=@snap_date 
	AND  (Snapshot_type  LIKE 'DAY%' OR Snapshot_type IS NULL)


	SET @snap_date= DATEADD(DD,-1,@snap_date)
	SET @cnti=@cnti-1
	SET @day=@day+1
	END


	--------------------------Weekly Snapshots----------------------


	SET @cnti=13
	DECLARE @week INT=1
	SET @snap_date=(SELECT (CASE WHEN DATEPART(weekday, @today)>5
	THEN DATEADD(DAY, +4, DATEADD(WEEK, DATEDIFF(WEEK, 0, @today), 0))
	ELSE DATEADD(DAY, -3, DATEADD(WEEK, DATEDIFF(WEEK, 0, @today), 0)) END))
	
	WHILE @cnti>0

	BEGIN

	
	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_stats_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'WEEK%')
	BEGIN
	INSERT INTO da_stats_snapshot
	SELECT [id]
      ,[ds_OpportunityID]
      ,[ds_DealDeskAnalyst]
      ,[ds_WebCPTLink]
      ,[ds_SystemEngineer]
      ,[ds_Sales_Rep]
      ,[ds_DealDeskName]
      ,[ds_PrimaryOption]
      ,[ds_Primary_DC]
      ,[ds_Secondary_DC]
      ,[ds_PriceList]
      ,[ds_AMS_OTC_Revenue]
      ,[ds_AMS_OTC_Cost]
      ,[ds_AMS_OTC_Margin]
      ,[ds_IaaS_OTC_Revenue]
      ,[ds_IaaS_OTC_Cost]
      ,[ds_IaaS_OTC_Margin]
      ,[ds_CSNS_OTC_Revenue]
      ,[ds_CSNS_OTC_Cost]
      ,[ds_CSNS_OTC_Margin]
      ,[ds_Onboarding_Revenue]
      ,[ds_Onboarding_Cost]
      ,[ds_Onboarding_Margin]
      ,[ds_TCV]
      ,[ds_TCC]
      ,[ds_TCV_Margin_Percent]
      ,[ds_ACV]
      ,[ds_ACC]
      ,[ds_ACV_Margin_Percent]
      ,[ds_CCV]
      ,[ds_CCC]
      ,[ds_CCV_Margin_Percent]
      ,[ds_Steady_State_MRR]
      ,[ds_Steady_State_MRC]
      ,[ds_Steady_State_MRR_Margin_Percent]
      ,[ds_AMS_Revenue]
      ,[ds_AMS_Cost]
      ,[ds_AMS_Margin_Percent]
      ,[ds_CSNS_Revenue]
      ,[ds_CSNS_Cost]
      ,[ds_CSNS_Margin_Percent]
      ,[ds_IaaS_Revenue]
      ,[ds_IaaS_Cost]
      ,[ds_IaaS_Margin_Percent]
      ,[ds_CDMS_Revenue]
      ,[ds_CDMS_Cost]
      ,[ds_CDMS_Margin_Percent]
      ,[ds_CDMS_MRR]
      ,[ds_CDMS_MRC]
      ,[ds_cdms_level]
      ,[ds_deal_term]
      ,[ds_gpl_version]
      ,[ds_Currency]
      ,[ds_closed_deal]
      ,[CreatedTimeStamp]
      ,[LastModified]
      ,[ds_IsHec]
      ,NULL as [snapshot_type]
      ,@snap_date as [snapshot_date]
  FROM [dbo].[da_stats]
	END

	  


	IF(@week<10)
	BEGIN
	UPDATE  da_stats_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK 0',@week))
	WHERE Snapshot_Date= @snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)

	END
	ELSE
	BEGIN
	UPDATE  da_stats_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK ',@week))
	WHERE Snapshot_Date=@snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)
	END

	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_sku_quantities_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'WEEK%')
	BEGIN
	INSERT INTO da_sku_quantities_snapshot
	SELECT [id]
      ,[da_id]
      ,[sku_id]
      ,[phase_id]
      ,[phase_discount]
      ,[phase_quantity]
      ,NULL as [snapshot_type]
      ,@snap_date as [snapshot_date]
  FROM [dbo].[da_sku_quantities]
	
	END

	 
	IF(@week<10)
	BEGIN
	UPDATE  da_sku_quantities_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK 0',@week))
	WHERE Snapshot_Date =@snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)

	END
	ELSE
	BEGIN
	UPDATE  da_sku_quantities_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK ',@week))
	WHERE Snapshot_Date=@snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)
	END

	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_cust_price_list_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'WEEK%')
	BEGIN
	INSERT INTO da_cust_price_list_snapshot
	SELECT *, NULL, @snap_date FROM [da_cust_price_list]
	END

	
	IF(@week<10)
	BEGIN
	UPDATE  da_cust_price_list_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK 0',@week))
	WHERE Snapshot_Date= @snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)

	END
	ELSE
	BEGIN
	UPDATE  da_cust_price_list_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK ',@week))
	WHERE Snapshot_Date=@snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)
	END


	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_skus_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'WEEK%')
	BEGIN
	INSERT INTO da_skus_snapshot
	SELECT *, NULL, @snap_date FROM [da_skus]
	END

	 
	IF(@week<10)
	BEGIN
	UPDATE  da_skus_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK 0',@week))
	WHERE Snapshot_Date =@snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)

	END
	ELSE
	BEGIN
	UPDATE  da_skus_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK ',@week))
	WHERE Snapshot_Date=@snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)
	END

	IF NOT EXISTS(SELECT distinct snapshot_date FROM da_phases_snapshot
	where snapshot_date=@snap_date AND snapshot_type LIKE 'WEEK%')
	BEGIN
	INSERT INTO da_phases_snapshot
	SELECT *, NULL, @snap_date FROM [da_phases]
	END

	 
	IF(@week<10)
	BEGIN
	UPDATE  da_phases_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK 0',@week))
	WHERE Snapshot_Date= @snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)

	END
	ELSE
	BEGIN
	UPDATE  da_phases_snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK ',@week))
	WHERE Snapshot_Date=@snap_date AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)
	END



	SET @snap_date= DATEADD(DD,-7,@snap_date)
	SET @cnti=@cnti-1
	SET @week=@week+1
	END




END



--	SELECT name FROM sys.tables WHERE name LIKE 'da%'
--da_stats : 564 rows
--da_cust_price_list : 4042 rows
--da_phases : 2243 rows
--da_skus : 17758 rows
--da_sku_quantities : 55423 rows



--SELECT snapshot_type, snapshot_date,count(*) FROM da_sku_quantities_snapshot
--GROUP BY snapshot_type, snapshot_date
--order by 1