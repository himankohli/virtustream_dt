/**

Maintains the Currency Conversion Rate for last 700 days. Incase, any Currency snapshot is missing,
it re-creates the missing snapshot then and there.

**/

CREATE PROCEDURE[Currency_Snap_Master]
AS
BEGIN

IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='Currency_Snapshot')
	BEGIN

			CREATE TABLE Currency_Snapshot
			(
			Id NVARCHAR(255),
			IsoCode NVARCHAR(255),
			ConversionRate FLOAT,
			DecimalPlaces INT,
			IsActive BIT,
			IsCorporate BIT,
			CreatedDate DATETIME,
			CreatedById NVARCHAR(255),
			LastModifiedDate DATETIME,
			LastModifiedById  NVARCHAR(255),
			SystemModstamp DATETIME,
			SnapshotDate DATE
			)

	END
	
	DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))
	DELETE FROM   Currency_Snapshot WHERE SnapshotDate<DATEADD(DD,-699,@today)
	DELETE FROM   Currency_Snapshot WHERE SnapshotDate=@today

	DECLARE @cnt INT=0
	DECLARE @counter INT

	WHILE @cnt<700
	BEGIN

	SET @counter=0

	SELECT @counter=COUNT(DISTINCT SnapshotDate) FROM Currency_Snapshot
	WHERE SnapshotDate=CAST(DATEADD(DD,-@cnt, @today) AS DATE)

	IF(@counter=0)
	BEGIN
	IF(@cnt=0)
	BEGIN
	INSERT INTO Currency_Snapshot
(
Id ,
IsoCode ,
ConversionRate ,
DecimalPlaces ,
IsActive ,
IsCorporate ,
CreatedDate ,
CreatedById ,
LastModifiedDate ,
LastModifiedById  ,
SystemModstamp ,
SnapshotDate 
)
(
SELECT
Id ,
IsoCode ,
ConversionRate ,
DecimalPlaces ,
IsActive ,
IsCorporate ,
CreatedDate ,
CreatedById ,
LastModifiedDate ,
LastModifiedById  ,
SystemModstamp ,
@today as SnapshotDate  
FROM CurrencyType
)
END
ELSE
BEGIN
INSERT INTO Currency_Snapshot
(
Id ,
IsoCode ,
ConversionRate ,
DecimalPlaces ,
IsActive ,
IsCorporate ,
CreatedDate ,
CreatedById ,
LastModifiedDate ,
LastModifiedById  ,
SystemModstamp ,
SnapshotDate 
)
(
SELECT
Id ,
IsoCode ,
ConversionRate ,
DecimalPlaces ,
IsActive ,
IsCorporate ,
CreatedDate ,
CreatedById ,
LastModifiedDate ,
LastModifiedById  ,
SystemModstamp ,
CAST(DATEADD(DD,-@cnt, GETDATE()) AS DATE) as SnapshotDate  
FROM Currency_Snapshot 
WHERE SnapshotDate=CAST(DATEADD(DD,1-@cnt, GETDATE()) AS DATE)
)
END
END

SET @cnt=@cnt+1
END

DECLARE @a INT
DECLARE @b INT

SELECT @a=COUNT(DISTINCT SnapshotDate) FROM Currency_Snapshot
WHERE SnapshotDate=@today

SELECT @b=COUNT(Id) FROM Currency_Snapshot

		IF(@a=1 AND @b=5600)
		BEGIN
			INSERT INTO u_audit_log
			values('Currency_Snapshot: Object updated',1,GETDATE(),8, NULL,@b)
		END
		ELSE
		BEGIN
			INSERT INTO u_audit_log
			values('Currency_Snapshot: Missing',0,GETDATE(),NULL,NULL,@b)
		END
END

