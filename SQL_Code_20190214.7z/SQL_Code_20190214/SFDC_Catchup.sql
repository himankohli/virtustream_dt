
ALTER VIEW SFDC_Data
AS
SELECT  MAX(pls.field_source) as Source, MAX(fq.WEEK)  as Week, CONCAT('FY ',MAX(fq.fiscal_qtr)) as Quarter,
pls.pl_practice_line__c AS [Revenue Schedule Practice Line],
pls.pl_service_line__c AS [Revenue Schedule Service Line],
pls.product_quant_practice_group__c AS [Quant Segment Practice Group],
MAX(SUBSTRING(pls.opp_stagename,1,CHARINDEX('%',pls.opp_stagename))) as [Probability],
MAX(pls.opp_stagename) as Stage,
MAX(CAST(pls.opp_heat_map__c AS INT)) as Heatmap,
pls.opp_id as [Opportunity Id],
MAX(pls.opp_opportunity_number__c) as [Opportunity Number],
MAX(pls.acc_name) as [Account NAme],
MAX(pls.opp_name) as [Opportunity],
MAX(pls.opp_theatre__c) as [Theater],
MAX(pls.opp_segment__c) as [Segment],
CONCAT('FY ',MAX(pls.opp_close_fiscal_quarter)) as [Fiscal Year/Quarter],
CAST(MAX(pls.opp_closedate) as DATE) as [Close Date],
MAX(pls.opp_lead_partner__c) as [Primary Partner],
CASE WHEN MAX(pls.acc_dell_emc_segment__c) IS NOT NULL
THEN MAX(pls.acc_dell_emc_segment__c) 
ELSE MAX(o.acc_dell_emc_segment__c) END as [Consol Classification],
SUM(pls.revschd_acv_final) as ACV,
SUM(pls.revschd_booked_amount_final) as CCV,
CASE WHEN MAX(pls.opp_theatre__c) = 'Americas' and MAX(pls.opp_segment__c) = 'Commercial' and 
  pls.product_quant_practice_group__c  = 'VEC' THEN 'Commercial'
WHEN MAX(pls.opp_segment__c) = 'Diamond Accounts' and  pls.product_quant_practice_group__c = 'VEC'
THEN 'Diamond' 
WHEN MAX(pls.opp_theatre__c) = 'Americas' and  MAX(pls.opp_segment__c) = 'Public Sector' and 
 pls.product_quant_practice_group__c = 'VEC' THEN 'Public Sector'
WHEN MAX(pls.opp_theatre__c) = 'EMEA' and  MAX(pls.opp_segment__c) <> 'Diamond Accounts' and 
 MAX(pls.product_quant_practice_group__c) = 'VEC' THEN 'EMEA'
WHEN MAX(pls.opp_theatre__c) = 'APJ' and  MAX(pls.opp_segment__c) <> 'Diamond Accounts' and 
 MAX(pls.product_quant_practice_group__c) = 'VEC' THEN 'APJ'
WHEN MAX(pls.product_quant_practice_group__c) = 'VSC' THEN 'VSC' 
WHEN MAX(pls.product_quant_practice_group__c) = 'SW' THEN 'SW' END as [Comm, Diamond, Public, EMEA, APJ, VSC, SW],
CASE WHEN MAX(pls.snapshot_fiscal_quarter)=MAX(pls.opp_close_fiscal_quarter)
THEN 1
ELSE 0 END as [Same Qtr for Booking]

FROM Product_Line_Snapshot pls JOIN FiscalQuarters fq
ON pls.snapshot_date=fq.date JOIN Opportunity_Header o ON pls.opp_id=o.opp_id
where pls.isharddeleted=0 AND pls.field_source='SFDC' AND pls.snapshot_type LIKE 'WEEK%'
AND PLS.snapshot_date between '2017-08-05' AND '2018-10-05'
AND pls.product_quant_practice_group__c <>'Managed Services'
AND ISNULL(pls.opp_type,'a')<>'CSP-Sell Out'
GROUP BY pls.snapshot_date, 
pls.pl_practice_line__c ,
pls.pl_service_line__c ,
pls.product_quant_practice_group__c, 
pls.opp_id


