
CREATE PROCEDURE Prev_Records(@k DATE)
 AS
  BEGIN 

  INSERT INTO t_ofh_last_record(Opportunityid, field ,  createddate, newvalue)
		(
		SELECT  erfh.Opportunityid, erfh.field, erfh.createddate , MAX(erfh.newvalue) as newvalue
		FROM OFH_Copy erfh INNER JOIN
			(SELECT CONCAT(Opportunityid,'_',field) as id_field, MAX(createddate) as max_cd FROM OFH_Copy
	WHERE  CAST(opp_created_date AS DATE) <= @k  AND CAST(createddate AS DATE)< =@k
	GROUP BY CONCAT(Opportunityid,'_',field)
	) level
		ON CONCAT(erfh.Opportunityid,'_',erfh.field)=level.id_field
		WHERE  erfh.createddate=level.max_cd 
		GROUP BY erfh.Opportunityid, erfh.field, erfh.createddate 
		) 
  END

 
 /*To find old value of first history record after Snapshot Date*/

CREATE PROCEDURE Next_Records(@k DATE)
AS
 BEGIN 

  INSERT INTO t_ofh_last_record2(opportunityid, field , createddate , oldvalue) 
		(
		
  SELECT  erfh.opportunityid, erfh.field, erfh.createddate , MAX(erfh.oldvalue) as oldvalue
		FROM OFH_Copy erfh INNER JOIN
			(SELECT CONCAT(opportunityid,'_',field) as id_field, MIN(createddate) as min_cd FROM OFH_Copy
	 WHERE 
		CONCAT(opportunityid,'_',field) NOT IN (SELECT CONCAT(opportunityid,'_',field) 
		FROM t_ofh_last_record)
		and  CAST(opp_created_date AS DATE) <= @k AND CAST(createddate AS DATE) > @k
	GROUP BY CONCAT(opportunityid,'_',field)
	) level
		ON CONCAT(erfh.opportunityid,'_',erfh.field)=level.id_field
		WHERE  erfh.createddate=level.min_cd 
		GROUP BY erfh.opportunityid, erfh.field, erfh.createddate 
		)

  END

  

  --------------------------Rev Functions--------------------

   /*To find new value of latest history record before Snapshot Date*/

     CREATE PROCEDURE Rev_Prev_Records(@k DATE)
 AS
  BEGIN 

  INSERT INTO t_rfh_last_record(ParentId, field ,  createddate, newvalue)
		(
		SELECT  erfh.ParentId, erfh.field, erfh.createddate , MAX(erfh.newvalue) as newvalue
		FROM RFH_Copy erfh INNER JOIN
			(SELECT CONCAT(ParentId,'_',field) as id_field, MAX(createddate) as max_cd 
			FROM RFH_Copy
	WHERE  CAST(Rev_created_date AS DATE) <= @k  AND CAST(createddate as DATE) <= @k
	GROUP BY CONCAT(ParentId,'_',field)
	) level
		ON CONCAT(erfh.ParentId,'_',erfh.field)=level.id_field
		WHERE  erfh.createddate=level.max_cd 
		GROUP BY erfh.ParentId, erfh.field, erfh.createddate 
		) 
  END
 

  
 
 /*To find old value of first history record after Snapshot Date*/

	CREATE PROCEDURE Rev_Next_Records(@k DATE)
AS
 BEGIN 
 INSERT INTO t_rfh_last_record2(ParentId, field , createddate , oldvalue) 
		(
  SELECT  erfh.ParentId, erfh.field, erfh.createddate , MAX(erfh.oldvalue) as oldvalue
		FROM RFH_Copy erfh INNER JOIN
			(SELECT CONCAT(ParentId,'_',field) as id_field, MIN(createddate) as min_cd FROM RFH_Copy
	 WHERE 
		CONCAT(ParentId,'_',field) NOT IN (SELECT CONCAT(ParentId,'_',field) 
		FROM t_rfh_last_record)
		and  CAST(Rev_created_date  AS DATE)<= @k AND CAST(createddate AS DATE) > @k
	GROUP BY CONCAT(ParentId,'_',field)
	) level
		ON CONCAT(erfh.ParentId,'_',erfh.field)=level.id_field
		WHERE  erfh.createddate=level.min_cd 
		GROUP BY erfh.ParentId, erfh.field, erfh.createddate 
		)
	END
	


	