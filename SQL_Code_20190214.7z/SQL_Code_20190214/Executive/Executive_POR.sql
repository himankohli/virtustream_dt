/**

Executive_Por_Data is split from Day 1 to Day 91, and it provides the ACV and booking value
 for the rescpective quarter as on that Day.

Executive_Por_Data is the Data Source for Executive Dashboard.

**/

ALTER PROCEDURE [dbo].[sp_executive_por_data] 
as 
BEGIN
	DECLARE @today date=(SELECT GETDATE()) 
	DECLARE @run_time TIME=(SELECT FORMAT(GETDATE(),'HH:mm:ss'))
	DECLARE @current_quarter nvarchar(255)=(SELECT fiscal_qtr FROM fiscalquarters WHERE date=@today)
	
	DROP TABLE IF EXISTS #fiscal_quarter_rank

		SELECT [fiscal_qtr], ROW_NUMBER() OVER (ORDER BY fiscal_qtr) as [rank]
		INTO #fiscal_quarter_rank
		FROM FiscalQuarters
		GROUP BY fiscal_qtr

DECLARE @p1_qtr VARCHAR(50)=(SELECT [fiscal_qtr]  FROM #fiscal_quarter_rank 
where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
where [fiscal_qtr]=@current_quarter))

DECLARE @p2_qtr VARCHAR(50)=(SELECT [fiscal_qtr]  FROM #fiscal_quarter_rank 
where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
where [fiscal_qtr]=@current_quarter))

DECLARE @p3_qtr VARCHAR(50)=(SELECT [fiscal_qtr]  FROM #fiscal_quarter_rank 
where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
where [fiscal_qtr]=@current_quarter))

DECLARE @p4_qtr VARCHAR(50)=(SELECT [fiscal_qtr]  FROM #fiscal_quarter_rank 
where rank=(SELECT rank-4 FROM #fiscal_quarter_rank 
where [fiscal_qtr]=@current_quarter))

DECLARE @p5_qtr VARCHAR(50)=(SELECT [fiscal_qtr]  FROM #fiscal_quarter_rank 
where rank=(SELECT rank-5 FROM #fiscal_quarter_rank 
where [fiscal_qtr]=@current_quarter))
	
	DROP TABLE IF EXISTS Executive_POR_Data 
	CREATE TABLE Executive_POR_Data 
	(
		day_of_quarter INT, 
		theatre VARCHAR(255), 
		product VARCHAR(255), 
		segment VARCHAR(255), 
		current_fiscal_quarter VARCHAR(255), 
		dell_emc_segment__c VARCHAR(255), 
		ccv_por_value FLOAT,
		acv_por_value FLOAT, 
		q_1_closedate DATE, 
		q_1_bookings_value FLOAT, 
		q_1_acv_value FLOAT, 
		q_2_bookings_value FLOAT, 
		q_2_acv_value FLOAT, 
		q_3_bookings_value FLOAT, 
		q_3_acv_value FLOAT, 
		q_4_bookings_value FLOAT, 
		q_4_acv_value FLOAT, 
		q_5_bookings_value FLOAT, 
		q_5_acv_value FLOAT, 
		q_6_bookings_value FLOAT, 
		q_6_acv_value FLOAT, 
		average_bookings_value float, 
		average_acv_value float, 
		current_fiscal_period varchar(50),
		[current_date] DATE,
		field_source VARCHAR(50)
	) 
DECLARE @lp int=1 
	
	DECLARE @count INT=
	(SELECT count(DISTINCT date) FROM fiscalquarters WHERE fiscal_qtr=@current_quarter) 
	
	DECLARE @a_opportunity_copy TABLE 
	( 
		opp_id nvarchar(255),
	    pl_id nvarchar(255),
	    product_id nvarchar(255),
	    theater__c nvarchar(255),
	    segment__c nvarchar(255),
		dell_emc_segment__c NVARCHAR(255),
	    quant_practice_group__c nvarchar(255),
	    closedate date,
		stagename nvarchar(255),
	    acv float
	)
	  
	INSERT INTO @a_opportunity_copy 
	( 
		opp_id, 
		pl_id, 
		product_id, 
		theater__c, 
		segment__c, 
		dell_emc_segment__c,
		quant_practice_group__c, 
		closedate, 
		stagename, 
		acv
	)
	( 
		SELECT o.id as opp_id,
	    pl.id as pl_id,
	    p.id as product_id,
	    o.theater__c,
	    o.segment__c,
		CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal'
		ELSE a.dell_emc_segment__c
		END as  dell_emc_segment__c,
	    p.quant_practice_group__c,
	    o.closedate,
	    o.stagename,
	    pl.annual_contact_value_year_1__c/c.conversionrate as acv
	    FROM opportunity o
	    LEFT JOIN productline pl ON o.id=pl.opportunity__c
		LEFT JOIN Account a ON o.accountid=a.Id
	    LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
	    LEFT JOIN product2 p ON pl.product__c=p.id
	    WHERE p.quant_practice_group__c<>'Managed Services'
		AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
	    AND (o.stagename LIKE '100%' OR o.stagename LIKE '99%')
	    AND pl.annual_contact_value_year_1__c<> 0
	    AND o.isharddeleted=0
	    AND pl.isharddeleted=0
	   
	    AND c.isharddeleted=0
	) 

	DECLARE @a_opportunity_copy_cq TABLE 
	( 
		opp_id nvarchar(255),
	    pl_id nvarchar(255),
	    product_id nvarchar(255),
	    theater__c nvarchar(255),
	    segment__c nvarchar(255),
		dell_emc_segment__c NVARCHAR(255),
	    quant_practice_group__c nvarchar(255),
	    closedate date, 
		stagename nvarchar(255),
	    acv float
	)
	INSERT INTO @a_opportunity_copy_cq 
	( 
		opp_id, 
		pl_id, 
		product_id, 
		theater__c, 
		segment__c, 
		dell_emc_segment__c,
		quant_practice_group__c, 
		closedate, 
		stagename, 
		acv
	)
	(
		SELECT o.id as opp_id,pl.id as pl_id,p.id as product_id,o.theater__c,o.segment__c,
		CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal' ELSE a.dell_emc_segment__c
		END as   dell_emc_segment__c,
		p.quant_practice_group__c,
		CAST(o.closedate as date),o.stagename,pl.annual_contact_value_year_1__c/c.conversionrate as acv
		FROM opportunity o
		LEFT JOIN productline pl ON o.id=pl.opportunity__c
		LEFT JOIN Account a ON o.accountid=a.id
		LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
		LEFT JOIN product2 p ON pl.product__c=p.id
		WHERE p.quant_practice_group__c<>'Managed Services'
		AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
		AND CAST(o.closedate as date)>@today
		AND pl.annual_contact_value_year_1__c<> 0
		AND o.isharddeleted=0
		AND pl.isharddeleted=0
		
		AND c.isharddeleted=0
		AND (
				(o.stagename LIKE '100%' OR o.stagename LIKE '99%' OR o.stagename LIKE '90%' OR o.stagename LIKE '75%')
				OR (o.stagename NOT LIKE '0%' AND o.heat_map__c=1)
			)
		AND (SELECT DISTINCT fiscal_qtr FROM fiscalquarters WHERE date=o.closedate)=@current_quarter

	    UNION ALL
		
		SELECT o.id as opp_id, pl.id as pl_id, p.id as product_id, o.theater__c, o.segment__c,
		CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal' ELSE a.dell_emc_segment__c
		END as   dell_emc_segment__c,
		p.quant_practice_group__c,
	    CAST(o.closedate as date),o.stagename,pl.annual_contact_value_year_1__c/c.conversionrate as acv
	    FROM opportunity o
	    LEFT JOIN productline pl ON o.id=pl.opportunity__c
		LEFT JOIN Account a ON o.accountid=a.id
	    LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
	    LEFT JOIN product2 p ON pl.product__c=p.id
	    WHERE p.quant_practice_group__c<>'Managed Services'
		AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
	    AND CAST(o.closedate as date)<=@today
	    AND pl.annual_contact_value_year_1__c<> 0
	    AND o.isharddeleted=0
	    AND pl.isharddeleted=0
	   
	    AND c.isharddeleted=0
	    AND (SELECT DISTINCT fiscal_qtr FROM fiscalquarters WHERE date=o.closedate)=@current_quarter
	    AND (o.stagename LIKE '100%' OR o.stagename LIKE '99%')
	    
		UNION ALL
		
		SELECT o.id as opp_id,pl.id as pl_id, p.id as product_id,o.theater__c, o.segment__c,
		CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal' ELSE a.dell_emc_segment__c
		END as   dell_emc_segment__c,
		p.quant_practice_group__c,
	   -- @today,
		(SELECT CASE WHEN @run_time>='07:00:00' AND @run_time<='23:59:59' 
		THEN  DATEADD(dd,1,@today)
		ELSE @today END),
		o.stagename, pl.annual_contact_value_year_1__c/c.conversionrate as acv
	    FROM opportunity o
	    LEFT JOIN productline pl ON o.id=pl.opportunity__c
		LEFT JOIN Account a ON o.accountid=a.id
	    LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
	    LEFT JOIN product2 p ON pl.product__c=p.id
	    WHERE p.quant_practice_group__c<>'Managed Services'
		AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
	    AND CAST(o.closedate as date)<=@today
	    AND pl.annual_contact_value_year_1__c<> 0
	    AND (SELECT DISTINCT fiscal_qtr FROM fiscalquarters WHERE date=o.closedate)=@current_quarter
	    AND CAST(o.closedate as date)>=(SELECT min(CAST(date as date)) FROM fiscalquarters WHERE fiscal_qtr=@current_quarter)
	    AND (
				(o.stagename LIKE '90%'OR o.stagename LIKE '75%')
	            OR (o.stagename NOT LIKE '0%'AND o.stagename NOT LIKE '99%' AND o.stagename NOT LIKE '100%' AND o.heat_map__c=1)
			)
	    AND o.isharddeleted=0
	    AND pl.isharddeleted=0
	   
	    AND c.isharddeleted=0
	) 
		   
		   
	DECLARE @b_opportunity_copy TABLE 
	( 
		opp_id nvarchar(255),
	    pl_id nvarchar(255),
	    product_id nvarchar(255),
	    theater__c nvarchar(255),
	    segment__c nvarchar(255),
		dell_emc_segment__c NVARCHAR(255),
	    quant_practice_group__c nvarchar(255),
	    closedate date, 
		stagename nvarchar(255),
	    booked_amount_with_override float
	)
	  INSERT INTO @b_opportunity_copy ( opp_id, pl_id, product_id, theater__c, segment__c,
	  dell_emc_segment__c, 
	  quant_practice_group__c, closedate, stagename, booked_amount_with_override)
	    ( SELECT o.id as opp_id,
	             pl.id as pl_id,
	             p.id as product_id,
	             o.theater__c,
	             o.segment__c,
			CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal' ELSE a.dell_emc_segment__c
		END as   dell_emc_segment__c,
	             p.quant_practice_group__c,
	             o.closedate,
	             o.stagename,
	             pl.booked_amount__c/c.conversionrate as booked_amount_with_override
	     FROM opportunity o
	     LEFT JOIN productline pl ON o.id=pl.opportunity__c
		 LEFT JOIN Account a ON o.accountid=a.id
	     LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
	     LEFT JOIN product2 p ON pl.product__c=p.id
	     WHERE p.quant_practice_group__c<>'Managed Services'
		 AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
	       AND (o.stagename LIKE '100%'
	            OR o.stagename LIKE '99%')
	       AND pl.booked_amount__c<>0
	       AND o.isharddeleted=0
	       AND pl.isharddeleted=0 AND c.isharddeleted=0) 
		   
		   DECLARE @b_opportunity_copy_cq TABLE 
		   ( opp_id nvarchar(255),
	         pl_id nvarchar(255),
	         product_id nvarchar(255),
	         theater__c nvarchar(255),
	         segment__c nvarchar(255),
		dell_emc_segment__c NVARCHAR(255),
	    quant_practice_group__c nvarchar(255),
	    closedate date, stagename nvarchar(255),
	       booked_amount_with_override float )
	  INSERT INTO @b_opportunity_copy_cq ( opp_id, pl_id, product_id, theater__c, segment__c, 
	  dell_emc_segment__c,
	  quant_practice_group__c, closedate, stagename, booked_amount_with_override)
	    ( SELECT o.id as opp_id,
	             pl.id as pl_id,
	             p.id as product_id,
	             o.theater__c,
	             o.segment__c,
		CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal' ELSE a.dell_emc_segment__c
		END as   dell_emc_segment__c,
	             p.quant_practice_group__c,
	             CAST(o.closedate as date),
	             o.stagename,
	             pl.booked_amount__c/c.conversionrate as booked_amount_with_override
	     FROM opportunity o
	     LEFT JOIN productline pl ON o.id=pl.opportunity__c
		 LEFT JOIN Account a ON o.accountid=a.id
	     LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
	     LEFT JOIN product2 p ON pl.product__c=p.id
	     WHERE p.quant_practice_group__c<>'Managed Services'
		 AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
	       AND CAST(o.closedate as date)>@today
	       AND pl.booked_amount__c<>0
	       AND o.isharddeleted=0
	       AND pl.isharddeleted=0
	    
	       AND c.isharddeleted=0
	       AND ((o.stagename LIKE '100%'
	             OR o.stagename LIKE '99%'
	             OR o.stagename LIKE '90%'
	             OR o.stagename LIKE '75%')
	            OR (o.stagename NOT LIKE '0%'
	                AND o.heat_map__c=1) )
	       AND
	         (SELECT DISTINCT fiscal_qtr
	          FROM fiscalquarters
	          WHERE date=o.closedate)=@current_quarter

	     UNION ALL
		 
		 SELECT o.id as opp_id,
	                  pl.id as pl_id,
	                  p.id as product_id,
	                  o.theater__c,
	                  o.segment__c,
			CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal' ELSE a.dell_emc_segment__c
		END as   dell_emc_segment__c,
	                  p.quant_practice_group__c,
	                  CAST(o.closedate as date),
	                  o.stagename,
	                  pl.booked_amount__c/c.conversionrate as booked_amount_with_override
	     FROM Opportunity o
	     LEFT JOIN productline pl ON o.id=pl.opportunity__c
		 LEFT JOIN Account a ON o.accountid=a.id
	     LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
	     LEFT JOIN product2 p ON pl.product__c=p.id
	     WHERE p.quant_practice_group__c<>'Managed Services'
		 AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
	       AND CAST(o.closedate as date)<=@today
	       AND pl.booked_amount__c<>0
	       AND o.isharddeleted=0
	       AND pl.isharddeleted=0
	       
	       AND c.isharddeleted=0
	       AND (o.stagename LIKE '100%'
	            OR o.stagename LIKE '99%')

	     UNION ALL
		 
		 SELECT o.id as opp_id, pl.id as pl_id, p.id as product_id, o.theater__c, o.segment__c,
		CASE 
		when substring(a.dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(a.dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(a.dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal' ELSE a.dell_emc_segment__c
		END as   dell_emc_segment__c, p.quant_practice_group__c,
	       
					 (SELECT CASE WHEN @run_time>='07:00:00' AND @run_time<='23:59:59' 
					THEN  DATEADD(dd,1,@today)
					ELSE @today END),
	                  o.stagename,
	                  pl.booked_amount__c/c.conversionrate as booked_amount_with_override
	     FROM opportunity o
	     LEFT JOIN productline pl ON o.id=pl.opportunity__c
		 LEFT JOIN Account a ON o.accountid=a.id
	     LEFT JOIN currencytype c ON pl.currencyisocode=c.isocode
	     LEFT JOIN product2 p ON pl.product__c=p.id
	     WHERE p.quant_practice_group__c<>'Managed Services'
		 AND ISNULL(o.type,'a') <> 'CSP-Sell Out'
	       AND CAST(o.closedate as date)<=@today
	       AND CAST(o.closedate as date)>=
	         (SELECT min(CAST(date as date))
	          FROM fiscalquarters
	          WHERE fiscal_qtr=@current_quarter)
	       AND (( o.stagename LIKE '90%'
	             OR o.stagename LIKE '75%')
	            OR (o.stagename NOT LIKE '0%'
	                AND o.stagename NOT LIKE '99%'
	                AND o.stagename NOT LIKE '100%'
	                AND o.heat_map__c=1))
	       AND pl.booked_amount__c<>0
	       AND o.isharddeleted=0
	       AND pl.isharddeleted=0
	       AND c.isharddeleted=0) 
		
	DROP TABLE IF EXISTS #Executive_POR_Data_New   
	CREATE  TABLE #Executive_POR_Data_New
	( 
		day_of_quarter int, 
		theatre varchar(255),
		product varchar(255),
	    segment varchar(255),
	    current_fiscal_quarter varchar(255),
	    dell_emc_segment__c varchar(255),
	    ccv_por_value float, 
		acv_por_value float, 
		q_1_closedate date, 
		q_1_bookings_value float, 
		q_1_acv_value float, 
		q_2_bookings_value float, 
		q_2_acv_value float, 
		q_3_bookings_value float, 
		q_3_acv_value float, 
		q_4_bookings_value float, 
		q_4_acv_value float, 
		q_5_bookings_value float, 
		q_5_acv_value float, 
		q_6_bookings_value float, 
		q_6_acv_value float 
	) 
	
	WHILE (@lp<=@count) 
	BEGIN
	  INSERT INTO #Executive_POR_Data_New ( day_of_quarter, theatre , product, segment , current_fiscal_quarter , 
	  dell_emc_segment__c,
	  ccv_por_value , acv_por_value , q_1_closedate , q_1_bookings_value , q_1_acv_value , q_2_bookings_value , q_2_acv_value , q_3_bookings_value , q_3_acv_value , q_4_bookings_value , q_4_acv_value , q_5_bookings_value , q_5_acv_value , q_6_bookings_value , q_6_acv_value)
	    (SELECT @lp as day_of_quarter,
	            por.theatre ,
	            por.product,
	            por.segment ,
	            por.fiscal_quarter as current_fiscal_quarter ,
				por.classification as dell_emc_segment__c,
	            (ccv_value/@COUNT)*@lp as ccv_por_value,
	            (acv_value/@COUNT)*@lp as acv_por_value,
				
	       (SELECT CAST(date as date)
	        FROM
	          (SELECT date, row_number() over(
	                                          ORDER BY date) rk
	           FROM fiscalquarters
	           WHERE fiscal_qtr=@current_quarter) date_qtr
	        WHERE rk=@lp) as q_1_closedate,

	       (SELECT sum(o.booked_amount_with_override)
	        FROM @b_opportunity_copy_cq o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND CAST(o.closedate as date) IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr=@current_quarter) date_qtr
	             WHERE rk<=@lp)) as q_1_bookings_value,

	       (SELECT sum(o.acv)
	        FROM @a_opportunity_copy_cq o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND CAST(o.closedate as date) IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr=@current_quarter) date_qtr
	             WHERE rk<=@lp)) as q_1_acv_value,

	       (SELECT sum(o.booked_amount_with_override)
	        FROM @b_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-1
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp) ) as q_2_bookings_value,

	       (SELECT sum(o.acv)
	        FROM @a_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-1
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp) ) as q_2_acv_value,

	       (SELECT sum(o.booked_amount_with_override)
	        FROM @b_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-2
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp)) as q_3_bookings_value,

	       (SELECT sum(o.acv)
	        FROM @a_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-2
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp)) as q_3_acv_value,

	       (SELECT sum(o.booked_amount_with_override)
	        FROM @b_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-3
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp) ) as q_4_bookings_value,

	       (SELECT sum(o.acv)
	        FROM @a_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-3
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp) ) as q_4_acv_value,

	       (SELECT sum(o.booked_amount_with_override)
	        FROM @b_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-4
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp)) as q_5_bookings_value,

	       (SELECT sum(o.acv)
	        FROM @a_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-4
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp)) as q_5_acv_value,

	       (SELECT sum(o.booked_amount_with_override)
	        FROM @b_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-5
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp)) as q_6_bookings_value,

	       (SELECT sum(o.acv)
	        FROM @a_opportunity_copy o
	        WHERE o.theater__c=por.theatre
	          AND o.quant_practice_group__c=por.product
	          AND o.segment__c=por.segment
			  AND o.dell_emc_segment__c=por.classification
	          AND o.closedate IN
	            (SELECT CAST(qtr_date as date)
	             FROM
	               (SELECT date as qtr_date,
	                       row_number() over(
	                                         ORDER BY date) rk
	                FROM fiscalquarters
	                WHERE fiscal_qtr IN
	                    (SELECT fiscal_qtr
	                     FROM #fiscal_quarter_rank
	                     WHERE rank IN
	                         (SELECT rank-5
	                          FROM #fiscal_quarter_rank
	                          WHERE fiscal_qtr = @current_quarter))) date_qtr
	             WHERE rk<=@lp)) as q_6_acv_value
	  
	   FROM (
SELECT theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  SUM(ccv_value) ccv_value,  SUM(acv_value) acv_value,
data_domain FROM POR_Data where  product <> 'Managed Services'
GROUP BY 
theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  
data_domain)   por
	     WHERE  por.data_type='POR' AND por_type='Rollover Bookings' AND por.data_domain='Virtustream'
		 AND por.por_type='New Bookings'
	       AND por.fiscal_quarter=@current_quarter
	       AND por.product<>'Managed Services')

	  SET @lp=@lp+1 
	  END
------------------------Rollover Code-------------------
	 DROP TABLE IF EXISTS #Executive_POR_Data_Rollover   
	CREATE  TABLE #Executive_POR_Data_Rollover
	( 
		day_of_quarter int, 
		theatre varchar(255),
		product varchar(255),
	    segment varchar(255),
	    current_fiscal_quarter varchar(255),
	    dell_emc_segment__c varchar(255),
	    ccv_por_value float, 
		acv_por_value float, 
		q_1_closedate date, 
		q_1_bookings_value float, 
		q_1_acv_value float, 
		q_2_bookings_value float, 
		q_2_acv_value float, 
		q_3_bookings_value float, 
		q_3_acv_value float, 
		q_4_bookings_value float, 
		q_4_acv_value float, 
		q_5_bookings_value float, 
		q_5_acv_value float, 
		q_6_bookings_value float, 
		q_6_acv_value float 
	) 

	SET @lp=1

	WHILE (@lp<=@count) 
	BEGIN

	  INSERT INTO #Executive_POR_Data_Rollover 
	  ( day_of_quarter, 
	  theatre , 
	  product, 
	  segment , 
	  current_fiscal_quarter , 
	  dell_emc_segment__c,
	  ccv_por_value , 
	  acv_por_value , 
	  q_1_closedate , 
	  q_1_bookings_value , 
	  q_1_acv_value , 
	  q_2_bookings_value , 
	  q_2_acv_value , 
	  q_3_bookings_value , 
	  q_3_acv_value , 
	  q_4_bookings_value ,
	   q_4_acv_value , 
	   q_5_bookings_value , 
	   q_5_acv_value , 
	   q_6_bookings_value , 
	   q_6_acv_value)
	    (SELECT @lp as day_of_quarter,
	            por.theatre ,
	            por.product,
	            por.segment ,
	           @current_quarter as current_fiscal_quarter ,
			   por.classification as dell_emc_segment__c,
	            qk.ccv_value as ccv_por_value,
	            qk.acv_value as acv_por_value,
				
	       (SELECT CAST(date as date)
	        FROM
	          (SELECT date, row_number() over(
	                                          ORDER BY date) rk
	           FROM fiscalquarters
	           WHERE fiscal_qtr=@current_quarter) date_qtr
	        WHERE rk=@lp) as q_1_closedate,

			q1.ccv_value as q_1_bookings_value,
			q1.ccv_value as  q_1_acv_value,
			q2.ccv_value as q_2_bookings_value,
			q2.ccv_value  as q_2_acv_value,
			q3.ccv_value  as q_3_bookings_value,
			q3.ccv_value as q_3_acv_value,
			q4.ccv_value as q_4_bookings_value,
			q4.ccv_value as q_4_acv_value,
			q5.ccv_value as q_5_bookings_value,
			q5.ccv_value  as q_5_acv_value,
			q6.ccv_value  as q_6_bookings_value,
			q6.ccv_value  as q_6_acv_value
	     FROM 

		 (SELECT DISTINCT theatre, segment, product, classification 
		 FROM POR_Data WHERE product <>'Managed Services') por
		 LEFT JOIN (SELECT * FROM 
		 
		 (
SELECT theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  SUM(ccv_value) ccv_value,  SUM(acv_value) acv_value,
data_domain FROM POR_Data where  product <> 'Managed Services'
GROUP BY 
theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  
data_domain) a 
	     WHERE data_type='POR' AND data_domain='Virtustream' 
		 AND por_type='Rollover Bookings'
	       AND fiscal_quarter=@current_quarter
	       AND product<>'Managed Services') qk
		     ON por.theatre=qk.theatre
	          AND por.product=qk.product
	          AND por.segment=qk.segment
			  AND por.classification=qk.classification
		   LEFT JOIN 
		   (SELECT * FROM Consolidated_POR_Data WHERE 
		   data_type='Actuals' 
		   AND por_type='Rollover Bookings' AND fiscal_quarter=@current_quarter) q1
		   ON por.theatre=q1.theatre
	          AND por.product=q1.product
	          AND por.segment=q1.segment
			  AND por.classification=q1.classification
			  LEFT JOIN 
		   (SELECT * FROM Consolidated_POR_Data WHERE 
		   data_type='Actuals' AND por_type='Rollover Bookings' AND 
		   fiscal_quarter=@p1_qtr) q2
		   ON por.theatre=q2.theatre
	          AND por.product=q2.product
	          AND por.segment=q2.segment
			  AND por.classification=q2.classification
			    LEFT JOIN 
		   (SELECT * FROM Consolidated_POR_Data WHERE 
		   data_type='Actuals' AND por_type='Rollover Bookings' AND 
		   fiscal_quarter=@p2_qtr) q3
		   ON por.theatre=q3.theatre
	          AND por.product=q3.product
	          AND por.segment=q3.segment
			  AND por.classification=q3.classification
			    LEFT JOIN 
		   (SELECT * FROM Consolidated_POR_Data WHERE 
		   data_type='Actuals' AND por_type='Rollover Bookings' AND 
		   fiscal_quarter=@p3_qtr) q4
		   ON por.theatre=q4.theatre
	          AND por.product=q4.product
	          AND por.segment=q4.segment
			  AND por.classification=q4.classification
			    LEFT JOIN 
		   (SELECT * FROM Consolidated_POR_Data WHERE 
		   data_type='Actuals' AND por_type='Rollover Bookings' AND  
		   fiscal_quarter=@p4_qtr) q5
		   ON por.theatre=q5.theatre
	          AND por.product=q5.product
	          AND por.segment=q5.segment
			  AND por.classification=q5.classification
			    LEFT JOIN 
		   (SELECT * FROM Consolidated_POR_Data WHERE 
		   data_type='Actuals' AND por_type='Rollover Bookings' AND 
		   fiscal_quarter=@p5_qtr) q6
		   ON por.theatre=q6.theatre
	          AND por.product=q6.product
	          AND por.segment=q6.segment
			  AND por.classification=q6.classification
			  )
	  SET @lp=@lp+1 
	  END
----------------------------Final Insert------------------------	
	  INSERT INTO Executive_Por_Data 
	  ( day_of_quarter,--1
	   theatre ,--2
	    product, --3
		segment , --4
		current_fiscal_quarter ,--5
	  dell_emc_segment__c, --6
	  ccv_por_value , --7
	  acv_por_value ,--8
	   q_1_closedate ,--9
	    q_1_bookings_value,--10
		 q_1_acv_value , 
	  	q_2_bookings_value,
		 q_2_acv_value ,
		  q_3_bookings_value, 
		  q_3_acv_value,
		   q_4_bookings_value, 
		   q_4_acv_value,
		    q_5_bookings_value, 
			q_5_acv_value,
			 q_6_bookings_value,
			  q_6_acv_value, 
	  	average_bookings_value,
		 average_acv_value,
		  field_source)
	    ( SELECT day_of_quarter,--1
	             theatre ,--2
	             product,--3
	             segment ,--4
	             current_fiscal_quarter ,--5
--				 CASE WHEN dell_emc_segment__c='Commercial' OR
--dell_emc_segment__c='Enterprise' OR
--dell_emc_segment__c='Federal' THEN 
dell_emc_segment__c 
--END 
as dell_emc_segment__c,--6
	             ccv_por_value ,--7
	             acv_por_value,--8
	             q_1_closedate,--9
	             isnull(q_1_bookings_value,0) as q_1_bookings_value,--10
	             isnull(q_1_acv_value,0),
	             isnull(q_2_bookings_value,0),
	             isnull(q_2_acv_value,0),
	             isnull(q_3_bookings_value,0),
	             isnull(q_3_acv_value,0),
	             isnull(q_4_bookings_value,0),
	             isnull(q_4_acv_value,0),
	             isnull(q_5_bookings_value,0),
	             isnull(q_5_acv_value,0),
	             isnull(q_6_bookings_value,0),
	             isnull(q_6_acv_value,0),
	             ( isnull(q_1_bookings_value,0)+isnull(q_2_bookings_value,0)+ isnull(q_3_bookings_value,0)+
				 isnull(q_4_bookings_value,0)+ isnull(q_5_bookings_value,0)+isnull(q_6_bookings_value,0))/6 
				 as average_bookings_value,
	             ( isnull(q_1_acv_value,0)+isnull(q_2_acv_value,0)+ isnull(q_3_acv_value,0)+isnull(q_4_acv_value,0)+ 
				 isnull(q_5_acv_value,0)+isnull(q_6_acv_value,0))/6 as average_acv_value,
				 'New Bookings' as field_source
	     FROM #Executive_POR_Data_New
		 UNION ALL
		 SELECT day_of_quarter,--1
	             theatre ,
	             product,
	             segment ,
	             current_fiscal_quarter ,
--				 CASE WHEN dell_emc_segment__c='Commercial' OR
--dell_emc_segment__c='Enterprise' OR
--dell_emc_segment__c='Federal' THEN 
dell_emc_segment__c
 --END 
 as dell_emc_segment__c,
	             ccv_por_value ,
	             acv_por_value,
	             q_1_closedate,
	             isnull(q_1_bookings_value,0),
	             isnull(q_1_acv_value,0),
	             isnull(q_2_bookings_value,0),
	             isnull(q_2_acv_value,0),
	             isnull(q_3_bookings_value,0),
	             isnull(q_3_acv_value,0),
	             isnull(q_4_bookings_value,0),
	             isnull(q_4_acv_value,0),
	             isnull(q_5_bookings_value,0),
	             isnull(q_5_acv_value,0),
	             isnull(q_6_bookings_value,0),
	             isnull(q_6_acv_value,0),
	             ( isnull(q_1_bookings_value,0)+isnull(q_2_bookings_value,0)+ isnull(q_3_bookings_value,0)+isnull(q_4_bookings_value,0)+ isnull(q_5_bookings_value,0)+isnull(q_6_bookings_value,0))/6 as average_bookings_value,
	             ( isnull(q_1_acv_value,0)+isnull(q_2_acv_value,0)+ isnull(q_3_acv_value,0)+isnull(q_4_acv_value,0)+ isnull(q_5_acv_value,0)+isnull(q_6_acv_value,0))/6 as average_acv_value,
				 'Rollover Bookings' as field_source
	     FROM #Executive_POR_Data_Rollover
		 )



	  UPDATE Executive_Por_Data
	  SET current_fiscal_period =(SELECT b.fiscal_period FROM fiscalquarters b WHERE b.date=CAST(GETDATE() as date)) 

	  UPDATE Executive_Por_Data
	  SET [current_date] =(SELECT CASE WHEN @run_time>='07:00:00' AND @run_time<='23:59:59' THEN (SELECT GETDATE()) 
						   ELSE (SELECT DATEADD(dd,-1,GETDATE())) END)

				INSERT INTO [dbo].[u_audit_log]
				values('Executive_POR_Data: Object updated',
				1,GETDATE(),NULL, NULL,NULL)			
		 
  END
