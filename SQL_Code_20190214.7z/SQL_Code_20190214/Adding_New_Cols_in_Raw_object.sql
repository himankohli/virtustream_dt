--------------Removing Cols  after Inf changes---------------


ALTER TABLE Opportunity
DROP COLUMN No_TforC_Finance__c


--------------Adding Cols after Inf changes-----------------

ALTER TABLE Lead
ADD  Assigned_to_Sales__c DATETIME,
Lead_In_Qualification__c DATETIME,
Lead_Requires_Action__c DATETIME


ALTER TABLE Contact 
ADD  Contact_In_Qualification__c  DATETIME,
 Contact_Qualified__c DATETIME,
Contact_Requires_Action__c DATETIME

ALTER TABLE Opportunity
ADD Forecast_Alignment__c VARCHAR(255)
