ALTER PROCEDURE Dev_Prod_move
AS
BEGIN
SET NOCOUNT ON


DROP TABLE IF EXISTS Dev_Production.dbo.FiscalQuarters
SELECT * INTO Dev_Production.dbo.FiscalQuarters 
FROM Dev_Staging.dbo.FiscalQuarters

DROP TABLE  IF EXISTS Dev_Production.dbo.Revenue_Schedule_Snapshot 
SELECT * INTO Dev_Production.dbo.Revenue_Schedule_Snapshot 
FROM Dev_Staging.dbo.Revenue_Schedule_Snapshot WHERE Snapshot_type 
IN ('DAY 01' ,'WEEK 01', 'DAY 07','WEEK 13')

DROP TABLE IF EXISTS  Dev_Production.dbo.Product_Line_Snapshot 
SELECT * INTO Dev_Production.dbo.Product_Line_Snapshot 
FROM Dev_Staging.dbo.Product_Line_Snapshot


DROP TABLE  IF EXISTS Dev_Production.dbo.Executive_POR_Data 
SELECT * INTO Dev_Production.dbo.Executive_POR_Data 
FROM Dev_Staging.dbo.Executive_POR_Data

DROP TABLE  IF EXISTS Dev_Production.dbo.u_PLS_wRollover_Waterfall
SELECT * INTO Dev_Production.dbo.u_PLS_wRollover_Waterfall 
FROM Dev_Staging.dbo.u_PLS_wRollover_Waterfall

DROP TABLE IF EXISTS  Dev_Production.dbo.u_Customer
SELECT * INTO Dev_Production.dbo.u_Customer 
FROM Dev_Staging.dbo.u_Customer

DROP TABLE  IF EXISTS Dev_Production.dbo.Revenue_Schedule_Detail
SELECT * INTO Dev_Production.dbo.Revenue_Schedule_Detail 
FROM Dev_Staging.dbo.Revenue_Schedule_Detail


DROP TABLE Dev_Production.dbo.Product_Line_Snapshot_Totals
SELECT * INTO Dev_Production.dbo.Product_Line_Snapshot_Totals 
FROM Dev_Staging.dbo.Product_Line_Snapshot_Totals


DROP TABLE  IF EXISTS Dev_Production.dbo.Opportunity_Header 
SELECT * INTO Dev_Production.dbo.Opportunity_Header 
FROM Dev_Staging.dbo.Opportunity_Header



DROP TABLE IF EXISTS  Dev_Production.dbo.POR_Data
SELECT * INTO Dev_Production.dbo.POR_Data 
FROM Dev_Staging.dbo.POR_Data

DROP TABLE IF EXISTS  Dev_Production.dbo.u_audit_log
SELECT * INTO Dev_Production.dbo.u_audit_log 
FROM Dev_Staging.dbo.u_audit_log

DROP TABLE IF EXISTS   Dev_Production.dbo.u_Account
SELECT * INTO Dev_Production.dbo.u_Account
 FROM Dev_Staging.dbo.u_Account

 DROP TABLE  IF EXISTS Dev_Production.dbo.[OutboundReportPreview]
SELECT * INTO Dev_Production.dbo.[OutboundReportPreview]
 FROM Dev_Staging.dbo.[OutboundReportPreview]

 
 DROP TABLE IF EXISTS  Dev_Production.dbo.[u_sales_rep_performance]
SELECT * INTO Dev_Production.dbo.[u_sales_rep_performance]
 FROM Dev_Staging.dbo.[u_sales_rep_performance]

  DROP TABLE IF EXISTS  Dev_Production.dbo.Latest_PLS_Totals
SELECT * INTO Dev_Production.dbo.Latest_PLS_Totals
 FROM Dev_Staging.dbo.Latest_PLS_Totals

 DROP TABLE IF EXISTS  Dev_Production.dbo.Consolidated_POR_Data
SELECT * INTO Dev_Production.dbo.Consolidated_POR_Data 
FROM Dev_Staging.dbo.Consolidated_POR_Data


SET NOCOUNT OFF

END
