/**

Deletes the temporary tables (if alreadys exists), deletes the the snapshots
older than 13 weeks, and calls the procedures to create the new ones.

**/
ALTER PROCEDURE [dbo].[Revenue_Schedule_Snapshot_Update]
AS
BEGIN 
		SET NOCOUNT ON

	
	DROP TABLE IF EXISTS [quarter]
	DROP TABLE IF EXISTS [OFH_Copy]
	DROP TABLE IF EXISTS [RFH_Copy]
	DROP TABLE IF EXISTS [Opp_copy]
	DROP TABLE IF EXISTS [Rev_copy]
	DROP TABLE IF EXISTS [t_static_opps2]
	DROP TABLE IF EXISTS [t_ofh_last_record]
	DROP TABLE IF EXISTS [t_ofh_last_record2]
	DROP TABLE IF EXISTS [Static_Revs]
	DROP TABLE IF EXISTS [t_rfh_last_record]
	DROP TABLE IF EXISTS [t_rfh_last_record2]
	DROP TABLE IF EXISTS [Opp_Header]
	DROP TABLE IF EXISTS [Revenue_Sch_Detail]
	DROP TABLE IF EXISTS [Opportunity_temp]
	DROP TABLE IF EXISTS [Rev_snap]
	DROP TABLE IF EXISTS [PL_Snap]

	DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))

	DECLARE @run_time TIME=(SELECT FORMAT(GETDATE(),'HH:mm:ss'))

	DECLARE @saturday DATE
	
	SELECT @saturday=(CASE WHEN DATEPART(weekday, @today)>6
	THEN DATEADD(DAY, +5, DATEADD(WEEK, DATEDIFF(WEEK, 0, @today), 0))
	ELSE DATEADD(DAY, -2, DATEADD(WEEK, DATEDIFF(WEEK, 0, @today), 0)) END)
	
	DECLARE @current_quarter NVARCHAR(255)=(SELECT fiscal_qtr FROM fiscalquarters
	where date=(SELECT CAST(GETDATE() AS DATE)))
	
	IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='revenue_schedule_snapshot')
	BEGIN
	CREATE TABLE Revenue_Schedule_Snapshot
	(
		revschd_id nvarchar(255),
		pl_id nvarchar(255),
		pl_name nvarchar(255),
		pl_product__c nvarchar(255),
		pl_service_line__c nvarchar(max) ,
		pl_practice_line__c nvarchar(max) ,
		pl_term__c INT,
		pl_Committed_Term_Months__c INT,
		opp_id nvarchar(255),
		opp_closedate datetime ,
		opp_ownerid nvarchar(255),
		opp_createddate datetime,
		opp_accountid nvarchar(255) ,
		opp_name nvarchar(255) ,
		opp_stagename nvarchar(255),
		opp_probability float,
		opp_type nvarchar(255),
		opp_leadsource nvarchar(255),
		opp_isclosed bit ,
		opp_iswon bit ,
		opp_gate__c nvarchar(255),
		opp_heat_map__c bit,
		opp_primary_data_center__c nvarchar(255),
		opp_sales_channel__c nvarchar(255),
		opp_secondary_data_center__c nvarchar(255),
		opp_opportunity_number__c nvarchar(255),
		opp_sub_segment__c nvarchar(255),
		opp_emc_opportunity_number__c nvarchar(255),
		opp_lead_partner_type__c nvarchar(255),
		opp_lead_partner__c nvarchar(255),
		opp_opportunity_conversion__c bit ,
		opp_related_opportunity__c nvarchar(255),
		opp_related_product_amount__c float,
		opp_so_number__c nvarchar(255),
		opp_dell_technologies_business__c nvarchar(255),
		opp_opportunity_age__c float ,
		opp_pardot_campaign__c nvarchar(255),
		opp_primary_partner_role__c nvarchar(255),
		acc_name nvarchar(255),
		acc_segment__c nvarchar(255),
		acc_dell_emc_segment__c nvarchar(255),
		product_name nvarchar(255),
		product_family nvarchar(255),
		[user_id] nvarchar(255) ,
		[user_name] nvarchar(255),
		user_division nvarchar(255),
		user_department nvarchar(255),
		user_email nvarchar(255),
		user_userroleid nvarchar(255),
		user_managerid nvarchar(255),
		user_forecastenabled bit ,
		ur_owner_role_name nvarchar(255),
		revschd_createddate date,
		revschd_committed_amount__c float,
		revschd_projection__c float,
		revschd_actual__c float ,
		revschd_forecast_amount__c float ,
		revschd_ccv_final float,
		revschd_acv_final float,
		pl_booked_amount_override__c float,
		revschd_booked_amount_final float,
		revschd_fiscal_period__c nvarchar(255),
		m1_role_name nvarchar(255),
		m2_role_name nvarchar(255),
		m3_role_name nvarchar(255),
		m4_role_name nvarchar(255),
		m5_role_name nvarchar(255),
		role_level nvarchar(255),
		hierarchy_global nvarchar(255),
		hierarchy_theatre nvarchar(255),
		hierarchy_segment nvarchar(255),
		hierarchy_division nvarchar(255),
		hierarchy_area nvarchar(255),
		user_employeenumber nvarchar(255),
		opp_country__c nvarchar(255),
		opp_theatre__c nvarchar(255),
		product_quant_practice_group__c nvarchar(255),
		opp_segment__c nvarchar(255),
		opp_close_fiscal_quarter nvarchar(255),
		fiscal_period nvarchar(255),
		ccv_por_value float,
		acv_por_value float,
		field_source nvarchar(255),
		por_type nvarchar(255),
		quota_value nvarchar(255),
		role_quota nvarchar(255),
		territory_quota nvarchar(255) ,
		latest_revschd_ccv_final float,
		latest_revschd_acv_final float,
		latest_revschd_booked_amount_final float,
		latest_stagename nvarchar(255),
		latest_closedate datetime,
		latest_fiscal_quarter nvarchar(255),
		latest_gate nvarchar(255),
		latest_heatmap bit,
		snapshot_type nvarchar(255),
		snapshot_date date,
		snapshot_fiscal_quarter nvarchar(255),
		current_fiscal_period nvarchar(255),
		isharddeleted BIT,
		opp_application_flag BIT
	)

	

	CREATE NONCLUSTERED INDEX ix_rss1
	ON [dbo].[revenue_schedule_snapshot](snapshot_date,snapshot_type)

	CREATE NONCLUSTERED INDEX ix_rss4
	ON Revenue_Schedule_Snapshot(Snapshot_type)
	INCLUDE(latest_revschd_ccv_final ,
		latest_revschd_acv_final ,
		latest_revschd_booked_amount_final ,
		latest_stagename ,
		latest_closedate ,
		latest_fiscal_quarter ,
		latest_gate ,
		latest_heatmap,
		Snapshot_Date,
		Snapshot_Fiscal_Quarter )


	END
	IF(@run_time>='00:00:00' AND @run_time<'08:00:00')
	BEGIN
	DELETE FROM   Revenue_Schedule_Snapshot
	WHERE Snapshot_Date<DATEADD(DD,-7,@today) AND Snapshot_type LIKE 'DAY%'

	END
	ELSE

	BEGIN	

	DELETE FROM   Revenue_Schedule_Snapshot
	WHERE Snapshot_Date<DATEADD(DD,-6,@today) AND Snapshot_type LIKE 'DAY%'

	END
	
	EXEC dbo.Daily_Auto_Backward  @today, @run_time

	DELETE FROM   Revenue_Schedule_Snapshot
	WHERE Snapshot_Date<DATEADD(DD,-91,@today)

	EXEC dbo.Auto_Backward @Saturday
	
	UPDATE  Revenue_Schedule_Snapshot
	SET Current_Fiscal_Period =(SELECT b.Fiscal_Period 
	FROM FiscalQuarters b WHERE b.date=@today)

	UPDATE Revenue_Schedule_Snapshot
	SET opp_Name='Rollover Bookings'
	where field_Source='RolloverBookings'

	
	DROP TABLE IF  EXISTS quarter
	DROP TABLE IF  EXISTS RS_Snapshot

	SELECT rss.*, r.isharddeleted INTO RS_Snapshot
	 FROM(SELECT revschd_id,pl_id,pl_name ,pl_product__c ,
		pl_service_line__c , pl_practice_line__c  , 
		pl_term__c , pl_committed_term_months__c ,opp_id ,opp_closedate  , opp_ownerid ,opp_createddate ,
		opp_accountid,opp_name ,opp_stagename ,opp_probability ,opp_type ,opp_leadsource ,
		opp_isclosed  ,
	opp_iswon,opp_gate__c ,opp_heat_map__c,opp_primary_data_center__c,
	opp_sales_channel__c ,opp_secondary_data_center__c ,
		opp_opportunity_number__c ,opp_sub_segment__c,opp_emc_opportunity_number__c ,opp_lead_partner_type__c ,
		opp_lead_partner__c ,opp_opportunity_conversion__c  ,opp_related_opportunity__c ,opp_related_product_amount__c ,
		opp_so_number__c ,opp_dell_technologies_business__c ,opp_opportunity_age__c ,opp_pardot_campaign__c ,
		opp_primary_partner_role__c ,acc_name ,acc_segment__c ,acc_dell_emc_segment__c ,product_name,
		product_family ,[user_id],[user_name] ,user_division ,user_department ,user_email ,user_userroleid ,
		user_managerid ,user_forecastenabled  ,ur_owner_role_name ,revschd_createddate ,revschd_committed_amount__c ,
		revschd_projection__c ,revschd_actual__c  ,revschd_forecast_amount__c  ,revschd_ccv_final ,revschd_acv_final ,
		pl_booked_amount_override__c ,revschd_booked_amount_final ,revschd_fiscal_period__c ,m1_role_name,
		m2_role_name ,m3_role_name ,m4_role_name ,m5_role_name ,role_level ,hierarchy_global,hierarchy_theatre ,
		hierarchy_segment ,hierarchy_division ,hierarchy_area ,user_employeenumber ,opp_country__c ,opp_theatre__c ,
		product_quant_practice_group__c ,opp_segment__c ,opp_close_fiscal_quarter ,fiscal_period ,ccv_por_value ,
		acv_por_value ,field_source,por_type,quota_value ,role_quota,territory_quota,latest_revschd_ccv_final ,
		latest_revschd_acv_final ,latest_revschd_booked_amount_final ,latest_stagename,latest_closedate ,
		latest_fiscal_quarter,latest_gate,latest_heatmap ,snapshot_type ,snapshot_date ,snapshot_fiscal_quarter,
		current_fiscal_period, opp_application_flag FROM Revenue_Schedule_Snapshot) rss
	LEFT JOIN RevenueSchedule r ON rss.revschd_id=r.id

	
	DROP TABLE IF  EXISTS Revenue_Schedule_Snapshot_bkp

EXEC sp_rename 'Revenue_Schedule_Snapshot', 'Revenue_Schedule_Snapshot_bkp';
EXEC sp_rename 'RS_Snapshot', 'Revenue_Schedule_Snapshot';

	DROP TABLE IF  EXISTS RS_Snapshot
	DROP TABLE IF  EXISTS Revenue_Schedule_Snapshot_bkp

	
	UPDATE  Revenue_Schedule_Snapshot
	SET
	isharddeleted =0
	WHERE field_source='RolloverBookings'
			
END

/*
------------------20/12/2018
ALTER TABLE Revenue_Schedule_Snapshot
ADD  opp_application_flag BIT


UPDATE pls
	SET 
		opp_application_flag=pl.opp_application_flag
	FROM Revenue_Schedule_Snapshot pls JOIN 
	(SELECT * FROM Revenue_Schedule_Snapshot WHERE Snapshot_type='DAY 01'
	) pl ON pls.opp_Id=pl.opp_Id

UAT_PRod_move

*/


