CREATE TABLE #a
(opp_id INT,
opp_name CHAR,
Link VARCHAR(255))

INSERT INTO #a
values (1, 'a', 'qwe,dfgdsg,hthtf,fss,dg')

INSERT INTO #a
values (2, 'b', 'qe,dfgdg,hthf,fs,dggf')

INSERT INTO #a
values (3, 'c', 'qwffe,dfsg,htddhtf,fjkkss,dddg')

SELECT * FROM #a CROSS APPLY string_split(Link,',')


SELECT id, [value] as [Web_CPT_Link]  
FROM 
(SELECT DISTINCT id, Web_CPT_Link__c FROM Opportunity WHERE IsHardDeleted=0) o
 CROSS APPLY string_split(Web_CPT_Link__c,' ')

WHERE [value]  LIKE 'www%' 
OR  [value]  LIKE 'http%'
OR  [value]  LIKE '%com%'
