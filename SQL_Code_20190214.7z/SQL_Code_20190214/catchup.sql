 DROP  TABLE  IF EXISTS #bcd

 CREATE  TABLE #bcd
 (
 pl CHAR,
 prl CHAR,
 sl CHAR,
 lob CHAR,
 opp CHAR,
 stag CHAR,
 ccv FLOAT,
 stag_f CHAR,
 ccv_f FLOAT,
 stag_c CHAR,
 ccv_c FLOAT,
 snapshot_date DATE,
 e_flag BIT,
 valid_flag BIT
 )

 INSERT INTO #bcd ( pl,prl ,sl ,lob ,opp ,stag ,ccv, snapshot_date )
 values('a','b','c','d','e','z',10,'2018-08-10'),
 ('q','b','c','d','e','z',10,'2018-08-10'),
 ('w','d','g','h','j','z',10,'2018-08-10'),
 ('r','t','u','i','o','z',10,'2018-08-10'),
 ('a','b','c','d','e','z',10,'2018-06-15'),
 ('q','b','c','d','e','z',10,'2018-06-15'),
 ('w','d','g','h','j','z',10,'2018-06-15'),
 ('r','t','u','i','o','z',10,'2018-06-15'),
 ('m','l','u','i','o','z',10,'2018-06-15'),
 ('s','p','u','i','n','z',10,'2018-06-15')



 DROP TABLE IF EXISTS #catch
  CREATE TABLE #catch
 (
 prl CHAR,
 sl CHAR,
 lob CHAR,
 opp CHAR,
 stag CHAR,
 ccv FLOAT,
 qtr VARCHAR(50),
 week INT
 )


  INSERT INTO #catch
 values('b','c','d','e','y',12,'2019 Q2',6),
 ('b','c','d','e','y',12,'2019 Q2',6),
 ('d','g','h','j','y',12,'2019 Q2',6),
 ('t','u','i','o','y',12,'2019 Q2',6),
 ('p','u','i','n',NULL,12,'2019 Q2',6)
 
 SELECT * FROM #catch

 SELECT * FROM #bcd


 UPDATE k
 SET ccv_f=CASE WHEN v.rn<>1 THEN 0 ELSE v.ccv_f END,
 stag_f=v.stag_f,
 ccv_c=CASE WHEN v.rn<>1 THEN 0 ELSE v.ccv_c END,
 stag_c=v.stag_c,
 e_flag=v.e_flag,
 valid_flag=v.valid_flag
 FROM  #bcd k LEFT JOIN 
				(SELECT b.pl, b.prl, b.sl, b.lob, b.opp, CASE WHEN c.snapshot_date 
				IS NOT NULL THEN 1 ELSE 0 END as e_flag,
				CASE WHEN c.stag IS NOT NULL AND c.ccv is NOT NULL
				THEN 1 ELSE 0 END as valid_flag,
				CASE WHEN c.snapshot_date IS NULL THEN 1 ELSE			
				 ROW_NUMBER() OVER (PARTITION BY b.prl, b.sl, b.lob, b.opp,b.snapshot_date ORDER BY b.pl) 
				 END as rn, CASE WHEN c.stag IS NOT NULL AND c.ccv is NOT NULL
				THEN COALESCE(c.stag, b.stag) ELSE b.stag END as stag_c, 
				CASE WHEN c.stag IS NOT NULL AND c.ccv is NOT NULL
				THEN COALESCE(c.ccv, b.ccv) ELSE b.ccv END as ccv_c, c.stag as stag_f, c.ccv as ccv_f,
				b.snapshot_date FROM #bcd b LEFT JOIN (SELECT c.prl,c.sl,c.lob,c.opp, 
							MAX(c.stag) as stag, SUM(c.ccv) as ccv, fq.date as snapshot_date
							 FROM #catch c LEFT JOIN FiscalQuarters fq
							 ON c.week=fq.WEEK AND c.qtr=fq.fiscal_qtr
							 GROUP BY c.prl,c.sl,c.lob,c.opp, fq.date) c
				 ON b.prl = c.prl AND b.sl = c.sl AND b.lob = c.lob AND
				 b.opp = c.opp
				 AND b.snapshot_date=c.snapshot_date) v
 ON k.pl=v.pl AND k.snapshot_date=v.snapshot_date