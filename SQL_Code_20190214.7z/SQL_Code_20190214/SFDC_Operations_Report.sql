
ALTER PROCEDURE SFDC_Operations_Data 
(@Period_Start VARCHAR(20), @Period_End VARCHAR(20), 
@a VARCHAR(20)=NULL,@b VARCHAR(20)=NULL)

AS
BEGIN

IF((SELECT COUNT(DISTINCT Fiscal_Period) FROM FiscalQuarters where Fiscal_Period
IN (@Period_Start, @Period_End))=2)
BEGIN

DECLARE @fiscal_qtr VARCHAR(20)
DECLARE @snapshot_date VARCHAR(20)
DECLARE @snapshot_week VARCHAR(20)

IF(SUBSTRING(@a,9,4)='WEEK')
BEGIN
SET @fiscal_qtr =@b
SET @snapshot_week=@a
END
ELSE
BEGIN
		IF(SUBSTRING(@b,9,4)='WEEK')
		BEGIN
		SET @fiscal_qtr=@a
		SET @snapshot_week =@b
		END
		ELSE
		BEGIN
			IF(SUBSTRING(@b,9,1)='')
			BEGIN
			SET @fiscal_qtr=@b
			SET @snapshot_week =@a
			END
			ELSE
			BEGIN
				IF(SUBSTRING(@a,9,1)='')
				BEGIN
				SET @fiscal_qtr=@a
				SET @snapshot_week=@b
				END
			END
		END
END
SELECT @snapshot_date=CAST(MAX(date) as date) FROM FiscalQuarters
where fiscal_qtr=SUBSTRING(@snapshot_week,1,7)
AND WEEK=CAST(SUBSTRING(@snapshot_week,14,2) AS INT)


DECLARE @d date=(SELECT snapshot_date FROM (
SELECT snapshot_date, COUNT(DISTINCT snapshot_type) as ab FROM Revenue_Schedule_Snapshot
GROUP BY snapshot_date) a
where a.ab=2)

DECLARE @p_start DATE=(SELECT Mid_of_Month__c FROM Fiscal_Period__c
where Name=@Period_Start AND isharddeleted=0)

DECLARE @p_end DATE=(SELECT Mid_of_Month__c FROM Fiscal_Period__c
where Name=@Period_End AND isharddeleted=0)


DECLARE @fiscal_period NVARCHAR(MAX)=(SELECT CONCAT((SELECT  DISTINCT  STUFF(
(SELECT DISTINCT '], [' +t1.Name  FROM Fiscal_Period__c t1
where t1.isharddeleted=0 AND t1.Mid_of_Month__c BETWEEN @p_start AND @p_end
FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'') 
FROM Fiscal_Period__c t
where t.isharddeleted=0 AND t.Mid_of_Month__c BETWEEN @p_start AND @p_end),
']'))

DECLARE @a_fiscal_period NVARCHAR(MAX)=(SELECT CONCAT('a.',(SELECT  DISTINCT  STUFF(
(SELECT DISTINCT 'a.[' +t1.Name +'] as ['+t1.Name+' Forecast],' FROM Fiscal_Period__c t1
where t1.isharddeleted=0 AND t1.Mid_of_Month__c BETWEEN @p_start AND @p_end
FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'') 
FROM Fiscal_Period__c t
where t.isharddeleted=0 AND t.Mid_of_Month__c BETWEEN @p_start AND @p_end)))

DECLARE @z_fiscal_period NVARCHAR(MAX)=(SELECT CONCAT('a.',(SELECT  DISTINCT  STUFF(
(SELECT DISTINCT 'z.[' +t1.Name +'] as ['+t1.Name+' Actuals],' FROM Fiscal_Period__c t1
where t1.isharddeleted=0 AND t1.Mid_of_Month__c BETWEEN @p_start AND @p_end
FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'') 
FROM Fiscal_Period__c t
where t.isharddeleted=0 AND t.Mid_of_Month__c BETWEEN @p_start AND @p_end)))
IF (@snapshot_date IS NULL)
SET @snapshot_date=(SELECT DISTINCT snapshot_date FROM Revenue_Schedule_Snapshot 
where snapshot_type='DAY 01'
AND ISNULL(product_quant_practice_group__c,'a') <> 'Managed Services')




IF(@p_start<=@p_end)
BEGIN

DECLARE @s VARCHAR(MAX)=(SELECT CONCAT('SELECT r.pl_practice_line__c AS [Revenue Schedule Practice Line], 
r.pl_service_line__c AS [Revenue Schedule Service Line],
r.product_quant_practice_group__c AS [Quant Segment Practice Group],
SUBSTRING(MAX(r.opp_stagename),1,CHARINDEX(''%'',MAX(r.opp_stagename))) as [Probability],
MAX(r.opp_stagename) as Stage,
MAX(CAST(r.opp_heat_map__c AS INT)) as [Heat Map],
r.opp_id as [Opportunity ID],
MAX(r.opp_opportunity_number__c) as [Opportunity Number],
MAX(r.opp_so_number__c) as [SO Number],
MAX(o.opp_Sold_To__c) as [Sold To],
MAX(r.acc_name) as [Account Name],
MAX(r.opp_name) as [Opportunity],
MAX(r.opp_theatre__c) as [Theater],
MAX(r.opp_segment__c) as [Segment],
CONCAT(''FY '',MAX(r.opp_close_fiscal_quarter)) as [Fiscal Year/Quarter],
CAST(MAX(r.opp_closedate) as DATE) as [Close Date],
MIN(pl.Initial_Start_Date__c) as [Start Date],
MAX(u.Name) as [Owner Name],
MAX(r.opp_country__c) as [Country],
MAX(pl.Initial_Revenue__c) as [Initial Revenue],
CASE WHEN MAX(r.Snapshot_date)>=''2018-11-01'' 
THEN MAX(r.pl_committed_term_months__c)
ELSE MAX(pl.committed_term) END as [Committed Term],
CASE WHEN MAX(r.Snapshot_date)>=''2018-11-01'' 
THEN MAX(r.pl_committed_term_months__c)
ELSE MAX(pl.term) END as [TERM],
MAX(ISNULL(r.pl_booked_amount_override__c,0)) as booked_amount_override,
SUM(ISNULL(r.revschd_ccv_final,0)) as [Committed Contract Value],
SUM(ISNULL(r.revschd_acv_final,0)) as [Annual Contract Value Year1],
SUM(ISNULL(r.revschd_booked_amount_final,0)) as [Booking Amount],
SUM(ISNULL(r.revschd_forecast_amount__c,0)) as [Forecast Amount],
SUM(ISNULL(r.revschd_actual__c,0)) as [Actuals],
MAX(r.opp_type) as [Opportunity Type],
MAX(r.opp_sales_channel__c) as [Sales Channel],
MAX(r.opp_primary_data_center__c) as [Primary Data Center],
MAX(r.opp_secondary_data_center__c) as [Secondary Data Center],
MAX(r.opp_leadsource) as [Lead Source],
MAX(o.Additional_Lead_Sources__c) as [Additional Lead Sources],
MAX(r.opp_sub_segment__c) as [Sub Segment],
MAX(r.opp_lead_partner__c) as [Primary Partner],
MAX(r.opp_lead_partner_type__c) as [Primary Partner Type],
MAX(pl.Job_Code__c) as [Job Code],
MAX(o.Legal_Entity__c) as [Legal Entity],
MAX(pl.WBSE__c) as [WBSE],
MAX(r.acc_dell_emc_segment__c) as [Dell EMC Classification],
MAX(o.Dell_EMC_Alignment__c) as [Dell EMC Division],
r.revschd_fiscal_period__c
INTO #report
FROM Revenue_Schedule_Snapshot r 
LEFT JOIN (SELECT opp.id ,acc.Name as opp_Sold_To__c, opp.Legal_Entity__c,
a.Dell_EMC_Alignment__c,
opp.Additional_Lead_Sources__c FROM Opportunity opp LEFT JOIN Account acc
ON opp.Sold_To__c=acc.Id 
LEFT JOIN (SELECT Id, Dell_EMC_Alignment__c FROM Account where IsHardDeleted=0) a
ON opp.accountId=a.Id
where opp.isharddeleted=0) o
ON r.opp_id=o.Id LEFT JOIN (SELECT p.Id, p.Initial_Start_Date__c, p.Initial_Revenue__c, p.Job_Code__c,
 p.WBSE__c,t.term, ct.committed_term FROM ProductLine p
 LEFT JOIN
(SELECT pl_id , COUNT(DISTINCT revschd_fiscal_period__c) as term FROM Revenue_Schedule_Snapshot 
where
isharddeleted=0 AND ISNULL(product_quant_practice_group__c,''a'') <> ''Managed Services''
AND revschd_id IS NOT NULL 
AND  snapshot_type LIKE (CASE WHEN snapshot_date=''',@d,''' THEN ''DAY%'' ELSE snapshot_type END)
AND snapshot_date=''',@snapshot_date,''' AND field_source=''SFDC''
GROUP BY pl_id) t ON p.Id=t.pl_id
LEFT JOIN
(SELECT pl_id , COUNT(DISTINCT revschd_fiscal_period__c) AS committed_term FROM Revenue_Schedule_Snapshot where
 isharddeleted=0 AND ISNULL(product_quant_practice_group__c,''a'') <> ''Managed Services''
 AND revschd_id IS NOT NULL AND revschd_committed_amount__c IS NOT NULL
 AND snapshot_type LIKE (CASE WHEN snapshot_date=''',@d,''' THEN ''DAY%'' ELSE snapshot_type END)
AND snapshot_date=''',@snapshot_date,''' AND field_source=''SFDC''
GROUP BY pl_id) ct  ON p.Id=ct.pl_id
 WHERE Isharddeleted=0) pl
 ON r.pl_Id=pl.Id
 LEFT JOIN (SELECT Id, [NAme] FROM [User] where isharddeleted=0) u
 ON r.opp_ownerid=u.Id
 where r.isharddeleted=0 AND r.revschd_id IS NOT NULL
 AND ISNULL(r.product_quant_practice_group__c,''a'') <> ''Managed Services''
AND r.snapshot_type LIKE (CASE WHEN r.snapshot_date=''',@d,''' THEN ''DAY%'' ELSE r.snapshot_type END)
AND r.snapshot_date=''',@snapshot_date,''' AND r.field_source=''SFDC''
AND r.opp_close_fiscal_quarter=
CASE WHEN ''',@fiscal_qtr,'''='''' THEN r.opp_close_fiscal_quarter
ELSE ''',@fiscal_qtr,''' END
GROUP BY  r.pl_practice_line__c , 
r.pl_service_line__c ,
r.product_quant_practice_group__c ,
r.opp_id, r.revschd_fiscal_period__c


SELECT DISTINCT
[Revenue Schedule Practice Line], 
[Revenue Schedule Service Line],
[Quant Segment Practice Group],
[Probability],
Stage,
[Heat Map],
 [Opportunity ID],
[Opportunity Number],
[SO Number],
[Sold To],
[Account Name],
[Opportunity],
[Theater],
 [Segment],
[Fiscal Year/Quarter],
[Close Date],
[Start Date],
[Owner Name],
[Country],
[Initial Revenue],
[Committed Term],
[TERM],
[Opportunity Type],
[Sales Channel],
[Primary Data Center],
[Secondary Data Center],
[Lead Source],
[Additional Lead Sources],
[Sub Segment],
[Primary Partner],
[Primary Partner Type],
[Job Code],
[Legal Entity],
[WBSE],
[Dell EMC Classification],
[Dell EMC Division],
',@fiscal_period,' 
  INTO #report_a
FROM
 (SELECT DISTINCT [Revenue Schedule Practice Line], 
[Revenue Schedule Service Line],
[Quant Segment Practice Group],
[Probability],
Stage,
[Heat Map],
 [Opportunity ID],
[Opportunity Number],
[SO Number],
[Sold To],
[Account Name],
[Opportunity],
[Theater],
 [Segment],
[Fiscal Year/Quarter],
[Close Date],
[Start Date],
[Owner Name],
[Country],
[Initial Revenue],
[Committed Term],
[TERM],
[Forecast Amount],
[Opportunity Type],
[Sales Channel],
[Primary Data Center],
[Secondary Data Center],
[Lead Source],
 [Additional Lead Sources],
 [Sub Segment],
[Primary Partner],
 [Primary Partner Type],
 [Job Code],
[Legal Entity],
 [WBSE],
[Dell EMC Classification],
 [Dell EMC Division], revschd_fiscal_period__c FROM #report) AS SOURCE_TABLE
PIVOT 
(SUM([Forecast Amount]) FOR revschd_fiscal_period__c IN
 (',@fiscal_period,'))
AS PIV


SELECT DISTINCT
[Revenue Schedule Practice Line], 
[Revenue Schedule Service Line],
[Quant Segment Practice Group],
[Probability],
Stage,
[Heat Map],
 [Opportunity ID],
[Opportunity Number],
[SO Number],
[Sold To],
[Account Name],
[Opportunity],
[Theater],
 [Segment],
[Fiscal Year/Quarter],
[Close Date],
[Start Date],
[Owner Name],
[Country],
[Initial Revenue],
[Committed Term],
[TERM],
[Opportunity Type],
[Sales Channel],
[Primary Data Center],
[Secondary Data Center],
[Lead Source],
[Additional Lead Sources],
[Sub Segment],
[Primary Partner],
[Primary Partner Type],
[Job Code],
[Legal Entity],
[WBSE],
[Dell EMC Classification],
[Dell EMC Division],
',@fiscal_period,' 
  INTO #report_z
FROM
 (SELECT DISTINCT [Revenue Schedule Practice Line], 
[Revenue Schedule Service Line],
[Quant Segment Practice Group],
[Probability],
Stage,
[Heat Map],
 [Opportunity ID],
[Opportunity Number],
[SO Number],
[Sold To],
[Account Name],
[Opportunity],
[Theater],
 [Segment],
[Fiscal Year/Quarter],
[Close Date],
[Start Date],
[Owner Name],
[Country],
[Initial Revenue],
[Committed Term],
[TERM],
[Actuals],
[Opportunity Type],
[Sales Channel],
[Primary Data Center],
[Secondary Data Center],
[Lead Source],
 [Additional Lead Sources],
 [Sub Segment],
[Primary Partner],
 [Primary Partner Type],
 [Job Code],
[Legal Entity],
 [WBSE],
[Dell EMC Classification],
 [Dell EMC Division], revschd_fiscal_period__c FROM #report) AS SOURCE_TABLE
PIVOT 
(SUM([Actuals]) FOR revschd_fiscal_period__c IN
 (',@fiscal_period,'))
AS PIV

SELECT DISTINCT [Revenue Schedule Practice Line], 
[Revenue Schedule Service Line],
[Quant Segment Practice Group],
[Opportunity ID],
SUM([Committed Contract Value]) as [Committed Contract Value],
SUM([Annual Contract Value Year1]) as [Annual Contract Value Year1],
CASE WHEN MAX(booked_amount_override)<>0 THEN MAX(booked_amount_override)
ELSE SUM([Booking Amount]) END as [Booking Amount]
INTO #report_b
FROm #report
GROUP BY 
[Revenue Schedule Practice Line], 
[Revenue Schedule Service Line],
[Quant Segment Practice Group],
 [Opportunity ID]

SELECT 
a.[Revenue Schedule Practice Line], 
a.[Revenue Schedule Service Line],
a.[Quant Segment Practice Group],
a.[Probability],
a.Stage,
a.[Heat Map],
 a.[Opportunity ID],
a.[Opportunity Number],
a.[SO Number],
a.[Sold To],
a.[Account Name],
a.[Opportunity],
a.[Theater],
 a.[Segment],
a.[Fiscal Year/Quarter],
a.[Close Date],
a.[Start Date],
a.[Owner Name],
a.[Country],
a.[Initial Revenue],
a.[Committed Term],
a.[Term],
b.[Committed Contract Value],
b.[Annual Contract Value Year1],
b.[Booking Amount],
a.[Opportunity Type],
a.[Sales Channel],
a.[Primary Data Center],
a.[Secondary Data Center],
a.[Lead Source],
 a.[Additional Lead Sources],
 a.[Sub Segment],
a.[Primary Partner],
 a.[Primary Partner Type],
 a.[Job Code],
a.[Legal Entity],
 a.[WBSE],
a.[Dell EMC Classification],',
@a_fiscal_period,
 @z_fiscal_period,'a.[Dell EMC Division]
 FROM #report_a a LEFT JOIN #report_b b
 ON a.[Revenue Schedule Practice Line]=b.[Revenue Schedule Practice Line] AND
a.[Revenue Schedule Service Line] = b.[Revenue Schedule Service Line] AND
a.[Quant Segment Practice Group]  = b.[Quant Segment Practice Group] AND
a.[Opportunity ID]  = b.[Opportunity ID]
LEFT JOIN #report_z z
 ON a.[Revenue Schedule Practice Line]=z.[Revenue Schedule Practice Line] AND
a.[Revenue Schedule Service Line] = z.[Revenue Schedule Service Line] AND
a.[Quant Segment Practice Group]  = z.[Quant Segment Practice Group] AND
a.[Opportunity ID]  = z.[Opportunity ID] 
'))

EXEC (@s)

END
ELSE
BEGIN
PRint 'Please enter the [Start Fiscal Period] before the [End Fiscal Period]'
END
END
Print 'Please enter the correct Fiscal Period'
END


SFDC_Operations_Data 'FY 2019 Period 11', 'FY 2019 Period 12','2019 Q4 WEEK 02','2019 Q3'




