
ALTER VIEW v_Sales_Forecast_Numbers
as
WITH snap_week
as
(SELECT snap_wk FROM (VALUES (1),(2),(3),(4),(5),(6),(7),(8),
(9),(10),(11),(12),(13)) snap_wk (snap_wk)),

cq as 
(SELECT fiscal_qtr, WEEK, Fiscal_Period FROM FiscalQuarters
where date=(SELECT CAST(GETDATE() AS DATE)))


SELECT 1 as snapshot_fiscal_week, 1 as opp_close_week,theatre,field_source, lob, segment, classification, opp_application_flag, strategic_alliance_flag,current_week, current_fiscal_period,
 sales_channel, por_type, opp_stagename, opp_ForecastCategory,
opp_heat_map__c,
 SUM(CCV) as ccv,
 SUM(acv) as acv,
 SUM(acv_otlk_value_low) as acv_otlk_value_low,
SUM(acv_otlk_value) as acv_otlk_value,
SUM(acv_otlk_value_high) as acv_otlk_value_high,
SUM(acv_value_pipeline) as acv_value_pipeline,
SUM(ccv_otlk_value_low) as ccv_otlk_value_low,
SUM(ccv_otlk_value) as ccv_otlk_value,
SUM(ccv_otlk_value_high) as ccv_otlk_value_high,
SUM(ccv_value_pipeline) as ccv_value_pipeline
  FROM v_Sales_Forecast
WHERE field_source IN ('Debookings','Finance Adjustments','RolloverBookings') 
AND snapshot_type='DAY 01'
AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM cq)
GROUP BY snapshot_fiscal_week,theatre,field_source, lob, segment, classification, opp_application_flag, strategic_alliance_flag,current_week, current_fiscal_period, 
sales_channel,por_type, opp_stagename, opp_ForecastCategory,
opp_heat_map__c

UNION ALL
SELECT snapshot_fiscal_week,opp_close_week,theatre,field_source, lob, segment, classification, opp_application_flag, strategic_alliance_flag,current_week, current_fiscal_period,
 sales_channel, por_type, opp_stagename, opp_ForecastCategory,
opp_heat_map__c,
 SUM(CCV) as ccv,
 SUM(acv) as acv,
 SUM(acv_otlk_value_low) as acv_otlk_value_low,
SUM(acv_otlk_value) as acv_otlk_value,
SUM(acv_otlk_value_high) as acv_otlk_value_high,
SUM(acv_value_pipeline) as acv_value_pipeline,
SUM(ccv_otlk_value_low) as ccv_otlk_value_low,
SUM(ccv_otlk_value) as ccv_otlk_value,
SUM(ccv_otlk_value_high) as ccv_otlk_value_high,
SUM(ccv_value_pipeline) as ccv_value_pipeline
  FROM v_Sales_Forecast

WHERE field_source='SFDC' AND snapshot_type LIKE 'WEEK%'
AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM cq)
GROUP BY snapshot_fiscal_week, opp_close_week,theatre,field_source, lob, segment, classification, opp_application_flag, strategic_alliance_flag,current_week, current_fiscal_period, 
sales_channel,por_type, opp_stagename, opp_ForecastCategory,
opp_heat_map__c

UNION ALL
SELECT snap_wk as snapshot_fiscal_week,
opp_close_week,theatre,field_source, lob, segment, classification, opp_application_flag, strategic_alliance_flag,current_week, current_fiscal_period, sales_channel,por_type, opp_stagename, opp_ForecastCategory,
opp_heat_map__c, 
ccv, acv, acv_otlk_value_low, acv_otlk_value,acv_otlk_value_high, acv_value_pipeline,
 ccv_otlk_value_low, ccv_otlk_value, ccv_otlk_value_high, ccv_value_pipeline FROM
(SELECT snap_wk FROM snap_week
where snap_wk>=(SELECT DISTINCT snapshot_fiscal_week FROM v_Sales_Forecast
where snapshot_type='DAY 01')) a
CROSS JOIN

(SELECT snapshot_fiscal_week,opp_close_week,theatre,field_source, lob, segment, classification, opp_application_flag, strategic_alliance_flag,current_week, current_fiscal_period, sales_channel,por_type, opp_stagename, opp_ForecastCategory,
opp_heat_map__c, SUM(CCV) as ccv,
 SUM(acv) as acv,
SUM(acv_otlk_value_low) as acv_otlk_value_low,
SUM(acv_otlk_value) as acv_otlk_value,
SUM(acv_otlk_value_high) as acv_otlk_value_high,
SUM(acv_value_pipeline) as acv_value_pipeline,
SUM(ccv_otlk_value_low) as ccv_otlk_value_low,
SUM(ccv_otlk_value) as ccv_otlk_value,
SUM(ccv_otlk_value_high) as ccv_otlk_value_high,
SUM(ccv_value_pipeline) as ccv_value_pipeline FROM v_Sales_Forecast
WHERE field_source='SFDC' AND snapshot_type='DAY 01'
AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM cq)
GROUP BY snapshot_fiscal_week, opp_close_week,theatre,field_source, lob, segment, classification, opp_application_flag, strategic_alliance_flag,current_week, current_fiscal_period, 
sales_channel,por_type, opp_stagename, opp_ForecastCategory,
opp_heat_map__c) b 




---------------------------------------------------------------
UNION ALL
SELECT Week  as snapshot_fiscal_week,
Week  as opp_close_week,theatre,data_type as field_source, product as lob, segment, classification, 
NULL as opp_application_flag,NULL as  strategic_alliance_flag,
(SELECT DISTINCT WEEK FROM cq) as current_week,
(SELECT DISTINCT Fiscal_Period FROM cq) as current_fiscal_period,
NULL as  sales_channel,por_type, 
NULL as opp_stagename, NULL as opp_ForecastCategory,
NULL as opp_heat_map__c, 
ccv_value as ccv, acv_value acv,NULL as   acv_otlk_value_low,NULL as   acv_otlk_value,
NULL as  acv_otlk_value_high, NULL as acv_value_pipeline,
NULL as   ccv_otlk_value_low,NULL as   ccv_otlk_value,NULL as   ccv_otlk_value_high ,
NULL as ccv_value_pipeline

 FROM POR_Data
 where fiscal_quarter=(SELECT fiscal_qtr FROM cq)









--SELECT SUM(ccv) FROM v_Sales_Forecast_Numbers
--where field_source  IN ('Debookings') 
--AND snapshot_fiscal_week=1
--AND opp_close_fiscal_quarter='2019 Q4'


