ALTER VIEW v_Sales_Forecast
AS

with 
cq as (SELECT * FROM FiscalQuarters where fiscal_qtr=
(SELECT fiscal_qtr FROM FiscalQuarters
where date=(SELECT CAST(GETDATE() AS DATE)))),

opps_wo_pl as 
(SELECT  b.opp_id, 
opp_name, 
opp_closedate, 
opp_stagename, 
opp_heat_map__c, 
acc_name, 
acc_dell_emc_segment__c, 
opp_theatre__c, 
CAST(NULL AS NVARCHAR(255)) as product_quant_practice_group__c, 
opp_segment__c,
opp_close_fiscal_quarter, 
--opp_ForecastCategory, 
opp_forecast_alignment__c,
field_source,
por_type, 
CAST(NULL AS FLOAT)  as revschd_acv_final, 
CAST(NULL AS FLOAT)  as revschd_booked_amount_final,
opp_application_flag, 
strategic_alliance_flag, 
sales_channel, opp_opportunity_age__c,opp_opportunity_number__c , closedate_change_count, m3_role_name, user_name,
b.snapshot_type, 
b.snapshot_date, 
snapshot_fiscal_quarter
	FROM (
	SELECT 
	* FROM (SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=1 ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT opp_Id FROM Opportunity_Header)
	GROUP BY snapshot_type, snapshot_date, opp_id) a EXCEPT
	(SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=0 ANd snapshot_type<='WEEK 13'
	GROUP BY snapshot_type, snapshot_date, opp_id)
	UNION ALL
	SELECT DISTINCT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where field_Source ='SFDC' AND isharddeleted IS NULL ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT opp_Id FROM Opportunity_Header)
	) a JOIN (SELECT *, ROW_NUMBER() OVER (PARTITION BY snapshot_Type, snapshot_date, opp_id
	ORDER BY pl_id) as Rk FROM Product_Line_Snapshot where (isharddeleted=1 OR isharddeleted IS NULL)) b
	ON a.snapshot_type=b.snapshot_type AND a.snapshot_date=b.snapshot_date
	AND a.opp_id=b.opp_id
	WHERE b.Rk=1 AND ISNULL(b.product_quant_practice_group__c,'a')<>'Managed Services'
				AND ISNULL(b.opp_type,'a') <> 'CSP-Sell Out')

	
SELECT opp_id, 
opp_name, 
opp_stagename, 
opp_heat_map__c,
acc_name,   
SUM(ISNULL(revschd_booked_amount_final,0)) as ccv, 
SUM(ISNULL(revschd_acv_final,0)) as acv,
opp_theatre__c as theatre, 
product_quant_practice_group__c as lob, 
opp_segment__c as segment,
acc_dell_emc_segment__c as classification,
opp_close_fiscal_quarter, 
opp_ForecastCategory,
CASE WHEN field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR opp_ForecastCategory in ('Low Range') 
then sum(ISNULL(revschd_acv_final,0)) else 0 end as acv_otlk_value_low,

case when field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR  opp_ForecastCategory in ('Low Range','Outlook') then sum(ISNULL(revschd_acv_final,0)) else 0 end  as acv_otlk_value,

case when field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR  opp_ForecastCategory in ('Low Range','Outlook','High Range') then sum(ISNULL(revschd_acv_final,0)) else 0 end  as acv_otlk_value_high,

case when field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR  opp_ForecastCategory in ('Low Range','Outlook','High Range','Pipeline') 
then sum(ISNULL(revschd_acv_final,0)) else 0 end  as acv_value_pipeline,

case when field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR  opp_ForecastCategory in ('Low Range') then sum(ISNULL(revschd_booked_amount_final,0)) else 0 end as ccv_otlk_value_low,

case when field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR  opp_ForecastCategory in ('Low Range','Outlook') then sum(ISNULL(revschd_booked_amount_final,0)) else 0 end  as ccv_otlk_value,

case when field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR  opp_ForecastCategory in ('Low Range','Outlook','High Range') then sum(ISNULL(revschd_booked_amount_final,0)) else 0 end  as ccv_otlk_value_high,

case when field_source IN ('Debookings','Finance Adjustments',
'RolloverBookings') OR  opp_ForecastCategory in ('Low Range','Outlook','High Range','Pipeline') 
then sum(ISNULL(revschd_booked_amount_final,0)) else 0 end  as ccv_value_pipeline,

field_source, 
por_type, 
fq.[WEEK] as opp_close_week,
opp_application_flag,
strategic_alliance_flag,
sales_channel
,opp_closedate, opp_opportunity_age__c,opp_opportunity_number__c , closedate_change_count, m3_role_name, user_name,
NULL as Margin, 
snapshot_type,
(SELECT DISTINCT Fiscal_Period FROM FiscalQuarters
where date=(SELECT CAST(GETDATE() AS DATE))) as current_fiscal_period,
fcq.WEEK as snapshot_fiscal_week,
(SELECT DISTINCT WEEK FROM cq 
where date=(SELECT CAST(GETDATE() AS DATE))) as current_week

FROM 

(SELECT opp_id, opp_name, opp_closedate, opp_stagename, opp_heat_map__c, acc_name, 
acc_dell_emc_segment__c, opp_theatre__c, 
product_quant_practice_group__c, opp_segment__c,
opp_close_fiscal_quarter, opp_forecast_alignment__c as opp_ForecastCategory, field_source,
por_type, revschd_acv_final, revschd_booked_amount_final,
opp_application_flag, strategic_alliance_flag, sales_channel
, opp_opportunity_age__c,opp_opportunity_number__c , closedate_change_count, m3_role_name, user_name,
snapshot_type, snapshot_date 
FROM Product_Line_Snapshot WHERE snapshot_type='Day 01' 
AND ISNULL(product_quant_practice_group__c,'a')<>'Managed Services' 
AND field_source<>'POR'
UNION ALL
SELECT opp_id, opp_name, opp_closedate, opp_stagename,
opp_heat_map__c, acc_name, 
acc_dell_emc_segment__c, opp_theatre__c, 
product_quant_practice_group__c, opp_segment__c,
opp_close_fiscal_quarter, opp_forecast_alignment__c as opp_ForecastCategory, field_source,
por_type, revschd_acv_final, revschd_booked_amount_final,
opp_application_flag, strategic_alliance_flag, sales_channel
, opp_opportunity_age__c,opp_opportunity_number__c , closedate_change_count, m3_role_name, user_name,
snapshot_type, snapshot_date FROM Product_Line_Snapshot WHERE snapshot_type LIKE 'WEEK%'
AND snapshot_fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters
where date=(SELECT CAST(GETDATE() AS DATE)))
AND ISNULL(product_quant_practice_group__c,'a')<>'Managed Services' 
AND field_source<>'POR'
AND isharddeleted=0
UNION ALL
SELECT opp_id, opp_name, opp_closedate, opp_stagename, 
opp_heat_map__c,acc_name, 
acc_dell_emc_segment__c, opp_theatre__c, 
product_quant_practice_group__c, opp_segment__c,
opp_close_fiscal_quarter, opp_forecast_alignment__c as opp_ForecastCategory, field_source,
por_type, revschd_acv_final, revschd_booked_amount_final,
opp_application_flag, strategic_alliance_flag, sales_channel 
, opp_opportunity_age__c,opp_opportunity_number__c , closedate_change_count, m3_role_name, user_name, 
snapshot_type, snapshot_date
FROM opps_wo_pl WHERE snapshot_type LIKE 'WEEK%'
AND snapshot_fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters
where date=(SELECT CAST(GETDATE() AS DATE)))
AND ISNULL(product_quant_practice_group__c,'a')<>'Managed Services' 
AND field_source<>'POR')
pls LEFT JOIN FiscalQuarters fq ON pls.opp_closedate = fq.date
LEFT JOIN cq fcq ON pls.snapshot_date=fcq.date
GROUP BY opp_id, 
opp_name, 
opp_stagename,
opp_heat_map__c, 
acc_name, 
opp_closedate,
acc_dell_emc_segment__c, 
opp_theatre__c, 
product_quant_practice_group__c, 
opp_segment__c,
opp_close_fiscal_quarter, 
opp_ForecastCategory, 
field_source,
por_type, fq.[WEEK],
opp_application_flag,
strategic_alliance_flag, 
sales_channel, opp_opportunity_age__c,opp_opportunity_number__c , closedate_change_count, m3_role_name, user_name, 
snapshot_type, fcq.WEEK
---------------------------------POR UNION-----------------
UNION ALL 
SELECT NULL as opp_id, 
NULL as  opp_name, 
NULL as opp_stagename, 
NULL as opp_heat_map__c,
NULL as acc_name,   
ccv_value as ccv, 
acv_value as acv,
theatre, 
product as lob, 
segment, classification,
fiscal_quarter as opp_close_fiscal_quarter, 
NULL as opp_ForecastCategory,
NULL as acv_otlk_value_low,
NULL as acv_otlk_value,
NULL as acv_otlk_value_high,
NULL as acv_value_pipeline,
NULL as ccv_otlk_value_low,
NULL as ccv_otlk_value,
NULL as ccv_otlk_value_high,
NULL as ccv_value_pipeline, 
data_type as field_source,
por_type, [Week] as opp_close_week,
NULL as opp_application_flag,
NULL as strategic_alliance_flag,
NULL as sales_channel
,NULL as opp_closedate,NULL as  opp_opportunity_age__c,
NULL as opp_opportunity_number__c ,NULL as  closedate_change_count, 
NULL as m3_role_name, NULL as user_name,
NULL as Margin,
'DAY 01' as snapshot_type,
(SELECT DISTINCT Fiscal_Period FROM FiscalQuarters
where date=(SELECT CAST(GETDATE() AS DATE))) as current_fiscal_period,
(SELECT DISTINCT WEEK FROM cq 
where date=(SELECT CAST(GETDATE() AS DATE))) as snapshot_fiscal_week,
(SELECT DISTINCT WEEK FROM cq 
where date=(SELECT CAST(GETDATE() AS DATE))) as current_week
 FROM POR_Data where product<>'Managed Services'


 
--SELECT field_source, snapshot_type, count(*) FROM v_Sales_Forecast
--GROUP BY field_source, snapshot_type


--SELECT * FROM v_Sales_Forecast where snapshot_Type='DAY 01' AND field_source='SFDC'
--AND opp_close_fiscal_quarter='2019 Q4'  AND opp_id='0061R00000l5EW8QAM'

