ALTER VIEW v_OppScore
as 
SELECT pl.snapshot_fiscal_quarter, pl.snapshot_date, sw.snapshot_week,
opp_id, opp_name, opp_closedate, opp_ownerid,
opp_createddate, opp_accountid, opp_stagename 
, opp_heat_map__c, opp_sales_channel__c, opp_opportunity_age__c, acc_name, user_managerid,
opp_theatre__c, product_quant_practice_group__c, opp_segment__c, opp_close_fiscal_quarter,
opp_forecast_alignment__c
, SUBSTRING(MAX(opp_stagename),1,CHARINDEX('%',MAX(opp_stagename))) as opp_probability

FROM Product_Line_Snapshot pl

LEFT JOIN
(SELECT snapshot_fiscal_quarter, snapshot_type, snapshot_date
,ROW_NUMBER() OVER (PARTITION BY snapshot_fiscal_quarter ORDER BY Snapshot_date) as snapshot_week
FROM Product_Line_Snapshot
where field_source='SFDC' AND isharddeleted=0
AND snapshot_type<='WEEK 91'
AND (snapshot_type LIKE 'WEEK%' OR snapshot_type='DAY 01')
GROUP BY
snapshot_type, snapshot_date, snapshot_fiscal_quarter) sw
ON pl.snapshot_fiscal_quarter=sw.snapshot_fiscal_quarter AND pl.snapshot_date=sw.snapshot_date

where field_source='SFDC' AND isharddeleted=0
AND pl.snapshot_type<='WEEK 91'
AND (pl.snapshot_type LIKE 'WEEK%' OR pl.snapshot_type='DAY 01')
GROUP BY
 pl.snapshot_date, pl.snapshot_fiscal_quarter, sw.snapshot_week,
opp_id, opp_name, opp_closedate, opp_ownerid,
opp_createddate, opp_accountid, opp_stagename
, opp_heat_map__c, opp_sales_channel__c, opp_opportunity_age__c, acc_name, user_managerid,
opp_theatre__c, product_quant_practice_group__c, opp_segment__c, opp_close_fiscal_quarter,
opp_forecast_alignment__c


