
ALTER view [dbo].[v_Channel] as

with last_qtr_final as (select distinct snapshot_type 
FROM Product_Line_Snapshot where snapshot_date in (
select qtr_last_date from FiscalQuarters
where cast([date] as date)=cast(dateadd(week,-13,getdate()) as date))),

opps_wo_pl as (SELECT  CAST(NULL AS NVARCHAR(255)) as [pl_id]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_name]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_product__c]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_service_line__c]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_practice_line__c]
      ,  CAST(NULL AS FLOAT)  as [pl_booked_amount__c]
      ,  CAST(NULL AS FLOAT)  as [pl_annual_contact_value_year_1__c]
      ,  CAST(NULL AS FLOAT)  as [pl_committed_contract_value__c]
      ,b.[opp_id]
      ,[opp_closedate]
      ,[opp_ownerid]
      ,[opp_createddate]
      ,[opp_accountid]
      ,[opp_name]
      ,[opp_stagename]
      ,[opp_probability]
      ,[opp_type]
      ,[opp_leadsource]
      ,[opp_isclosed]
      ,[opp_iswon]
      ,[opp_gate__c]
      ,[opp_heat_map__c]
      ,[opp_primary_data_center__c]
      ,[opp_sales_channel__c]
      ,[opp_secondary_data_center__c]
      ,[opp_opportunity_number__c]
      ,[opp_sub_segment__c]
      ,[opp_emc_opportunity_number__c]
      ,[opp_lead_partner_type__c]
      ,[opp_lead_partner__c]
      ,[opp_opportunity_conversion__c]
      ,[opp_related_opportunity__c]
      ,[opp_related_product_amount__c]
      ,[opp_so_number__c]
      ,[opp_dell_technologies_business__c]
      ,[opp_opportunity_age__c]
      ,[opp_pardot_campaign__c]
      ,[opp_primary_partner_role__c]
      ,[acc_name]
      ,[acc_segment__c]
      ,[acc_dell_emc_segment__c]
      ,[product_name]
      ,[product_family]
      ,[user_id]
      ,[user_name]
      ,[user_division]
      ,[user_department]
      ,[user_email]
      ,[user_userroleid]
      ,[user_managerid]
      ,[user_forecastenabled]
      ,[ur_owner_role_name]
      , CAST(NULL AS FLOAT) as [revschd_committed_amount__c]
      , CAST(NULL AS FLOAT) as [revschd_projection__c]
      , CAST(NULL AS FLOAT) as [revschd_actual__c]
      , CAST(NULL AS FLOAT) as [revschd_forecast_amount__c]
      , CAST(NULL AS FLOAT) as [revschd_ccv_final]
      , CAST(NULL AS FLOAT) as [revschd_acv_final]
      , CAST(NULL AS FLOAT) as [revschd_booked_amount_final]
      ,[m1_role_name]
      ,[m2_role_name]
      ,[m3_role_name]
      ,[m4_role_name]
      ,[m5_role_name]
      ,[role_level]
      ,[hierarchy_global]
      ,[hierarchy_theatre]
      ,[hierarchy_segment]
      ,[hierarchy_division]
      ,[hierarchy_area]
      ,[user_employeenumber]
      ,[opp_country__c]
      ,[opp_theatre__c]
      , CAST(NULL AS NVARCHAR(255)) as [product_quant_practice_group__c]
      ,[opp_segment__c]
      ,[opp_close_fiscal_quarter]
      ,[fiscal_period]
      ,[id_rev_schd]
      ,[ccv_por_value]
      ,[acv_por_value]
      ,[field_source]
      ,[por_type]
      ,[quota_value]
      ,[role_quota]
      ,[territory_quota]
      ,[latest_annual_contact_value_year_1__c]
      ,[latest_committed_contract_value__c]
      ,[latest_booked_amount__c]
      ,[latest_revschd_ccv_final]
      ,[latest_revschd_acv_final]
      ,[latest_revschd_booked_amount_final]
      ,[latest_stagename]
      ,[latest_closedate]
      ,[latest_fiscal_quarter]
      ,[latest_gate]
      ,[latest_heatmap]
      ,b.[snapshot_type]
      ,b.[snapshot_date]
      ,[snapshot_fiscal_quarter]
      ,[current_fiscal_period]
      ,[isharddeleted]
      ,[strategic_alliance_flag]
      ,[latest_strategic_alliance_flag]
      ,[latest_theatre]
      ,[latest_lob]
      ,[latest_segment] 
      ,[latest_dell_emc_segment]
      ,[opp_application_flag]
      ,[latest_opp_application_flag]
      ,[closedate_change_count]
      ,[channel]
      ,[opp_dell_technologies_role__c]
      ,[latest_primary_partner_role__c]
      ,[latest_channel]
      ,[latest_dell_technologies_role__c]
      ,[sales_channel]
      ,[latest_sales_channel],
	  opp_ForecastCategory, opp_forecast_alignment__c
	  FROM (
	SELECT 
	* FROM (SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=1 ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT opp_Id FROM Opportunity_Header)
	GROUP BY snapshot_type, snapshot_date, opp_id) a EXCEPT
	(SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=0 ANd snapshot_type<='WEEK 13'
	GROUP BY snapshot_type, snapshot_date, opp_id)
	UNION ALL
	SELECT DISTINCT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where field_Source ='SFDC' AND isharddeleted IS NULL ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT opp_Id FROM Opportunity_Header)
	) a JOIN (SELECT *, ROW_NUMBER() OVER (PARTITION BY snapshot_Type, snapshot_date, opp_id
	ORDER BY pl_id) as Rk FROM Product_Line_Snapshot where (isharddeleted=1 OR isharddeleted IS NULL)) b
	ON a.snapshot_type=b.snapshot_type AND a.snapshot_date=b.snapshot_date
	AND a.opp_id=b.opp_id
	WHERE b.Rk=1 AND ISNULL(b.product_quant_practice_group__c,'a')<>'Managed Services'
				AND ISNULL(b.opp_type,'a') <> 'CSP-Sell Out'
	
	)

SELECT pls.opp_id,
	oh.opp_opportunity_number__c,
	pls.acc_name,
	oh.Dell_Technologies_Role__c as dell_technologies_role_c,
	pls.pl_id,
	pls.opp_primary_partner_role__c,
	pls.opp_leadsource,
	pls.opp_lead_partner__c,
	pls.opp_dell_technologies_business__c,
	pls.opp_lead_partner_type__c,
	pls.acc_dell_emc_segment__c,
	pls.opp_theatre__c,
	pls.opp_segment__c,
	pls.product_quant_practice_group__c as lob,
	pls.opp_stagename,
	pls.opp_heat_map__c,
	pls.opp_closedate,
	pl_booked_amount__c,
	pl_annual_contact_value_year_1__c,
	pls.field_source,
	pls.opp_close_fiscal_quarter,
	pls.opp_type,
	pls.opp_application_flag,
	current_fiscal_period,
	oh.current_week_num as current_fiscal_week, 
	pls.snapshot_type  as snapshot_type,
	oh.acc_partner_type__c as lead_partner_type,
	pls.opp_name,
	pls.user_name as opp_owner_name,
	pls.m3_role_name as division,
	pls.opp_opportunity_age__c,
	pls.closedate_change_count,
case when pls.opp_leadsource='Dell Technologies' then oh.Dell_Technologies_Role__c
else pls.opp_primary_partner_role__c end as [role_mapped],
case when pls.opp_leadsource='Dell Technologies' and pls.opp_lead_partner__c is not null then 'Common Rows' else 'Normal' end as [data_type]
from (SELECT * FROM Product_Line_Snapshot where
isharddeleted=0  and field_source='SFDC' UNION SELECT * FROM opps_wo_pl) pls
left join Opportunity_Header oh
on pls.opp_id=oh.opp_id
where pls.snapshot_type in ('DAY 01','WEEK 01','Week 13')
 and ISNULL(pls.product_quant_practice_group__c,'a')<>'Managed Services'
 and ISNULL(pls.opp_type,'a') <>'CSP-Sell Out'  



union all                             

select pls.opp_id,oh.opp_opportunity_number__c,pls.acc_name,oh.Dell_Technologies_Role__c as dell_technologies_role_c,pls.pl_id,pls.opp_primary_partner_role__c,pls.opp_leadsource,pls.opp_lead_partner__c,pls.opp_dell_technologies_business__c,pls.opp_lead_partner_type__c,
pls.acc_dell_emc_segment__c,pls.opp_theatre__c,pls.opp_segment__c,pls.product_quant_practice_group__c as lob,pls.opp_stagename,pls.opp_heat_map__c,pls.opp_closedate,pl_booked_amount__c,pl_annual_contact_value_year_1__c,pls.field_source,pls.opp_close_fiscal_quarter,pls.opp_type,
pls.opp_application_flag,
current_fiscal_period,
oh.current_week_num as current_fiscal_week, 
 pls.snapshot_type  as snapshot_type,oh.acc_partner_type__c as lead_partner_type,
 pls.opp_name,
	pls.user_name as opp_owner_name,
	pls.m3_role_name as division,
	pls.opp_opportunity_age__c,
	pls.closedate_change_count,
case when pls.opp_leadsource='Dell Technologies' then oh.Dell_Technologies_Role__c
else pls.opp_primary_partner_role__c end as [role_mapped],
 'Append'  as [data_type]
from (SELECT * FROM Product_Line_Snapshot where
 isharddeleted=0  and field_source='SFDC' UNION SELECT * FROM opps_wo_pl) pls
left join Opportunity_Header oh
on pls.opp_id=oh.opp_id
where   pls.snapshot_type in ('DAY 01','WEEK 01','Week 13')
 and ISNULL(pls.product_quant_practice_group__c, 'a' ) <>'Managed Services' 
and  ISNULL(pls.opp_type,'a') <>'CSP-Sell Out'   and pls.opp_leadsource='Dell Technologies' 
and pls.opp_lead_partner__c is not null

union all


select pls.opp_id,oh.opp_opportunity_number__c,pls.acc_name,oh.Dell_Technologies_Role__c as dell_technologies_role_c,pls.pl_id,pls.opp_primary_partner_role__c,pls.opp_leadsource,pls.opp_lead_partner__c,pls.opp_dell_technologies_business__c,pls.opp_lead_partner_type__c,
pls.acc_dell_emc_segment__c,pls.opp_theatre__c,pls.opp_segment__c,pls.product_quant_practice_group__c as lob,pls.opp_stagename,pls.opp_heat_map__c,pls.opp_closedate,pl_booked_amount__c,pl_annual_contact_value_year_1__c,pls.field_source,pls.opp_close_fiscal_quarter,pls.opp_type,
pls.opp_application_flag,
current_fiscal_period,
oh.current_week_num as current_fiscal_week, 
 'LQ Final' 
 as snapshot_type
,oh.acc_partner_type__c as lead_partner_type,
pls.opp_name,
	pls.user_name as opp_owner_name,
	pls.m3_role_name as division,
	pls.opp_opportunity_age__c,
	pls.closedate_change_count,
case when pls.opp_leadsource='Dell Technologies' then oh.Dell_Technologies_Role__c
else pls.opp_primary_partner_role__c end as [role_mapped],
case when pls.opp_leadsource='Dell Technologies' and pls.opp_lead_partner__c is not null then 'Common Rows' else 'Normal' end as [data_type]
from (SELECT * FROM Product_Line_Snapshot where
isharddeleted=0  and field_source='SFDC' UNION SELECT * FROM opps_wo_pl) pls
left join Opportunity_Header oh
on pls.opp_id=oh.opp_id
where pls.snapshot_type in ((select distinct snapshot_type from last_qtr_final))
 and ISNULL(pls.product_quant_practice_group__c, 'a' ) <>'Managed Services'
and ISNULL(pls.opp_type,'a') <>'CSP-Sell Out'   



union all                             

select pls.opp_id,oh.opp_opportunity_number__c,pls.acc_name,oh.Dell_Technologies_Role__c as dell_technologies_role_c,pls.pl_id,pls.opp_primary_partner_role__c,pls.opp_leadsource,pls.opp_lead_partner__c,pls.opp_dell_technologies_business__c,pls.opp_lead_partner_type__c,
pls.acc_dell_emc_segment__c,pls.opp_theatre__c,pls.opp_segment__c,pls.product_quant_practice_group__c as lob,pls.opp_stagename,pls.opp_heat_map__c,pls.opp_closedate,pl_booked_amount__c,pl_annual_contact_value_year_1__c,pls.field_source,pls.opp_close_fiscal_quarter,pls.opp_type,
pls.opp_application_flag,
current_fiscal_period,
oh.current_week_num as current_fiscal_week, 
 'LQ Final' 
snapshot_type,oh.acc_partner_type__c as lead_partner_type,
pls.opp_name,
	pls.user_name as opp_owner_name,
	pls.m3_role_name as division,
	pls.opp_opportunity_age__c,
	pls.closedate_change_count,
case when pls.opp_leadsource='Dell Technologies' then oh.Dell_Technologies_Role__c
else pls.opp_primary_partner_role__c end as [role_mapped],
 'Append'  as [data_type]
from  (SELECT * FROM Product_Line_Snapshot where
 isharddeleted=0  and field_source='SFDC' UNION SELECT * FROM opps_wo_pl) pls
left join Opportunity_Header oh
on pls.opp_id=oh.opp_id
where pls.snapshot_type in ((select distinct snapshot_type from last_qtr_final))
 and ISNULL(pls.product_quant_practice_group__c, 'a' ) <>'Managed Services' 
and ISNULL(pls.opp_type,'a') <>'CSP-Sell Out'   and pls.opp_leadsource='Dell Technologies' and pls.opp_lead_partner__c is not null

---------------------------------
union all


select pls.opp_id,
	oh.opp_opportunity_number__c,
	pls.acc_name,
	oh.Dell_Technologies_Role__c as dell_technologies_role_c,
	pls.pl_id,
	pls.opp_primary_partner_role__c,
	pls.opp_leadsource,
	pls.opp_lead_partner__c,
	pls.opp_dell_technologies_business__c,
	pls.opp_lead_partner_type__c,
	pls.acc_dell_emc_segment__c,
	pls.opp_theatre__c,
	pls.opp_segment__c,
	pls.product_quant_practice_group__c as lob,
	pls.opp_stagename,
	pls.opp_heat_map__c,
	pls.opp_closedate,
	pl_booked_amount__c,
	pl_annual_contact_value_year_1__c,
	pls.field_source,
	pls.opp_close_fiscal_quarter,
	pls.opp_type,
	pls.opp_application_flag,
	current_fiscal_period,
	oh.current_week_num as current_fiscal_week, 


	 'Baseline' 
	 as snapshot_type
,oh.acc_partner_type__c as lead_partner_type,
pls.opp_name,
	pls.user_name as opp_owner_name,
	pls.m3_role_name as division,
	pls.opp_opportunity_age__c,
	pls.closedate_change_count,
case when pls.opp_leadsource='Dell Technologies' then oh.Dell_Technologies_Role__c
else pls.opp_primary_partner_role__c end as [role_mapped],
case when pls.opp_leadsource='Dell Technologies' and pls.opp_lead_partner__c is not null then 'Common Rows' else 'Normal' end as [data_type]
from  (SELECT * FROM Product_Line_Snapshot where
isharddeleted=0  and field_source='SFDC' UNION SELECT * FROM opps_wo_pl) pls
left join Opportunity_Header oh
on pls.opp_id=oh.opp_id
where pls.snapshot_type in ((select 'Week '+
case when len((select cast((select top 1 current_week_num-4 from Opportunity_Header) as varchar(2))))=1 then '0'+(select cast((select top 1 current_week_num-4 from Opportunity_Header) as varchar(2))) else (select cast((select top 1 current_week_num-4 from Opportunity_Header) as varchar(2))) end))
 and ISNULL(pls.product_quant_practice_group__c, 'a' ) <>'Managed Services' 
and ISNULL(pls.opp_type,'a') <>'CSP-Sell Out'    



union all                             

select pls.opp_id,oh.opp_opportunity_number__c,pls.acc_name,oh.Dell_Technologies_Role__c as dell_technologies_role_c,pls.pl_id,pls.opp_primary_partner_role__c,pls.opp_leadsource,pls.opp_lead_partner__c,pls.opp_dell_technologies_business__c,pls.opp_lead_partner_type__c,pls.acc_dell_emc_segment__c,pls.opp_theatre__c,pls.opp_segment__c,pls.product_quant_practice_group__c as lob,pls.opp_stagename,pls.opp_heat_map__c,pls.opp_closedate,pl_booked_amount__c,pl_annual_contact_value_year_1__c,pls.field_source,pls.opp_close_fiscal_quarter,pls.opp_type,
pls.opp_application_flag,
current_fiscal_period,
oh.current_week_num as current_fiscal_week, 
 'Baseline' 
 as snapshot_type,oh.acc_partner_type__c as lead_partner_type,
 pls.opp_name,
	pls.user_name as opp_owner_name,
	pls.m3_role_name as division,
	pls.opp_opportunity_age__c,
	pls.closedate_change_count,
case when pls.opp_leadsource='Dell Technologies' then oh.Dell_Technologies_Role__c
else pls.opp_primary_partner_role__c end as [role_mapped],
 'Append'  as [data_type]
from (SELECT * FROM Product_Line_Snapshot where
isharddeleted=0  and field_source='SFDC' UNION SELECT * FROM opps_wo_pl) pls
left join Opportunity_Header oh
on pls.opp_id=oh.opp_id
where  pls.snapshot_type in ((select 'Week '+
case when len((select cast((select top 1 current_week_num-4 from Opportunity_Header) as varchar(2))))=1 then '0'+(select cast((select top 1 current_week_num-4 from Opportunity_Header) as varchar(2))) else (select cast((select top 1 current_week_num-4 from Opportunity_Header) as varchar(2))) end))
 and ISNULL(pls.product_quant_practice_group__c, 'a' ) <>'Managed Services' 
and ISNULL(pls.opp_type,'a') <>'CSP-Sell Out'  and pls.opp_leadsource='Dell Technologies' and pls.opp_lead_partner__c is not null

