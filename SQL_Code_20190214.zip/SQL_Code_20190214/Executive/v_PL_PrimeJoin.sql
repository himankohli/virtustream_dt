

ALTER VIEW [dbo].[v_PL_PrimeJoin1] 
(
pl_id, 
pl_name,
pl_product__c,
pl_service_line__c, 
pl_practice_line__c,
pl_booked_amount__c,
pl_annual_contact_value_year_1__c,
pl_committed_contract_value__c,
opp_id,
opp_closedate,
opp_ownerid,
opp_createddate,
opp_accountid,
opp_name,
opp_stagename,
opp_probability,
opp_type,
opp_leadsource,
leadsource_flag,
opp_isclosed,
opp_iswon,
opp_gate__c,
opp_heat_map__c,
opp_primary_data_center__c,
opp_sales_channel__c,
opp_secondary_data_center__c,
opp_opportunity_number__c,
opp_sub_segment__c,
opp_emc_opportunity_number__c,
opp_lead_partner_type__c,
opp_lead_partner__c,
opp_opportunity_conversion__c,
opp_related_opportunity__c,
opp_related_product_amount__c,
opp_so_number__c,
opp_dell_technologies_business__c,
opp_opportunity_age__c,
opp_pardot_campaign__c,
opp_primary_partner_role__c,
acc_name,
acc_segment__c,
acc_dell_emc_segment__c,
product_name, 
product_family,
revschd_forecast_amount__c,
revschd_ccv_final,
revschd_acv_final,
user_id,
user_name,
user_division,
user_department,
user_email,
user_userroleid,
user_managerid,
user_forecastenabled,
ur_owner_role_name,
m1_role_name,
m2_role_name,
m3_role_name,
m4_role_name,
m5_role_name,
role_level,
hierarchy_global,
hierarchy_theatre,
hierarchy_segment,
hierarchy_division,
hierarchy_area,
user_employeenumber,
opp_country__c,
opp_theatre__c,
product_quant_practice_group__c,
opp_segment__c,
opp_close_fiscal_quarter,
id_rev_schd,
ccv_por_value , 
acv_por_value,
field_source,
por_type, 
quota_value,
role_quota,
territory_quota,
stlw_stagename,
stlw_heat_map,
stlw_closedate,
stlw_fiscal_quarter,
stlw_ccv_final,
stlw_acv_final,
stlw_forecast_amount__c,
stlq_stagename,
stlq_heat_map,
stlq_closedate,
stlq_fiscal_quarter,
stlq_ccv_final,
stlq_acv_final,
stlq_forecast_amount__c,
stly_stagename,
stly_heat_map,
stly_closedate,
stly_fiscal_quarter,
stly_ccv_final,
stly_acv_final,
stly_forecast_amount__c,
current_fiscal_period,
current_fiscal_week
)
AS
(
SELECT 
pls0.pl_id, 
pls0.pl_name,
pls0.pl_product__c, 
pls0.pl_service_line__c, 
pls0.pl_practice_line__c,
CASE	WHEN ISNULL(pls0.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls0.pl_booked_amount__c
		ELSE 0 END as pl_booked_amount__c,
CASE	WHEN ISNULL(pls0.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls0.pl_annual_contact_value_year_1__c
		ELSE 0 END as pl_annual_contact_value_year_1__c,
CASE	WHEN ISNULL(pls0.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls0.pl_Committed_Contract_Value__c
		ELSE 0 END as pl_Committed_Contract_Value__c,
pls0.opp_id,
pls0.opp_closedate,
pls0.opp_ownerid,
pls0.opp_CreatedDate,
pls0.opp_accountid,
pls0.opp_name,
pls0.opp_stagename,
pls0.opp_probability,
pls0.opp_type,
pls0.opp_leadsource,
CASE WHEN pls0.opp_leadsource='Dell Technologies'
THEN 1 ELSE 0 END as LeadSource_Flag,
pls0.opp_isclosed,
pls0.opp_iswon,
pls0.opp_gate__c,
pls0.opp_heat_map__c,
pls0.opp_primary_data_center__c,
pls0.opp_sales_channel__c,
pls0.opp_secondary_data_center__c,
pls0.opp_Opportunity_Number__c,
pls0.opp_sub_segment__c,
pls0.opp_emc_opportunity_number__c,
pls0.opp_lead_partner_type__c,
pls0.opp_lead_partner__c,
pls0.opp_Opportunity_Conversion__c,
pls0.opp_Related_Opportunity__c,
pls0.opp_Related_Product_Amount__c,
pls0.opp_so_number__c,
pls0.opp_Dell_Technologies_Business__c,
pls0.opp_Opportunity_Age__c,
pls0.opp_Pardot_Campaign__c,
pls0.opp_Primary_Partner_Role__c,
pls0.acc_Name,
pls0.acc_Segment__c,
pls0.acc_Dell_EMC_Segment__c,
pls0.product_name, 
pls0.product_family,
CASE	WHEN ISNULL(pls0.opp_type,'a') <> 'CSP-Sell Out'
		THEN rss0.revschd_Forecast_Amount__c
		ELSE 0 END as revschd_Forecast_Amount__c,
CASE	WHEN ISNULL(pls0.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls0.revschd_CCV_Final
		ELSE 0 END as revschd_CCV_Final,
CASE	WHEN ISNULL(pls0.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls0.revschd_ACV_Final
		ELSE 0 END revschd_ACV_Final,
pls0.user_id,
pls0.user_name,
pls0.user_division,
pls0.user_department,
pls0.user_email,
pls0.user_userroleid,
pls0.user_managerid,
pls0.user_forecastenabled,
pls0.ur_owner_role_name,
pls0.M1_Role_Name,
pls0.M2_Role_Name,
pls0.M3_Role_Name,
pls0.M4_Role_Name,
pls0.M5_Role_Name,
pls0.Role_Level,
pls0.hierarchy_global,
pls0.hierarchy_theatre,
pls0.acc_Segment__c as hierarchy_segment,
pls0.hierarchy_division,
pls0.hierarchy_area,
pls0.user_employeenumber,
pls0.opp_country__c,
pls0.opp_theatre__c,
pls0.product_quant_practice_group__c,
pls0.opp_segment__c,
pls0.opp_close_fiscal_quarter,
pls0.id_rev_schd,
pls0.ccv_por_value , 
pls0.acv_por_value, 
pls0.field_source,
pls0.por_type, 
pls0.quota_value,
pls0.role_quota,
pls0.territory_quota,
pls1.opp_stagename as stlw_stagename,
pls1.opp_heat_map__c  as stlw_heat_map,
pls1.opp_closedate as stlw_closedate,
pls1.opp_close_fiscal_quarter as stlw_fiscal_quarter,
CASE	WHEN ISNULL(pls1.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls1.pl_booked_amount__c
		ELSE 0 END as stlw_ccv_final,
CASE	WHEN ISNULL(pls1.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls1.revschd_acv_final
		ELSE 0 END as stlw_acv_final,
CASE	WHEN ISNULL(pls1.opp_type,'a') <> 'CSP-Sell Out'
		THEN rss1.revschd_forecast_amount__c
		ELSE 0 END  as stlw_forecast_amount__c,
pls2.opp_stagename as stlq_stagename,
pls2.opp_heat_map__c  as stlq_heat_map,
pls2.opp_closedate as stlq_closedate,
pls2.opp_close_fiscal_quarter as STLQ_fiscal_quarter,
CASE	WHEN ISNULL(pls2.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls2.pl_booked_amount__c
		ELSE 0 END  as STLQ_CCV_Final,
CASE	WHEN ISNULL(pls2.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls2.revschd_ACV_Final
		ELSE 0 END   as STLQ_ACV_Final,
CASE	WHEN ISNULL(pls2.opp_type,'a') <> 'CSP-Sell Out'
		THEN rss2.revschd_Forecast_Amount__c 
		ELSE 0 END  as STLQ_Forecast_Amount__c,
pls3.opp_StageName as STLY_StageName,
pls3.opp_Heat_Map__c  as STLY_Heat_Map,
pls3.opp_CloseDate as STLY_CloseDate,
pls3.opp_close_fiscal_quarter as STLY_fiscal_quarter,
CASE	WHEN ISNULL(pls3.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls3.pl_booked_amount__c
		ELSE 0 END   as STLY_CCV_Final,
CASE	WHEN ISNULL(pls3.opp_type,'a') <> 'CSP-Sell Out'
		THEN pls3.revschd_ACV_Final  
		ELSE 0 END   as STLY_ACV_Final,
NULL as STLY_Forecast_Amount__c,
(SELECT b.Fiscal_Period
FROM FiscalQuarters b 
WHERE b.date=CAST(GETDATE() AS DATE)) as Current_Fiscal_Period,
(SELECT b.WEEK
FROM FiscalQuarters b 
WHERE b.date=CAST(GETDATE() AS DATE)) as Current_Fiscal_Week

FROM

(SELECT * FROM Product_Line_Snapshot 
where  Snapshot_type='DAY 01' and pl_id IS NOT NULL AND
product_quant_practice_group__C <> 'Managed Services'
) pls0 
LEFT JOIN (SELECT pl_id, opp_StageName, opp_Heat_Map__c, opp_CloseDate, opp_close_fiscal_quarter, opp_type,
revschd_CCV_Final, revschd_ACV_Final, revschd_Forecast_Amount__c, pl_booked_amount__c
 FROM Product_Line_Snapshot 
where  Snapshot_type='DAY 07' and pl_id IS NOT NULL) pls1
ON  pls0.pl_id  =  pls1.pl_id   
LEFT JOIN (SELECT pl_id, opp_StageName, opp_Heat_Map__c, opp_CloseDate, opp_close_fiscal_quarter, opp_type,
revschd_CCV_Final, revschd_ACV_Final, revschd_Forecast_Amount__c, pl_booked_amount__c
 FROM Product_Line_Snapshot 
where  Snapshot_type='WEEK 13' and pl_id IS NOT NULL) pls2
ON  pls0.pl_id  =  pls2.pl_id  
LEFT JOIN (SELECT pl_id, opp_StageName, opp_Heat_Map__c, opp_CloseDate, opp_close_fiscal_quarter,opp_type,
revschd_CCV_Final, revschd_ACV_Final, revschd_Forecast_Amount__c, pl_booked_amount__c
 FROM Product_Line_Snapshot 
where  Snapshot_type='WEEK 52' and pl_id IS NOT NULL) pls3
ON  pls0.pl_id  =  pls3.pl_id          
LEFT JOIN (SELECT pl_id, SUM(revschd_Forecast_amount__c) as revschd_Forecast_amount__c FROM Revenue_Schedule_Snapshot a LEFT JOIN 
(SELECT DISTINCT fiscal_period, fiscal_qtr FROM FiscalQuarters)  b ON a.revschd_fiscal_period__c = b.Fiscal_Period
WHERE b.fiscal_qtr = (SELECT fiscal_qtr FROM FiscalQuarters WHERE [date] = CAST(GETDATE() as date)) AND a.snapshot_type = 'DAY 01'
AND (product_quant_practice_group__c IS NOT NULL AND product_quant_practice_group__c <> 'Managed Services')
GROUP BY pl_id) rss0
ON  pls0.pl_id  =  rss0.pl_id
LEFT JOIN (SELECT pl_id, SUM(revschd_Forecast_amount__c) as revschd_Forecast_amount__c FROM Revenue_Schedule_Snapshot a LEFT JOIN 
(SELECT DISTINCT fiscal_period, fiscal_qtr FROM FiscalQuarters)  b ON a.revschd_fiscal_period__c = b.Fiscal_Period
WHERE b.fiscal_qtr = (SELECT fiscal_qtr FROM FiscalQuarters WHERE [date] = CAST(GETDATE() as date)) AND a.snapshot_type = 'DAY 07'
AND (product_quant_practice_group__c IS NOT NULL AND product_quant_practice_group__c <> 'Managed Services')
GROUP BY pl_id) rss1
ON  pls0.pl_id  =  rss1.pl_id
LEFT JOIN (SELECT pl_id, SUM(revschd_Forecast_amount__c) as revschd_Forecast_amount__c FROM Revenue_Schedule_Snapshot a LEFT JOIN 
(SELECT DISTINCT fiscal_period, fiscal_qtr FROM FiscalQuarters)  b ON a.revschd_fiscal_period__c = b.Fiscal_Period
WHERE b.fiscal_qtr = (SELECT fiscal_qtr FROM FiscalQuarters WHERE [date] = CAST(GETDATE() as date)) AND a.snapshot_type = 'WEEK 13'
AND (product_quant_practice_group__c IS NOT NULL AND product_quant_practice_group__c <> 'Managed Services')
GROUP BY pl_id) rss2
ON  pls0.pl_id  =  rss2.pl_id

UNION ALL
-------------------Non SFDC-----------------------------
SELECT  
NULL as pl_id,
NULL as pl_name,
NULL as pl_product__c,
NULL as pl_service_line__c,
NULL as pl_practice_line__c,
NULL as pl_booked_amount__c,
NULL as pl_annual_contact_value_year_1__c,
NULL as pl_Committed_Contract_Value__c,
NULL as  opp_id,
NULL as opp_closedate,
NULL as opp_ownerid,
NULL as opp_CreatedDate,
NULL as opp_accountid,
NULL as opp_name,
NULL as opp_stagename,
NULL as opp_probability,
NULL as opp_type,
NULL as opp_leadsource,
NULL as LeadSource_Flag,
NULL as opp_isclosed,
NULL as opp_iswon,
NULL as opp_gate__c,
NULL as opp_heat_map__c,
NULL as opp_primary_data_center__c,
NULL as opp_sales_channel__c,
NULL as opp_secondary_data_center__c,
NULL as opp_Opportunity_Number__c,
NULL  as opp_sub_segment__c,
NULL as opp_emc_opportunity_number__c,
NULL as opp_lead_partner_type__c,
NULL as opp_lead_partner__c,
NULL as opp_opportunity_conversion__c,
NULL as opp_related_opportunity__c,
NULL as opp_related_product_amount__c,
NULL as opp_so_number__c,
NULL as opp_dell_technologies_business__c,
NULL as opp_opportunity_age__c,
NULL as opp_pardot_campaign__c, 
NULL as opp_Primary_Partner_Role__c,
NULL as acc_Name,
NULL as acc_Segment__c,
--CASE WHEN classification='Commercial' OR
--classification='Enterprise' OR
--classification='Federal' THEN 
classification 
--END 
as  acc_Dell_EMC_Segment__c,
NULL as product_name,
NULL as product_family,
NULL as revschd_Forecast_Amount__c,
NULL as revschd_CCV_Final,
NULL as revschd_ACV_Final,
NULL as user_id,
NULL as user_name,
NULL as user_division,
NULL as user_department,
NULL as user_email,
NULL as user_userroleid,
NULL as user_managerid,
NULL as user_forecastenabled, 
NULL as ur_owner_role_name,
NULL as M1_Role_Name,
NULL as M2_Role_Name,
NULL as M3_Role_Name,
NULL as M4_Role_Name,
NULL as M5_Role_Name,
NULL as Role_Level,
'Global' as hierarchy_global,
theatre as hierarchy_theatre,
NULL as hierarchy_segment,
NULL as hierarchy_division,
NULL as hierarchy_area,
NULL as user_employeenumber,
NULL as opp_country__c,
theatre as opp_theatre__c,
product as product_quant_practice_group__c,
segment  as opp_segment__c,
fiscal_quarter as opp_close_fiscal_quarter,
'por' as id_rev_schd,
ccv_value as ccv_por_value , 
acv_value as acv_por_value,  
data_type as field_source,
por_type , 
NULL as quota_value,
NULL as role_quota,
NULL as territory_quota ,
NULL as stlw_stagename,
NULL as stlw_heat_map,
NULL as STLW_CloseDate,
NULL as STLW_fiscal_quarter,
NULL as STLW_CCV_Final,
NULL as STLW_ACV_Final,
NULL as STLW_Forecast_Amount__c,
NULL as STLQ_StageName,
NULL as STLQ_Heat_Map,
NULL as STLQ_CloseDate,
NULL as STLQ_fiscal_quarter,
NULL as STLQ_CCV_Final,
NULL as STLQ_ACV_Final,
NULL as STLQ_Forecast_Amount__c,
NULL as STLY_StageName,
NULL as STLY_Heat_Map,
NULL as STLY_CloseDate,
NULL as STLY_fiscal_quarter,
NULL as STLY_CCV_Final,
NULL as STLY_ACV_Final,
NULL as STLY_Forecast_Amount__c,
(SELECT b.Fiscal_Period
FROM FiscalQuarters b 
WHERE b.date=CAST(GETDATE() AS DATE)) as Current_Fiscal_Period,
(SELECT b.WEEK
FROM FiscalQuarters b 
WHERE b.date=CAST(GETDATE() AS DATE)) as Current_Fiscal_Week
FROM  (
SELECT theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  SUM(ccv_value) ccv_value,  SUM(acv_value) acv_value,
data_domain FROM POR_Data where  product <> 'Managed Services'
GROUP BY 
theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  
data_domain) a



UNION ALL


SELECT  
NULL as pl_id,
NULL as pl_name,
NULL as pl_product__c,
NULL as pl_service_line__c,
NULL as pl_practice_line__c,
CCV as pl_booked_amount__c,
ACV as pl_annual_contact_value_year_1__c,
CCV as pl_Committed_Contract_Value__c,
NULL as  opp_id,
NULL as opp_closedate,
NULL as opp_ownerid,
NULL as opp_CreatedDate,
NULL as opp_accountid,
NULL as opp_name,
'100% Booked (Closed/Won)' as opp_stagename,
NULL as opp_probability,
NULL as opp_type,
NULL as opp_leadsource,
NULL as LeadSource_Flag,
NULL as opp_isclosed,
NULL as opp_iswon,
NULL as opp_gate__c,
NULL as opp_heat_map__c,
NULL as opp_primary_data_center__c,
NULL as opp_sales_channel__c,
NULL as opp_secondary_data_center__c,
NULL as opp_Opportunity_Number__c,
NULL  as opp_sub_segment__c,
NULL as opp_emc_opportunity_number__c,
NULL as opp_lead_partner_type__c,
NULL as opp_lead_partner__c,
NULL as opp_opportunity_conversion__c,
NULL as opp_related_opportunity__c,
NULL as opp_related_product_amount__c,
NULL as opp_so_number__c,
NULL as opp_dell_technologies_business__c,
NULL as opp_opportunity_age__c,
NULL as opp_pardot_campaign__c, 
NULL as opp_Primary_Partner_Role__c,
NULL as acc_Name,
NULL as acc_Segment__c,
--CASE WHEN classification='Commercial' OR
--classification='Enterprise' OR
--classification='Federal' THEN 
classification 
--END 
as acc_Dell_EMC_Segment__c,
NULL as product_name,
NULL as product_family,
NULL as revschd_Forecast_Amount__c,
CCV as revschd_CCV_Final,
ACV as revschd_ACV_Final,
NULL as user_id,
NULL as user_name,
NULL as user_division,
NULL as user_department,
NULL as user_email,
NULL as user_userroleid,
NULL as user_managerid,
NULL as user_forecastenabled, 
NULL as ur_owner_role_name,
NULL as M1_Role_Name,
NULL as M2_Role_Name,
NULL as M3_Role_Name,
NULL as M4_Role_Name,
NULL as M5_Role_Name,
NULL as Role_Level,
'Global' as hierarchy_global,
theatre as hierarchy_theatre,
NULL as hierarchy_segment,
NULL as hierarchy_division,
NULL as hierarchy_area,
NULL as user_employeenumber,
NULL as opp_country__c,
theatre as opp_theatre__c,
product as product_quant_practice_group__c,
segment as opp_segment__c,
fiscal_quarter as opp_close_fiscal_quarter,
id_rev_schd,
NULL as ccv_por_value, 
NULL as acv_por_value,  
field_source,
por_type , 
NULL as quota_value,
NULL as role_quota,
NULL as territory_quota ,
'100% Booked (Closed/Won)' as stlw_stagename,
NULL as stlw_heat_map,
NULL as stlw_closedate,
stlw_fiscal_quarter as stlw_fiscal_quarter,
stlw_ccv as stlw_ccv_final,
stlw_acv as stlw_acv_final,
null as stlw_forecast_amount__c,
'100% Booked (Closed/Won)' as stlq_stagename,
null as stlq_heat_map,
null as stlq_closedate,
stlq_fiscal_quarter as stlq_fiscal_quarter,
stlq_ccv as stlq_ccv_final,
stlq_acv as stlq_acv_final,
null as stlq_forecast_amount__c,
'100% Booked (Closed/Won)' as stly_stagename,
null as stly_heat_map,
null as stly_closedate,
stly_fiscal_quarter as stly_fiscal_quarter,
stly_ccv as stly_ccv_final,
stly_acv as stly_acv_final,
NULL as stly_forecast_amount__c,
(SELECT b.Fiscal_Period
FROM FiscalQuarters b 
WHERE b.date=CAST(GETDATE() AS DATE)) as current_fiscal_period,
(SELECT b.WEEK
FROM FiscalQuarters b 
WHERE b.date=CAST(GETDATE() AS DATE)) as current_fiscal_week
FROM 

(

(SELECT a.theatre, a.product, a.segment, a.classification
,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT
CAST(GETDATE() AS DATE))) as fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-1,GETDATE()) AS DATE))) as STLW_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-13,GETDATE()) AS DATE))) as STLQ_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-52,GETDATE()) AS DATE))) as STLY_fiscal_quarter, 'por' as id_rev_schd, 
'RolloverBookings' as field_source, 'Rollover Bookings' as por_type,
b.ccv_value as CCV,
c.ccv_value as STLW_CCV,
d.ccv_value as STLQ_CCV,
e.ccv_value as STLY_CCV,
b.acv_value as ACV,
c.acv_value as STLW_ACV,
d.acv_value as STLQ_ACV,
e.acv_value as STLY_ACV
FROM
(SELECT DISTINCT theatre, product, segment, classification FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings'
AND fiscal_quarter IN (SELECT fiscal_qtr FROM FiscalQuarters where date IN 
((SELECT CAST(GETDATE() AS DATE)), 
(SELECT CAST(DATEADD(ww,-1,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-13,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-52,GETDATE()) AS DATE))
)) GROUP BY theatre, product, segment, classification) a 
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT
CAST(GETDATE() AS DATE)))) b
ON a.theatre=b.theatre AND a.product=b.product AND
a.segment=b.segment AND a.classification=b.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-1,GETDATE()) AS DATE)))) c
ON a.theatre=c.theatre AND a.product=c.product AND
a.segment=c.segment  AND a.classification=c.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT 
CAST(DATEADD(ww,-13,GETDATE()) AS DATE)))) d
ON a.theatre=d.theatre AND a.product=d.product AND
a.segment=d.segment  AND a.classification=d.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT 
CAST(DATEADD(ww,-52,GETDATE()) AS DATE)))) e
ON a.theatre=e.theatre AND a.product=e.product AND
a.segment=e.segment  AND a.classification=e.classification
WHERE a.product<>'Managed Services')

UNION ALL
------------------------------------------------------------------------

(SELECT a.theatre, a.product, a.segment, a.classification,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT
CAST(DATEADD(ww,-13,GETDATE()) AS DATE))) as fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-14,GETDATE()) AS DATE))) as STLW_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-26,GETDATE()) AS DATE))) as STLQ_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-65,GETDATE()) AS DATE))) as STLY_fiscal_quarter, 'por' as id_rev_schd, 
'RolloverBookings' as field_source, 'Rollover Bookings' as por_type,
b.ccv_value as CCV,
c.ccv_value as STLW_CCV,
d.ccv_value as STLQ_CCV,
e.ccv_value as STLY_CCV,
b.acv_value as ACV,
c.acv_value as STLW_ACV,
d.acv_value as STLQ_ACV,
e.acv_value as STLY_ACV
FROM
(SELECT DISTINCT theatre, product, segment , classification FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings'
AND fiscal_quarter IN (SELECT fiscal_qtr FROM FiscalQuarters where date IN 
((SELECT CAST(DATEADD(ww,-13,GETDATE()) AS DATE)), 
(SELECT CAST(DATEADD(ww,-14,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-26,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-65,GETDATE()) AS DATE))
)) GROUP BY theatre, product, segment, fiscal_quarter, classification) a 
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-13,GETDATE()) AS DATE)))) b
ON a.theatre=b.theatre AND a.product=b.product AND
a.segment=b.segment  AND a.classification=b.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-14,GETDATE()) AS DATE)))) c
ON a.theatre=c.theatre AND a.product=c.product AND
a.segment=c.segment AND a.classification=c.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-26,GETDATE()) AS DATE)))) d
ON a.theatre=d.theatre AND a.product=d.product AND
a.segment=d.segment AND a.classification=d.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-65,GETDATE()) AS DATE)))) e
ON a.theatre=e.theatre AND a.product=e.product AND
a.segment=e.segment AND a.classification=e.classification
WHERE a.product<>'Managed Services')
UNION ALL

-------------------------------------------------------------------------


(SELECT a.theatre, a.product, a.segment, a.classification,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT
CAST(DATEADD(ww,-26,GETDATE()) AS DATE))) as fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-27,GETDATE()) AS DATE))) as STLW_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-39,GETDATE()) AS DATE))) as STLQ_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-78,GETDATE()) AS DATE))) as STLY_fiscal_quarter, 'por' as id_rev_schd, 
'RolloverBookings' as field_source, 'Rollover Bookings' as por_type,
b.ccv_value as CCV,
c.ccv_value as STLW_CCV,
d.ccv_value as STLQ_CCV,
e.ccv_value as STLY_CCV,
b.acv_value as ACV,
c.acv_value as STLW_ACV,
d.acv_value as STLQ_ACV,
e.acv_value as STLY_ACV
FROM
(SELECT DISTINCT theatre, product, segment, classification FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings'
AND fiscal_quarter IN (SELECT fiscal_qtr FROM FiscalQuarters where date IN 
((SELECT CAST(DATEADD(ww,-26,GETDATE()) AS DATE)), 
(SELECT CAST(DATEADD(ww,-27,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-39,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-78,GETDATE()) AS DATE))
)) GROUP BY theatre, product, segment, fiscal_quarter, classification) a 
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-26,GETDATE()) AS DATE)))) b
ON a.theatre=b.theatre AND a.product=b.product AND
a.segment=b.segment AND a.classification=b.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-27,GETDATE()) AS DATE)))) c
ON a.theatre=c.theatre AND a.product=c.product AND
a.segment=c.segment AND a.classification=c.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-39,GETDATE()) AS DATE)))) d
ON a.theatre=d.theatre AND a.product=d.product AND
a.segment=d.segment AND a.classification=d.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-78,GETDATE()) AS DATE)))) e
ON a.theatre=e.theatre AND a.product=e.product AND
a.segment=e.segment AND a.classification=e.classification
WHERE a.product<>'Managed Services')
UNION ALL
-----------------------------------------------------------

(SELECT a.theatre, a.product, a.segment, a.classification,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT
CAST(DATEADD(ww,-39,GETDATE()) AS DATE))) as fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-40,GETDATE()) AS DATE))) as STLW_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-52,GETDATE()) AS DATE))) as STLQ_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-91,GETDATE()) AS DATE))) as STLY_fiscal_quarter, 'por' as id_rev_schd, 
'RolloverBookings' as field_source, 'Rollover Bookings' as por_type,
b.ccv_value as CCV,
c.ccv_value as STLW_CCV,
d.ccv_value as STLQ_CCV,
e.ccv_value as STLY_CCV,
b.acv_value as ACV,
c.acv_value as STLW_ACV,
d.acv_value as STLQ_ACV,
e.acv_value as STLY_ACV
FROM
(SELECT DISTINCT theatre, product, segment, classification FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings'
AND fiscal_quarter IN (SELECT fiscal_qtr FROM FiscalQuarters where date IN 
((SELECT CAST(DATEADD(ww,-39,GETDATE()) AS DATE)), 
(SELECT CAST(DATEADD(ww,-40,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-52,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-91,GETDATE()) AS DATE))
)) GROUP BY theatre, product, segment, fiscal_quarter, classification) a 
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-39,GETDATE()) AS DATE)))) b
ON a.theatre=b.theatre AND a.product=b.product AND
a.segment=b.segment AND a.classification=b.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-40,GETDATE()) AS DATE)))) c
ON a.theatre=c.theatre AND a.product=c.product AND
a.segment=c.segment AND a.classification=c.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-52,GETDATE()) AS DATE)))) d
ON a.theatre=d.theatre AND a.product=d.product AND
a.segment=d.segment AND a.classification=d.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-91,GETDATE()) AS DATE)))) e
ON a.theatre=e.theatre AND a.product=e.product AND
a.segment=e.segment AND a.classification=e.classification
WHERE a.product<>'Managed Services')

UNION ALL
-----------------------------------------------------------

(SELECT a.theatre, a.product, a.segment, a.classification,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT
CAST(DATEADD(ww,-52,GETDATE()) AS DATE))) as fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-53,GETDATE()) AS DATE))) as STLW_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-65,GETDATE()) AS DATE))) as STLQ_fiscal_quarter,
(SELECT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT 
CAST(DATEADD(ww,-104,GETDATE()) AS DATE))) as STLY_fiscal_quarter, 'por' as id_rev_schd, 
'RolloverBookings' as field_source, 'Rollover Bookings' as por_type,
b.ccv_value as CCV,
c.ccv_value as STLW_CCV,
d.ccv_value as STLQ_CCV,
e.ccv_value as STLY_CCV,
b.acv_value as ACV,
c.acv_value as STLW_ACV,
d.acv_value as STLQ_ACV,
e.acv_value as STLY_ACV
FROM
(SELECT DISTINCT theatre, product, segment , classification FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings'
AND fiscal_quarter IN (SELECT fiscal_qtr FROM FiscalQuarters where date IN 
((SELECT CAST(DATEADD(ww,-52,GETDATE()) AS DATE)), 
(SELECT CAST(DATEADD(ww,-53,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-65,GETDATE()) AS DATE)),
(SELECT CAST(DATEADD(ww,-104,GETDATE()) AS DATE))
)) GROUP BY theatre, product, segment, fiscal_quarter, classification) a 
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-52,GETDATE()) AS DATE)))) b
ON a.theatre=b.theatre AND a.product=b.product AND
a.segment=b.segment AND a.classification=b.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-53,GETDATE()) AS DATE)))) c
ON a.theatre=c.theatre AND a.product=c.product AND
a.segment=c.segment AND a.classification=c.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-65,GETDATE()) AS DATE)))) d
ON a.theatre=d.theatre AND a.product=d.product AND
a.segment=d.segment AND a.classification=d.classification
LEFT JOIN 
(SELECT * FROM  Consolidated_POR_Data
where data_type='Actuals' AND por_type='Rollover Bookings' AND 
fiscal_quarter=(SELECT fiscal_qtr FROM FiscalQuarters where date=(SELECT CAST(DATEADD(ww,-104,GETDATE()) AS DATE)))) e
ON a.theatre=e.theatre AND a.product=e.product AND
a.segment=e.segment AND a.classification=e.classification
WHERE a.product<>'Managed Services')
)x
)