/**

Deletes all the temporary objects which are created in the ingestion process.

**/
ALTER PROCEDURE [dbo].[delete_temporary_objects]
AS
BEGIN
	
	DROP TABLE IF EXISTS  [Campaign_check]
	DROP TABLE IF EXISTS  [Account_check]
	DROP TABLE IF EXISTS  [CampaignMember_check]
	DROP TABLE IF EXISTS  [Contact_check]
	DROP TABLE IF EXISTS  [Lead_check]
	DROP TABLE IF EXISTS  [Opportunity_check]
	DROP TABLE IF EXISTS  [OpportunityTeamMember_check]
	DROP TABLE IF EXISTS  [OpportunityFieldHistory_check]
	DROP TABLE IF EXISTS  [Product2_check]
	DROP TABLE IF EXISTS  [ProductLine_check]
	DROP TABLE IF EXISTS  [RevenueSchedule_check]
	DROP TABLE IF EXISTS  Fiscal_Period__c_check
	DROP TABLE IF EXISTS  Fiscal_Period_check
	DROP TABLE IF EXISTS  [User_check]
	DROP TABLE IF EXISTS  [UserRole_check]
	DROP TABLE IF EXISTS  [RevenueScheduleHistory_check]
	DROP TABLE IF EXISTS  [CurrencyType_check]
	DROP TABLE IF EXISTS  [Sales_Credit_Detail_check]
	DROP TABLE IF EXISTS  [Task_check]
	DROP TABLE IF EXISTS  [Event_check]
	DROP TABLE IF EXISTS  [OpportunityContactRole_check]

	DROP TABLE IF EXISTS  Row_Count

	DROP TABLE IF EXISTS  [Campaign_temp]
	DROP TABLE IF EXISTS  [Account_temp]
	DROP TABLE IF EXISTS  [CampaignMember_temp]
	DROP TABLE IF EXISTS  [Contact_temp]
	DROP TABLE IF EXISTS  [Lead_temp]
	DROP TABLE IF EXISTS  [Opportunity_temp]
	DROP TABLE IF EXISTS  [OpportunityTeamMember_temp]
	DROP TABLE IF EXISTS  [OpportunityFieldHistory_temp]
	DROP TABLE IF EXISTS  [Product2_temp]

	DROP TABLE IF EXISTS  [ProductLine_temp]

	DROP TABLE IF EXISTS  [RevenueSchedule_temp]

	DROP TABLE IF EXISTS  [Fiscal_Period_temp]

	DROP TABLE IF EXISTS  [Territory2_temp]

	DROP TABLE IF EXISTS  [User_temp]

	DROP TABLE IF EXISTS  [UserRole_temp]

	DROP TABLE IF EXISTS  [RevenueScheduleHistory_temp]

	DROP TABLE IF EXISTS  [CurrencyType_temp]

	DROP TABLE IF EXISTS  [Sales_Credit_Detail_temp]

	DROP TABLE IF EXISTS  [Task_temp]

	DROP TABLE IF EXISTS  [Event_temp]

	DROP TABLE IF EXISTS  [OpportunityContactRole_temp]

	DROP TABLE IF EXISTS  [u_googleanalytics_check]

END

