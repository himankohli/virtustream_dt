

SELECT DISTINCT x.*,  
CASE WHEN y.opp_id IS NULL THEN 'FALSE' ELSE 'TRUE' END as Opps_with_valid_WebCPTLink,
 CASE WHEN a.opp_id IS NULL THEN 'FALSE' ELSE 'TRUE' END as Opps_Joins_DealDesk
 
FROM (SELECT DISTINCT id as opp_id, name as opp_name, Web_CPT_Link__c 
as SFDC_WebCPTLink FROM Opportunity 
WHERE IsHardDeleted=0 AND fiscal_Year_quarter__C='FY 2019 Q4' 
AND (stagename LIKE '99%' OR stagename LIKE '100%')) x 
LEFT JOIN


(SELECT DISTINCT id as opp_id FROM
(SELECT DISTINCT id,stagename, [value] as [Web_CPT_Link]  
FROM (SELECT DISTINCT id, stagename, Web_CPT_Link__c FROM Opportunity 
WHERE IsHardDeleted=0

AND fiscal_Year_quarter__C='FY 2019 Q4' AND (stagename LIKE '99%' OR stagename LIKE '100%')
) a CROSS APPLY string_split(Web_CPT_Link__c,' ')
WHERE [value]  LIKE 'www%' 
OR  [value]  LIKE '%http%'
OR  [value]  LIKE '%com%') b where [Web_CPT_Link]  LIKE '%https://cpt%') y
ON x.opp_id=y.opp_id

LEFT JOIN (SELECT DISTINCT x.opp_id--, x.probablity, x.Web_CPT_Link 
FROM
(SELECT DISTINCT id as opp_id, 
SUBSTRING(stagename,1,CHARINDEX('%',stagename)) as probablity,
SUBSTRING(SUBSTRING(SUBSTRING(SUBSTRING(SUBSTRING([Web_CPT_Link],
CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100), CHARINDEX('/',
SUBSTRING(SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100))+1,100),
CHARINDEX('/',SUBSTRING(SUBSTRING(SUBSTRING([Web_CPT_Link],
CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100), CHARINDEX('/', SUBSTRING(SUBSTRING([Web_CPT_Link],
CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100))+1,100))+1,100),1,24) as [Web_CPT_Link]
FROM
(SELECT DISTINCT id,stagename, [value] as [Web_CPT_Link]  
FROM 
(SELECT DISTINCT id, stagename, Web_CPT_Link__c FROM Opportunity 
WHERE IsHardDeleted=0

------------------------------Option filter-------------------------------------------------
AND fiscal_Year_quarter__C='FY 2019 Q4' AND (stagename LIKE '99%' OR stagename LIKE '100%')
----------------------------------------------------------------------------------
) a CROSS APPLY string_split(Web_CPT_Link__c,' ')
WHERE [value]  LIKE 'www%' 
OR  [value]  LIKE '%http%'
OR  [value]  LIKE '%com%') b where [Web_CPT_Link]  LIKE '%https://cpt%') x


 JOIN 
(SELECT DISTINCT da_id,id as opp_id, 
SUBSTRING(SUBSTRING(SUBSTRING(SUBSTRING(SUBSTRING([Web_CPT_Link],
CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100), CHARINDEX('/',
SUBSTRING(SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100))+1,100),
CHARINDEX('/',SUBSTRING(SUBSTRING(SUBSTRING([Web_CPT_Link],
CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100), CHARINDEX('/', SUBSTRING(SUBSTRING([Web_CPT_Link],
CHARINDEX('/',[Web_CPT_Link])+1,100),
CHARINDEX('/',SUBSTRING([Web_CPT_Link],CHARINDEX('/',[Web_CPT_Link])+1,100))
+1,100))+1,100))+1,100),1,24) as [Web_CPT_Link]
FROM
(SELECT DISTINCT id as da_id , ds_OpportunityID as id,  
ds_WebCPTLink as [Web_CPT_Link] FROM [VSPricingPOC].dbo.da_stats
where ds_WebCPTLink NOT IN ('0','') AND ds_WebCPTLink NOT LIKE 'C%') b) y
ON x.[Web_CPT_Link]=y.[Web_CPT_Link]) a
ON x.opp_id=a.opp_id



ORDER BY 4,5 