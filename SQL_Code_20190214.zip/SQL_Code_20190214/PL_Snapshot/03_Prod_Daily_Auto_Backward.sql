/**

Triggers the updation of Daily Snapshots of Product_Line_Snapshot, it checks if any 
historical snapshot is missing then it triggers SP that recreate the missing ones.

**/

ALTER PROCEDURE Prod_Daily_Auto_Backward(@snap_date DATE, @run_time TIME)
AS
BEGIN
	
	DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))
	
	
	DROP TABLE IF EXISTS Opp_Copy
	SELECT * INTO Opp_copy FROM Opportunity  WHERE isdeleted=0 AND isharddeleted=0


	DROP TABLE IF  EXISTS OFH_Copy
	SELECT * INTO OFH_Copy FROM OpportunityFieldHistory 
	where field IN ('Name', 
	'Type', 'Manager__c','Heat_Map__c', 'StageName','CloseDate')

	ALTER TABLE OFH_Copy ADD  opp_created_date DATE

	UPDATE OFH_Copy SET opp_created_date = CAST(b.createddate AS DATE) FROM OFH_Copy a JOIN Opp_copy b 
	ON a.opportunityid = b.id

	
	UPDATE Opp_copy
	SET type='ABCD'
	WHERE type IS NULL

	UPDATE Opp_copy
	SET Manager__c='ABCD'
	WHERE Manager__c IS NULL

	UPDATE OFH_Copy
	SET OldValue='ABCD'
	WHERE OldValue IS NULL
	AND Field IN ('Type', 'Manager__c')

	UPDATE OFH_Copy
	SET NewValue='ABCD'
	WHERE NewValue IS NULL
	AND Field IN ('Type', 'Manager__c')


	DROP TABLE IF  EXISTS rev_copy
	SELECT * INTO rev_copy FROM RevenueSchedule WHERE isdeleted=0 AND isharddeleted=0

	DROP TABLE IF  EXISTS rfh_copy
	SELECT  * INTO rfh_copy FROM RevenueScheduleHistory
	WHERE  field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	ALTER TABLE RFH_Copy 
	ADD  Rev_created_date DATE

	ALTER TABLE RFH_Copy
	ALTER COLUMN NewValue FLOAT

	ALTER TABLE RFH_Copy
	ALTER COLUMN OldValue FLOAT

	UPDATE RFH_Copy SET Rev_created_date = CAST(b.createddate AS DATE) FROM RFH_Copy a JOIN RevenueSchedule b 
	ON a.ParentId = b.id

	UPDATE Rev_copy
	SET Committed_Amount__c=999950000
	WHERE Committed_Amount__c IS NULL

	UPDATE Rev_copy
	SET Projection__c=999950000
	WHERE Projection__c IS NULL

	UPDATE Rev_copy
	SET Actual__c=999950000
	WHERE Actual__c IS NULL

	UPDATE RFH_Copy
	SET OldValue=999950000
	WHERE OldValue IS NULL
	AND Field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	UPDATE RFH_Copy
	SET NewValue=999950000
	WHERE NewValue IS NULL
	AND Field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	/* Number of Loops*/
	DECLARE @cnti INT=7
	
	/* Name of week in the Reverse Order*/
	DECLARE @day INT=1

	DECLARE @counter1 INT
	

	WHILE @cnti>0

	BEGIN

	SET @counter1=0
	

	IF(@run_time>='00:00:00' AND @run_time<'08:00:00')
	BEGIN
	SELECT @counter1=COUNT(DISTINCT Snapshot_Date) FROM Product_Line_Snapshot
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date)  and Snapshot_type LIKE 'DAY%'
	and Snapshot_Date<>DATEADD(dd, -1, @today)


	IF(@counter1=0)
	BEGIN
	DELETE FROM Product_Line_Snapshot 
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date) AND Snapshot_type LIKE 'DAY%'

	
	EXEC dbo.PL_Daily_Snapshot_Creation @snap_date, @run_time
	END


	UPDATE  Product_Line_Snapshot
	SET
	Snapshot_type =(SELECT CONCAT('DAY 0',@day))
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date) AND  (Snapshot_type  LIKE 'DAY%'
	 OR Snapshot_type IS NULL)

	END
	ELSE
	BEGIN

	SELECT @counter1=COUNT(DISTINCT Snapshot_Date) FROM Product_Line_Snapshot
	WHERE Snapshot_Date=@snap_date and Snapshot_type LIKE 'DAY%'
	and Snapshot_Date<>@today



	IF(@counter1=0)
	BEGIN
	DELETE FROM Product_Line_Snapshot 
	WHERE Snapshot_Date=@snap_date AND Snapshot_type LIKE 'DAY%'

	
	
	EXEC dbo.PL_Daily_Snapshot_Creation @snap_date, @run_time
	END
	UPDATE  Product_Line_Snapshot
	SET
	Snapshot_type =(SELECT CONCAT('DAY 0',@day))
	WHERE Snapshot_Date=@snap_date AND  (Snapshot_type  LIKE 'DAY%'
	 OR Snapshot_type IS NULL)

	END
	

	
	SET @snap_date= DATEADD(DD,-1,@snap_date)
	SET @cnti=@cnti-1
	SET @day=@day+1
	END
	

	DROP TABLE IF EXISTS OFH_Copy
	DROP TABLE IF EXISTS RFH_Copy
	DROP TABLE IF EXISTS Opp_copy
	DROP TABLE IF EXISTS Rev_copy
	END
