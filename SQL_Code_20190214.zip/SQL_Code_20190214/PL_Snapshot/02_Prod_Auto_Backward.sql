/**

Triggers the updation of Weekly snapshots of Product_Line_Snapshot, it checks if 
any historical snapshot is missing then it triggers a SP that recreate the missing ones.

**/

CREATE PROCEDURE Prod_Auto_Backward(@snap_date DATE)
AS
BEGIN
	IF EXISTS(SELECT name FROM sys.tables WHERE name='opp_copy')
	DROP TABLE opp_copy

	SELECT * INTO Opp_copy FROM Opportunity  WHERE isdeleted=0 AND isharddeleted=0

	IF  EXISTS(SELECT name FROM sys.tables WHERE name='ofh_copy')
	DROP TABLE ofh_copy

	SELECT * INTO ofh_copy FROM OpportunityFieldHistory  
	where field IN ('Name', 'Type', 'Manager__c','Heat_Map__c', 'StageName','CloseDate')

	ALTER TABLE OFH_Copy ADD  opp_created_date DATE

	UPDATE OFH_Copy SET opp_created_date = CAST(b.createddate AS DATE)
	FROM OFH_Copy a JOIN Opp_copy b 
	ON a.opportunityid = b.id

	UPDATE Opp_copy
	SET type='ABCD'
	WHERE type IS NULL

	UPDATE Opp_copy
	SET Manager__c='ABCD'
	WHERE Manager__c IS NULL

	UPDATE OFH_Copy
	SET OldValue='ABCD'
	WHERE OldValue IS NULL
	AND Field IN ('Type', 'Manager__c')

	UPDATE OFH_Copy
	SET NewValue='ABCD'
	WHERE NewValue IS NULL
	AND Field IN ('Type', 'Manager__c')

	IF  EXISTS(SELECT name FROM sys.tables WHERE name='rev_copy')
	DROP TABLE rev_copy

	SELECT * INTO rev_copy FROM RevenueSchedule WHERE isdeleted=0 AND isharddeleted=0

	IF  EXISTS(SELECT name FROM sys.tables WHERE name='rfh_copy')
	DROP TABLE rfh_copy

	SELECT  * INTO rfh_copy FROM RevenueScheduleHistory
	WHERE field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	ALTER TABLE RFH_Copy 
	ADD  Rev_created_date DATE

	ALTER TABLE RFH_Copy
	ALTER COLUMN NewValue FLOAT

	ALTER TABLE RFH_Copy
	ALTER COLUMN OldValue FLOAT

	UPDATE RFH_Copy SET Rev_created_date = CAST(b.createddate AS DATE) FROM RFH_Copy a JOIN Rev_Copy b 
	ON a.ParentId = b.id

	UPDATE Rev_copy
	SET Committed_Amount__c=999950000
	WHERE Committed_Amount__c IS NULL

	UPDATE Rev_copy
	SET Projection__c=999950000
	WHERE Projection__c IS NULL

	UPDATE Rev_copy
	SET Actual__c=999950000
	WHERE Actual__c IS NULL

	UPDATE RFH_Copy
	SET OldValue=999950000
	WHERE OldValue IS NULL
	AND Field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	UPDATE RFH_Copy
	SET NewValue=999950000
	WHERE NewValue IS NULL
	AND Field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	/* Number of Loops*/
	DECLARE @cnti INT=99
	DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))
	/* Name of week in the Reverse Order*/
	DECLARE @week INT=1
	DECLARE @counter1 INT
	

	WHILE @cnti>0
	BEGIN

	SET @counter1=0
	

	SELECT @counter1=COUNT(DISTINCT Snapshot_Date) FROM Product_Line_Snapshot
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date)  and  Snapshot_type  LIKE 'WEEK%'

	
	

	IF(@counter1=0)
	BEGIN
	DELETE FROM Product_Line_Snapshot 
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date) AND Snapshot_type LIKE 'WEEK%'
	
	SET @snap_date=(SELECT DATEADD(DD, -1, @snap_date))
	EXEC dbo.PL_Weekly_Snapshot_Creation @snap_date
	SET @snap_date=(SELECT DATEADD(DD, 1, @snap_date))

	END

	IF(@week<10)
	BEGIN
	UPDATE  Product_Line_Snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK 0',@week))
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date) AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)

	END
	ELSE
	BEGIN
	UPDATE  Product_Line_Snapshot
	SET
	Snapshot_type =(SELECT CONCAT('WEEK ',@week))
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date) AND (Snapshot_type  LIKE 'WEEK%' OR Snapshot_type IS NULL)

	END
	
	SET @snap_date= DATEADD(DD,-7,@snap_date)
	SET @cnti=@cnti-1
	SET @week=@week+1
	END
	
		IF  EXISTS(SELECT name FROM sys.tables WHERE name='OFH_Copy')
		DROP TABLE OFH_Copy

		IF  EXISTS(SELECT name FROM sys.tables WHERE name='RFH_Copy')
		DROP TABLE RFH_Copy

		IF  EXISTS(SELECT name FROM sys.tables WHERE name='Opp_copy')
		DROP TABLE Opp_copy

		IF  EXISTS(SELECT name FROM sys.tables WHERE name='Rev_copy')
		DROP TABLE Rev_copy
	

	END
