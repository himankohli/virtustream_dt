ALTER PROCEDURE sp_PLS_wRollover_Waterfall
AS
BEGIN

SET NOCOUNT ON

DROP TABLE IF  EXISTS u_PLS_wRollover_Waterfall

CREATE TABLE  u_PLS_wRollover_Waterfall
(
pl_id NVARCHAR(50),
pl_name NVARCHAR(255),
pl_product__c NVARCHAR(255),
pl_service_line__c NVARCHAR(255),
pl_practice_line__c NVARCHAR(255),
pl_booked_amount__c FLOAT,
pl_annual_contact_value_year_1__c FLOAT,
pl_committed_contract_value__c FLOAT,
opp_id NVARCHAR(20),
opp_closedate DATE,
opp_ownerid NVARCHAR(255),
opp_createddate DATE,
opp_name NVARCHAR(255),
opp_stagename NVARCHAR(255),
opp_probability FLOAT,
opp_segment__c NVARCHAR(255),
opp_type NVARCHAR(255),
opp_leadsource NVARCHAR(255),
opp_gate__c NVARCHAR(255),
opp_heat_map__c BIT,
opp_opportunity_number__c NVARCHAR(255),
opp_sub_segment__c NVARCHAR(255),
opp_emc_opportunity_number__c NVARCHAR(255),
opp_lead_partner_type__c NVARCHAR(255),
opp_primary_partner_role__c NVARCHAR(255),
[opp_lead_partner__c] NVARCHAR(255),
opp_dell_technologies_business__c NVARCHAR(255),
opp_opportunity_age__c FLOAT,
opp_theatre__c NVARCHAR(255),
opp_close_fiscal_quarter NVARCHAR(255),
acc_name NVARCHAR(255),
acc_segment__c NVARCHAR(255),
acc_dell_emc_segment__c NVARCHAR(255),
product_name NVARCHAR(255),
product_family NVARCHAR(255),
user_name NVARCHAR(255),
user_division NVARCHAR(255),
user_department NVARCHAR(255),
user_email NVARCHAR(255),
ur_owner_role_name NVARCHAR(255),
revschd_forecast_amount__c FLOAT,
revschd_ccv_final FLOAT,
revschd_acv_final FLOAT,
revschd_booked_amount_final FLOAT,
m3_role_name  NVARCHAR(255),
user_employeenumber NVARCHAR(255),
product_quant_practice_group__c NVARCHAR(255),
product_quant_practice_group_previous  NVARCHAR(255),
fiscal_period NVARCHAR(255),
ccv_por_value FLOAT,
acv_por_value FLOAT,
field_source NVARCHAR(255),
por_type NVARCHAR(255),
quota_value FLOAT,
role_quota FLOAT,
territory_quota FLOAT,
strategic_alliance_flag BIT,
closedate_change_count INT,
channel VARCHAR(255),
opp_dell_technologies_role__c VARCHAR(255),
sales_channel VARCHAR(255),
opp_application_flag BIT,
latest_annual_contact_value_year_1__c FLOAT,
latest_committed_contract_value__c FLOAT,
latest_booked_amount__c FLOAT,
latest_revschd_ccv_final FLOAT,
latest_revschd_acv_final FLOAT,
latest_revschd_booked_amount_final FLOAT,
latest_stagename NVARCHAR(255),
latest_closedate DATE,
latest_fiscal_quarter NVARCHAR(255),
latest_gate NVARCHAR(255),
latest_heatmap NVARCHAR(255),
snapshot_type NVARCHAR(50),
snapshot_date DATE,
snapshot_fiscal_quarter NVARCHAR(255),
current_fiscal_quarter NVARCHAR(255),
snapshot_week NVARCHAR(255),
current_fiscal_period NVARCHAR(255),
opp_created_before_snapshot_flag BIT,
pl_created_before_snapshot_flag BIT,
row_type NVARCHAR(255),
)


	SELECT  CAST(NULL AS NVARCHAR(255)) as [pl_id]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_name]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_product__c]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_service_line__c]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_practice_line__c]
      ,  CAST(NULL AS FLOAT)  as [pl_booked_amount__c]
      ,  CAST(NULL AS FLOAT)  as [pl_annual_contact_value_year_1__c]
      ,  CAST(NULL AS FLOAT)  as [pl_committed_contract_value__c]
      ,b.[opp_id]
      ,[opp_closedate]
      ,[opp_ownerid]
      ,[opp_createddate]
      ,[opp_accountid]
      ,[opp_name]
      ,[opp_stagename]
      ,[opp_probability]
      ,[opp_type]
      ,[opp_leadsource]
      ,[opp_isclosed]
      ,[opp_iswon]
      ,[opp_gate__c]
      ,[opp_heat_map__c]
      ,[opp_primary_data_center__c]
      ,[opp_sales_channel__c]
      ,[opp_secondary_data_center__c]
      ,[opp_opportunity_number__c]
      ,[opp_sub_segment__c]
      ,[opp_emc_opportunity_number__c]
      ,[opp_lead_partner_type__c]
      ,[opp_lead_partner__c]
      ,[opp_opportunity_conversion__c]
      ,[opp_related_opportunity__c]
      ,[opp_related_product_amount__c]
      ,[opp_so_number__c]
      ,[opp_dell_technologies_business__c]
      ,[opp_opportunity_age__c]
      ,[opp_pardot_campaign__c]
      ,[opp_primary_partner_role__c]
      ,[acc_name]
      ,[acc_segment__c]
      ,[acc_dell_emc_segment__c]
      ,[product_name]
      ,[product_family]
      ,[user_id]
      ,[user_name]
      ,[user_division]
      ,[user_department]
      ,[user_email]
      ,[user_userroleid]
      ,[user_managerid]
      ,[user_forecastenabled]
      ,[ur_owner_role_name]
      , CAST(NULL AS FLOAT) as [revschd_committed_amount__c]
      , CAST(NULL AS FLOAT) as [revschd_projection__c]
      , CAST(NULL AS FLOAT) as [revschd_actual__c]
      , CAST(NULL AS FLOAT) as [revschd_forecast_amount__c]
      , CAST(NULL AS FLOAT) as [revschd_ccv_final]
      , CAST(NULL AS FLOAT) as [revschd_acv_final]
      , CAST(NULL AS FLOAT) as [revschd_booked_amount_final]
      ,[m1_role_name]
      ,[m2_role_name]
      ,[m3_role_name]
      ,[m4_role_name]
      ,[m5_role_name]
      ,[role_level]
      ,[hierarchy_global]
      ,[hierarchy_theatre]
      ,[hierarchy_segment]
      ,[hierarchy_division]
      ,[hierarchy_area]
      ,[user_employeenumber]
      ,[opp_country__c]
      ,[opp_theatre__c]
      , CAST(NULL AS NVARCHAR(255)) as [product_quant_practice_group__c]
      ,[opp_segment__c]
      ,[opp_close_fiscal_quarter]
      ,[fiscal_period]
      ,[id_rev_schd]
      ,[ccv_por_value]
      ,[acv_por_value]
      ,[field_source]
      ,[por_type]
      ,[quota_value]
      ,[role_quota]
      ,[territory_quota]
      ,[latest_annual_contact_value_year_1__c]
      ,[latest_committed_contract_value__c]
      ,[latest_booked_amount__c]
      ,[latest_revschd_ccv_final]
      ,[latest_revschd_acv_final]
      ,[latest_revschd_booked_amount_final]
      ,[latest_stagename]
      ,[latest_closedate]
      ,[latest_fiscal_quarter]
      ,[latest_gate]
      ,[latest_heatmap]
      ,b.[snapshot_type]
      ,b.[snapshot_date]
      ,[snapshot_fiscal_quarter]
      ,[current_fiscal_period]
      ,[isharddeleted]
      ,[strategic_alliance_flag]
      ,[latest_strategic_alliance_flag]
      ,[latest_theatre]
      ,[latest_lob]
      ,[latest_segment]
      ,[latest_dell_emc_segment]
      ,[opp_application_flag]
      ,[latest_opp_application_flag]
      ,[closedate_change_count]
      ,[channel]
      ,[opp_dell_technologies_role__c]
      ,[latest_primary_partner_role__c]
      ,[latest_channel]
      ,[latest_dell_technologies_role__c]
      ,[sales_channel]
      ,[latest_sales_channel],
	  opp_ForecastCategory, opp_forecast_alignment__c 
	 INTO #opps_wo_pl FROM (
	SELECT 
	* FROM (SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=1 ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT Id FROM Opportunity where isharddeleted=0)
	GROUP BY snapshot_type, snapshot_date, opp_id) a EXCEPT
	(SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=0 ANd snapshot_type<='WEEK 13'
	GROUP BY snapshot_type, snapshot_date, opp_id)
	UNION ALL
	SELECT DISTINCT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where field_Source ='SFDC' AND isharddeleted IS NULL ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT Id FROM Opportunity where isharddeleted=0)
	) a JOIN (SELECT *, ROW_NUMBER() OVER (PARTITION BY snapshot_Type, snapshot_date, opp_id
	ORDER BY pl_id) as Rk FROM Product_Line_Snapshot where (isharddeleted=1 OR isharddeleted IS NULL)) b
	ON a.snapshot_type=b.snapshot_type AND a.snapshot_date=b.snapshot_date
	AND a.opp_id=b.opp_id
	WHERE b.Rk=1 AND ISNULL(b.product_quant_practice_group__c,'a')<>'Managed Services'
				AND ISNULL(b.opp_type,'a') <> 'CSP-Sell Out'
	
	 
----------------- BASE COLUMN INSERTION INTO TABLE --------------------

ALTER INDEX ix_waterfall ON Product_Line_Snapshot
REBUILD;

INSERT INTO u_PLS_wRollover_Waterfall 
(
pl_id ,
pl_name ,
pl_product__c ,
pl_service_line__c,
pl_practice_line__c ,
pl_booked_amount__c ,
pl_annual_contact_value_year_1__c ,
pl_committed_contract_value__c ,
opp_id,
opp_closedate ,
opp_ownerid ,
opp_createddate ,
opp_name,
opp_stagename,
opp_probability ,
opp_segment__c ,
opp_type,
opp_leadsource ,
opp_gate__c ,
opp_heat_map__c ,
opp_opportunity_number__c ,
opp_sub_segment__c ,
opp_emc_opportunity_number__c ,
opp_lead_partner_type__c,
opp_primary_partner_role__c,
[opp_lead_partner__c],
opp_dell_technologies_business__c ,
opp_opportunity_age__c ,
opp_theatre__c,
opp_close_fiscal_quarter ,
acc_name ,
acc_segment__c ,
acc_dell_emc_segment__c,
product_name ,
product_family ,
user_name,
user_division ,
user_department ,
user_email ,
ur_owner_role_name,
revschd_forecast_amount__c ,
revschd_ccv_final ,
revschd_acv_final ,
revschd_booked_amount_final ,
m3_role_name ,
user_employeenumber ,
product_quant_practice_group__c ,
product_quant_practice_group_previous,
fiscal_period ,
ccv_por_value ,
acv_por_value ,
field_source ,
por_type ,
quota_value ,
role_quota ,
territory_quota ,
strategic_alliance_flag,
closedate_change_count,
channel,
opp_dell_technologies_role__c ,
sales_channel,
opp_application_flag,
latest_annual_contact_value_year_1__c ,
latest_committed_contract_value__c ,
latest_booked_amount__c ,
latest_revschd_ccv_final ,
latest_revschd_acv_final ,
latest_revschd_booked_amount_final,
latest_stagename ,
latest_closedate ,
latest_fiscal_quarter,
latest_gate ,
latest_heatmap ,
snapshot_type,
snapshot_date ,
snapshot_fiscal_quarter ,
current_fiscal_quarter ,
snapshot_week ,
current_fiscal_period ,
opp_created_before_snapshot_flag ,
pl_created_before_snapshot_flag ,
row_type)
SELECT ISNULL(b.pl_id,b.opp_id) as pl_id,
		b.pl_name as pl_name,
		b.pl_product__c as pl_product__c,
		b.pl_service_line__c  as pl_service_line__c,
		b.pl_practice_line__c  as pl_practice_line__c,
		b.pl_booked_amount__c  as pl_booked_amount__c,
		b.pl_annual_contact_value_year_1__c  as pl_annual_contact_value_year_1__c,
		b.pl_committed_contract_value__c  as pl_committed_contract_value__c,
		b.opp_id  as opp_id,
		coalesce(c.opp_closedate, b.opp_closedate)  as opp_closedate,--10
		b.opp_ownerid  as opp_ownerid,
		b.opp_createddate  as opp_createddate,
		b.opp_name  as opp_name,
		CASE 
			WHEN c.pl_id IS NOT NULL
			THEN coalesce(c.opp_stagename, b.opp_stagename)
			ELSE (SELECT DISTINCT opp_stagename FROM Product_Line_Snapshot 
	 where snapshot_type= a.snapshot_type and opp_id= b.opp_id)
		END as opp_stagename,
		coalesce(c.opp_probability, b.opp_probability)  as opp_probability,
		b.opp_segment__c  as opp_segment__c,
		b.opp_type  as opp_type,
		b.opp_leadsource  as opp_leadsource,
		b.opp_gate__c  as opp_gate__c,
		CASE 
			WHEN c.pl_id IS NOT NULL
			THEN coalesce(c.opp_heat_map__c, b.opp_heat_map__c)
			ELSE (SELECT DISTINCT opp_heat_map__c FROM Product_Line_Snapshot 
	 where snapshot_type= a.snapshot_type and opp_id= b.opp_id)
		END 
		  as opp_heat_map__c,
		b.opp_opportunity_number__c  as opp_opportunity_number__c,
		b.opp_sub_segment__c  as opp_sub_segment__c,
		b.opp_emc_opportunity_number__c  as opp_emc_opportunity_number__c,
		b.opp_lead_partner_type__c as opp_lead_partner_type__c,
		b.opp_primary_partner_role__c as opp_primary_partner_role__c,
		b.[opp_lead_partner__c],
		b.opp_dell_technologies_business__c  as opp_dell_technologies_business__c,
		b.opp_opportunity_age__c as opp_opportunity_age__c,
		b.opp_theatre__c as opp_theatre__c ,
		CASE 
			WHEN c.pl_id IS NOT NULL
			THEN coalesce(c.opp_close_fiscal_quarter, b.opp_close_fiscal_quarter)
			ELSE (SELECT DISTINCT opp_close_fiscal_quarter FROM Product_Line_Snapshot 
	 where snapshot_type= a.snapshot_type and opp_id= b.opp_id)
		END 
		  as opp_close_fiscal_quarter,
		b.acc_name  as acc_name,
		b.acc_segment__c as acc_segment__c,--40
		b.acc_dell_emc_segment__c  as acc_dell_emc_segment__c,
		b.product_name  as product_name,
		b.product_family  as product_family,
		b.user_name  as user_name,
		b.user_division  as user_division,
		b.user_department  as user_department,
		b.user_email  as user_email,
		b.ur_owner_role_name  as ur_owner_role_name,
		coalesce(c.revschd_forecast_amount__c, b.revschd_forecast_amount__c)  as revschd_forecast_amount__c,
		CASE WHEN c.product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(c.opp_type,'a') <> 'CSP-Sell Out'
		THEN c.revschd_ccv_final 
		ELSE 0 END as revschd_ccv_final,
		CASE WHEN c.product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(c.opp_type,'a') <> 'CSP-Sell Out'
		THEN c.revschd_acv_final 
		ELSE 0 END  as revschd_acv_final,
		CASE WHEN c.product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(c.opp_type,'a') <> 'CSP-Sell Out'
		THEN c.revschd_booked_amount_final
		ELSE 0 END  as revschd_booked_amount_final,
		b.m3_role_name  as  m3_role_name,
		b.user_employeenumber  as user_employeenumber,
		b.product_quant_practice_group__c  as product_quant_practice_group__c,
		c.product_quant_practice_group__c  as product_quant_practice_group_previous,
		coalesce(c.fiscal_period, b.fiscal_period)  as fiscal_period,
		coalesce(c.ccv_por_value, b.ccv_por_value)  as ccv_por_value,
		coalesce(c.acv_por_value, b.acv_por_value)  as acv_por_value,
		coalesce(c.field_source, b.field_source) as field_source ,
		coalesce(c.por_type, b.por_type)  as por_type,
		b.quota_value  as quota_value,
		b.role_quota  as role_quota,
		b.territory_quota  as territory_quota,
		b.strategic_alliance_flag as strategic_alliance_flag,
		b.closedate_change_count as closedate_change_count,
		b.channel as channel,
b.opp_dell_technologies_role__c as opp_dell_technologies_role__c,
		b.sales_channel,
		b.opp_application_flag as opp_application_flag,
		b.latest_annual_contact_value_year_1__c  as latest_annual_contact_value_year_1__c,
		b.latest_committed_contract_value__c  as latest_committed_contract_value__c,
		b.latest_booked_amount__c as latest_booked_amount__c ,
		CASE WHEN b.product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(b.opp_type,'a') <> 'CSP-Sell Out'
		THEN b.revschd_ccv_final 
		ELSE 0 END  as latest_revschd_ccv_final,
		CASE WHEN b.product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(b.opp_type,'a') <> 'CSP-Sell Out'
		THEN b.revschd_acv_final 
		ELSE 0 END   as latest_revschd_acv_final ,
		CASE WHEN b.product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(b.opp_type,'a') <> 'CSP-Sell Out'
		THEN b.revschd_booked_amount_final 
		ELSE 0 END   as latest_revschd_booked_amount_final,
		b.latest_stagename  as latest_stagename,
		b.latest_closedate  as latest_closedate,
		b.latest_fiscal_quarter  as latest_fiscal_quarter,
		b.latest_gate  as latest_gate,
		b.latest_heatmap  as latest_heatmap,
		a.snapshot_type  as snapshot_type,
		(SELECT DISTINCT snapshot_date FROM Product_Line_Snapshot
		WHERE snapshot_type=a.snapshot_type) as snapshot_date ,
		(SELECT DISTINCT fiscal_qtr FROM FiscalQuarters
		WHERE date=((SELECT DISTINCT snapshot_date FROM Product_Line_Snapshot
		WHERE snapshot_type=a.snapshot_type))) as snapshot_fiscal_quarter,
		(SELECT DISTINCT fiscal_qtr FROM FiscalQuarters
		WHERE date=(SELECT CAST(GETDATE() AS DATE))) as current_fiscal_quarter,
		(SELECT DISTINCT WEEK FROM FiscalQuarters
		WHERE date=((SELECT DISTINCT snapshot_date FROM Product_Line_Snapshot
		WHERE snapshot_type=a.snapshot_type))) as snapshot_week,
		b.current_fiscal_period  as current_fiscal_period,
		CASE 
			WHEN coalesce(c.opp_createddate, b.opp_createddate) <=(SELECT DISTINCT 
			snapshot_date FROM Product_Line_Snapshot
				WHERE snapshot_type=a.snapshot_type)
			THEN 1
			ELSE 0
		END  as opp_created_before_snapshot_flag,
		CASE 
			WHEN c.pl_id IS NOT NULL
			THEN 1
			ELSE 0
		END as pl_created_before_snapshot_flag,
		'Rows' as row_type
from 
(SELECT DISTINCT Snapshot_type  FROM Product_Line_Snapshot 
WHERE snapshot_type<='WEEK 13' AND field_source='SFDC' AND pl_id IS NOT NULL) a
cross join (SELECT * FROM Product_Line_Snapshot
WHERE snapshot_type='DAY 01' AND field_source='SFDC') b
LEFT JOIN
(SELECT * FROM Product_Line_Snapshot 
WHERE snapshot_type<='WEEK 13' AND field_source='SFDC'
UNION
SELECT * FROM #opps_wo_pl) c
ON a.snapshot_type=c.snapshot_type 
and ISNULL(b.pl_id,b.opp_id)=ISNULL(c.pl_id,c.opp_id)

---------------------------------------------- INDEXES   ------------------------------------------------
CREATE CLUSTERED INDEX ix_waterfall ON [dbo].[u_PLS_wRollover_Waterfall] (Snapshot_type, pl_id, opp_id);


CREATE NONCLUSTERED INDEX ix_waterfall_nc ON [dbo].[u_PLS_wRollover_Waterfall] (Snapshot_type, pl_id, opp_stagename, latest_stagename )
INCLUDE(revschd_ACV_final,
revschd_booked_amount_final,
latest_revschd_ACV_final,
latest_revschd_booked_amount_final);

---------------------------------- HASH TABLE COMPUTATIONS ------------------------------------------
SELECT * INTO #qtrlist 
FROM (
SELECT TOP 8 fiscal_qtr, ROW_NUMBER() OVER(ORDER BY fiscal_qtr ASC) as row_num FROM (
SELECT DISTINCT fiscal_qtr FROM FiscalQuarters WHERE fiscal_qtr >= (
SELECT LTRIM(CONCAT(STR(CAST(LEFT(fiscal_qtr,4)as INT) - 1),RIGHT(fiscal_qtr,3))) FROM FiscalQuarters WHERE date = CAST (GETDATE() as DATE))
) v
ORDER BY fiscal_qtr ASC) a

SELECT * INTO #opptags FROM 
(SELECT  snapshot_type, opp_id, SUM(revschd_booked_amount_final) as revschd_booked_amount_final, SUM(latest_revschd_booked_amount_final) as latest_revschd_booked_amount_final, 
	SUM(revschd_ccv_final) as revschd_ccv_final, SUM(latest_revschd_ccv_final) as latest_revschd_ccv_final, SUM(revschd_acv_final) as revschd_acv_final, SUM(latest_revschd_acv_final) as latest_revschd_acv_final 
	FROM u_PLS_wRollover_Waterfall
GROUP BY snapshot_type, opp_id) a

ALTER TABLE #opptags 
ADD booked_amt_tag NVARCHAR(255), ccv_tag NVARCHAR(255), acv_tag NVARCHAR(255)

UPDATE d SET booked_amt_tag = c.tag FROM
#opptags d JOIN
(SELECT snapshot_type, opp_id, (CASE WHEN (ISNULL(revschd_booked_amount_final,0) - ISNULL(latest_revschd_booked_amount_final,0)) > 0.5 THEN 'Value Decreased' 
	WHEN  (ISNULL(revschd_booked_amount_final,0) - ISNULL(latest_revschd_booked_amount_final,0)) < -0.5 THEN 'Value Increased' ELSE NULL END) 
	as tag FROM #opptags) c
on c.snapshot_type  = d.snapshot_type AND c.opp_id= d.opp_id;

UPDATE d SET ccv_tag = c.tag FROM
#opptags d JOIN
(SELECT snapshot_type, opp_id, (CASE WHEN (ISNULL(revschd_ccv_final,0) - ISNULL(latest_revschd_ccv_final,0)) > 0.5 THEN 'Value Decreased' 
	WHEN  (ISNULL(revschd_ccv_final,0) - ISNULL(latest_revschd_ccv_final,0)) < -0.5 THEN 'Value Increased' ELSE NULL END) as tag FROM #opptags) c
on c.snapshot_type  = d.snapshot_type AND c.opp_id= d.opp_id;

UPDATE d SET acv_tag = c.tag FROM
#opptags d JOIN
(SELECT snapshot_type, opp_id, (CASE WHEN (ISNULL(revschd_acv_final,0) - ISNULL(latest_revschd_acv_final,0)) > 0.5 THEN 'Value Decreased' 
	WHEN  (ISNULL(revschd_acv_final,0) - ISNULL(latest_revschd_acv_final,0)) < -0.5 THEN 'Value Increased' ELSE NULL END) 
	as tag FROM #opptags) c
on c.snapshot_type  = d.snapshot_type AND c.opp_id= d.opp_id;


------------------------- COLUMN ADDITIONS TO SCHEMA -----------------------------------

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_cq_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_cq_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_cq_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_cq_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_cq_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_cq_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_cq_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_cq_acv NVARCHAR(255);

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p4q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p4q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p4q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p4q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p4q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p4q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p4q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p4q_acv NVARCHAR(255);

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p3q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p3q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p3q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p3q_acv NVARCHAR(255);

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p2q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p2q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p2q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p2q_acv NVARCHAR(255);

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_p1q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_p1q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_p1q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_p1q_acv NVARCHAR(255);

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_f1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_f1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_f1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_f1q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_f1q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_f1q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_f1q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_f1q_acv NVARCHAR(255);

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_f2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_f2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_f2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_f2q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_f2q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_f2q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_f2q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_f2q_acv NVARCHAR(255);

ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_f3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_f3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_f3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_f3q_booked NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_bookings_f3q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_forecast_f3q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_chm_f3q_acv NVARCHAR(255);
ALTER TABLE u_PLS_wRollover_Waterfall ADD mc_pipeline_f3q_acv NVARCHAR(255);

-------------------CQ BOOKED AMOUNT---------------------------------


UPDATE d SET mc_bookings_cq_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 
	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5)	 THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter 
AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
 AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5)  THEN 'New'


WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
 AND opp_close_fiscal_quarter = latest_fiscal_quarter AND
  latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'


WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_cq_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5) THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5) THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_cq_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_cq_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5)  THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)' 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5) THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)'AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)'AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;



---------------------------------------- CQ ACV --------------------------------------------


UPDATE d SET mc_bookings_cq_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 
	AND latest_stagename IN ('99% Won (Closed/Won)',
	'100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)',
'100% Won (closed/won)') AND opp_close_fiscal_quarter = 
(SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter 
AND latest_stagename IN ('99% Won (Closed/Won)',
'100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter
 = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename 
IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_cq_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_cq_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)'))
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5)  THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_cq_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 5)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 5) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 5)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)'AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)'AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 5) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


------------------------------------------- P4Q BOOKED --------------------------------------------------

UPDATE d SET mc_bookings_p4q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p4q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p4q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p4q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)'AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)'AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


---------------------------------------- P4Q ACV --------------------------------------------


UPDATE d SET mc_bookings_p4q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 
	THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p4q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p4q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p4q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 1)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1)  THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 1)  THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 1)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)'AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 1) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


-------------------------------------------- P3Q BOOKED AMOUNT -----------------------------------------------------

UPDATE d SET mc_bookings_p3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

---------------------------------------- P3Q ACV --------------------------------------------


UPDATE d SET mc_bookings_p3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2)  THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2) THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2) THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 2)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 2) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 2)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 2) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

-------------------------------------------- P2Q BOOKED AMOUNT -----------------------------------------------------

UPDATE d SET mc_bookings_p2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)  	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3)  THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)  THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)' 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3) THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

---------------------------------------- P2Q ACV --------------------------------------------


UPDATE d SET mc_bookings_p2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3) THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 3)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 3) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)' 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 3) THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 3) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


-------------------------------------------- P1Q BOOKED AMOUNT -----------------------------------------------------

UPDATE d SET mc_bookings_p1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4)THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4) THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4)  THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)'))
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4) THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

---------------------------------------- P1Q ACV --------------------------------------------


UPDATE d SET mc_bookings_p1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_p1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4) THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4) THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_p1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_p1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 4)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 4) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)' 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 4) THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 4) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


-------------------------------------------- F1Q BOOKED AMOUNT -----------------------------------------------------

UPDATE d SET mc_bookings_f1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_f1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6) THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_f1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6)  THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_f1q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)  THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

---------------------------------------- F1Q ACV --------------------------------------------


UPDATE d SET mc_bookings_f1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_f1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6) THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_f1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6)  THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6)  THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_f1q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 6)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 6)  THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 6) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


-------------------------------------------- F2Q BOOKED AMOUNT -----------------------------------------------------

UPDATE d SET mc_bookings_f2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7)  THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 6)  THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_f2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 7)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_f2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)  THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)'))
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 7)  THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_f2q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)  THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7)  THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)' 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 7) THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

---------------------------------------- F2Q ACV --------------------------------------------


UPDATE d SET mc_bookings_f2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7)  THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 7) THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_f2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 7)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_f2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)'))
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 7)  THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_f2q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 7)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 7) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 7)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 7) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;



-------------------------------------------- F3Q BOOKED AMOUNT -----------------------------------------------------

UPDATE d SET mc_bookings_f3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8)  THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_f3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8)  THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_f3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_f3q_booked = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8) THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)' 
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8) THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT booked_amt_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

---------------------------------------- F3Q ACV --------------------------------------------


UPDATE d SET mc_bookings_f3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New' 
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND  opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8) THEN 'Dropped From Bookings'
WHEN opp_stagename NOT IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8)  THEN 'New'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_forecast_f3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') THEN 'New'  -- New Creations
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND 
	latest_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND opp_close_fiscal_quarter = latest_fiscal_quarter   AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8) THEN 'Dropped From Thru 75%'
WHEN opp_stagename NOT IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  
	AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')
	AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)')  AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') AND 
	opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_chm_f3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) THEN 'New'  -- New Creations
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND 
latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter >latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter < 
(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter <latest_fiscal_quarter AND (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND 
		opp_stagename <>'0% Lost (Closed/Lost)')) AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND 
	(latest_stagename IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND latest_heatmap = 0) AND opp_close_fiscal_quarter = latest_fiscal_quarter  AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8) THEN 'Dropped From Thru CHM'
WHEN ((opp_stagename  IN ('20% Raw Pipeline','40% Qualified Pipeline','60% Upside') AND opp_heat_map__c = 0) OR opp_stagename = '0% Lost (Closed/Lost)')
	AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) 
		AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8) THEN 'New'  -- Stage Changed  
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN (opp_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (opp_heat_map__c = 1 AND opp_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = latest_fiscal_quarter AND (latest_stagename IN ('75% Strong Upside','90% Commit','99% Won (Closed/Won)','100% Booked (Closed/Won)','100% Won (closed/won)') OR (latest_heatmap = 1 AND 
		latest_stagename <>'0% Lost (Closed/Lost)')) AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;


UPDATE d SET mc_pipeline_f3q_acv = c.tag FROM u_PLS_wRollover_Waterfall d LEFT JOIN 
(SELECT snapshot_type, pl_id,
	(CASE WHEN opp_created_before_snapshot_flag = 0 AND latest_stagename <> '0% Lost (Closed/Lost)' THEN 'New'  -- New Creations
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
WHERE row_num = 8)  AND latest_stagename = '0% Lost (Closed/Lost)' THEN 'Lost' 
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Future Qtr
WHEN opp_close_fiscal_quarter > latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter < (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) 	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'Moved Pushed'
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND latest_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) THEN 'New'  -- Pulled In from Past Qtr
WHEN opp_close_fiscal_quarter < latest_fiscal_quarter AND opp_stagename <> '0% Lost (Closed/Lost)' AND latest_fiscal_quarter > (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)	AND opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8)  THEN 'Moved Pushed'
WHEN opp_stagename <> '0% Lost (Closed/Lost)' AND latest_stagename = '0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist
WHERE row_num = 8)  THEN 'Dropped From Pipeline'
WHEN opp_stagename = '0% Lost (Closed/Lost)'	AND latest_stagename <> '0% Lost (Closed/Lost)'
AND latest_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist WHERE row_num = 8)  THEN 'New'  -- Stage Changed  
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Increased' THEN 'Value Increased'
WHEN opp_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = latest_fiscal_quarter AND latest_stagename <>'0% Lost (Closed/Lost)' AND opp_close_fiscal_quarter = (SELECT fiscal_qtr FROM #qtrlist 
	WHERE row_num = 8) AND (SELECT acv_tag FROM #opptags b 
	WHERE  a.snapshot_type = b.snapshot_type and a.opp_id = b.opp_id) = 'Value Decreased' THEN 'Value Decreased'
END) as tag FROM u_PLS_wRollover_Waterfall a) c ON c.snapshot_type = d.snapshot_type and c.pl_id = d.pl_id;

-------------------------------------- INSERTING POR VALUES ----------------------------------------------

INSERT INTO u_PLS_wRollover_Waterfall
SELECT a.pl_id,
a.pl_name,
a.pl_product__c,
a.pl_service_line__c,
a.pl_practice_line__c,
CAST(ISNULL(a.pl_booked_amount__c,0) AS FLOAT)  as pl_booked_amount__c,
CAST(ISNULL(a.pl_annual_contact_value_year_1__c,0) AS FLOAT)  as pl_annual_contact_value_year_1__c,
CAST(ISNULL(a.pl_committed_contract_value__c,0) AS FLOAT)  as pl_committed_contract_value__c,
a.opp_id,
a.opp_closedate,
a.opp_ownerid,
a.opp_createddate,
a.opp_name,
a.opp_stagename,
CAST(ISNULL(a.opp_probability,0) AS FLOAT) as opp_probability,
a.opp_segment__c,
a.opp_type,
a.opp_leadsource,
a.opp_gate__c,
a.opp_heat_map__c,
a.opp_opportunity_number__c,
a.opp_sub_segment__c,
a.opp_emc_opportunity_number__c,
a.opp_lead_partner_type__c,
a.opp_primary_partner_role__c,
a.[opp_lead_partner__c],
a.opp_dell_technologies_business__c,
CAST(ISNULL(a.opp_opportunity_age__c,0) AS FLOAT)  as opp_opportunity_age__c,
a.opp_theatre__c,
a.opp_close_fiscal_quarter,
a.acc_name,
a.acc_segment__c,
a.acc_dell_emc_segment__c,
a.product_name,
a.product_family,
a.user_name,
a.user_division,
a.user_department,
a.user_email,
a.ur_owner_role_name,
CAST(ISNULL(a.revschd_forecast_amount__c,0) AS FLOAT) as revschd_forecast_amount__c,
CAST(ISNULL(a.revschd_ccv_final,0) AS FLOAT) as revschd_ccv_final,
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT) as revschd_acv_final,
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT) as revschd_booked_amount_final,
a.m3_role_name as m3_role_name,
a.user_employeenumber,
a.product_quant_practice_group__c as product_quant_practice_group__c,
a.product_quant_practice_group__c as product_quant_practice_group_previous,
a.fiscal_period,
CAST(ISNULL(a.ccv_por_value,0) AS FLOAT) as ccv_por_value,
CAST(ISNULL(a.acv_por_value,0) AS FLOAT) as acv_por_value,
a.field_source,
a.por_type,
NULL AS quota_value,
NULL AS role_quota,
NULL AS territory_quota,
NULL as strategic_alliance_flag,
a.closedate_change_count as closedate_change_count,
a.channel as channel,
a.opp_dell_technologies_role__c as opp_dell_technologies_role__c,
a.sales_channel,
NULL as opp_application_flag,
b.pl_annual_contact_value_year_1__c AS latest_annual_contact_value_year_1__c,
b.pl_committed_contract_value__c AS latest_committed_contract_value__c,
b.pl_booked_amount__c AS latest_booked_amount__c,
b.revschd_ccv_final AS latest_revschd_ccv_final,
ISNULL(b.revschd_acv_final,0) AS latest_revschd_acv_final,
ISNULL(b.revschd_booked_amount_final,0) AS latest_revschd_booked_amount_final,
b.opp_stagename AS latest_stagename,
b.opp_closedate AS latest_closedate,
b.opp_close_fiscal_quarter AS latest_fiscal_quarter,
b.opp_gate__c AS latest_gate,
b.opp_heat_map__c AS latest_heatmap,
a.snapshot_type,
a.snapshot_date,
a.snapshot_fiscal_quarter,
(SELECT DISTINCT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT CAST(GETDATE() AS DATE))) as current_fiscal_quarter,
(SELECT WEEK  FROM FiscalQuarters WHERE  CAST(date AS DATE)=a.snapshot_date) as snapshot_week,
a.current_fiscal_period,
CAST(1 AS BIT) AS opp_created_before_snapshot_flag ,
CAST(1 AS BIT) AS pl_created_before_snapshot_flag ,
'Rows' as row_type,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END as mc_bookings_cq_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_cq_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_cq_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_cq_booked,


CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END as mc_bookings_cq_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_cq_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_cq_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_cq_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p4q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p4q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p4q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p4q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p4q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p4q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p4q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p4q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p3q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p3q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p3q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p3q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_p1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_p1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_p1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_p1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_f1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_f1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_f1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_f1q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_f1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_f1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_f1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_f1q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_f2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_f2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_f2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_f2q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_f2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_f2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_f2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_f2q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_f3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_f3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_f3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_booked_amount_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_booked_amount_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_f3q_booked,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_bookings_f3q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_forecast_f3q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_chm_f3q_acv,
CASE WHEN a.field_source<>'POR' AND CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)>
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Increased' 
WHEN a.field_source<>'POR' AND 
CAST(ISNULL(b.revschd_acv_final,0) AS FLOAT)<
CAST(ISNULL(a.revschd_acv_final,0) AS FLOAT)
THEN 'Value Decreased' END  as mc_pipeline_f3q_acv
FROM (SELECT * FROM Product_Line_Snapshot
		WHERE Field_Source<>'SFDC' AND snapshot_type <='WEEK 13'
		and product_quant_practice_group__c<>'Managed Services') a
		LEFT JOIN 
		(SELECT * FROM Product_Line_Snapshot
		WHERE Field_Source NOT IN ('POR','SFDC') AND snapshot_type ='DAY 01'
		and product_quant_practice_group__c<>'Managed Services') b
		ON
		a.opp_theatre__c=b.opp_theatre__c
		AND a.opp_segment__c=b.opp_segment__c
		AND a.product_quant_practice_group__c=b.product_quant_practice_group__c
		AND a.opp_close_fiscal_quarter=b.opp_close_fiscal_quarter
		AND a.field_source=b.field_source
		AND a.acc_dell_emc_segment__c=b.acc_dell_emc_segment__c

---------------- INSERTING TOTALS VALUES --------------------------

INSERT INTO u_PLS_wRollover_Waterfall
SELECT NULL as pl_id,
NULL as pl_name,
NULL as pl_product__c,
NULL as pl_service_line__c,
NULL as pl_practice_line__c,
pl_booked_amount__c as pl_booked_amount__c,
pl_annual_contact_value_year_1__c as pl_annual_contact_value_year_1__c,
pl_committed_contract_value__c as pl_committed_contract_value__c,
NULL as opp_id,
NULL as opp_closedate,
NULL as opp_ownerid,
NULL as opp_createddate,
NULL as opp_name,
Stagename as opp_stagename,
NULL as opp_probability,
Segment as opp_segment__c,
NULL as opp_type,
NULL as opp_leadsource,
Gate__c as opp_gate__c,
Heatmap as opp_heat_map__c,
NULL as opp_opportunity_number__c,
NULL as opp_sub_segment__c,
NULL as opp_emc_opportunity_number__c,
NULL as opp_lead_partner_type__c,
opp_primary_partner_role__c as opp_primary_partner_role__c,
NULL as [opp_lead_partner__c],
NULL as opp_dell_technologies_business__c,
NULL as opp_opportunity_age__c,
Theatre as opp_theatre__c,
Fiscal_Quarter as opp_close_fiscal_quarter,
NULL as acc_name,
NULL as acc_segment__c,
acc_Dell_EMC_Segment__c as acc_dell_emc_segment__c,
NULL as product_name,
NULL as product_family,
NULL as user_name,
NULL as user_division,
NULL as user_department,
NULL as user_email,
NULL as ur_owner_role_name,
NULL as revschd_forecast_amount__c,
revschd_ccv_final,
revschd_acv_final,
revschd_booked_amount_final,
NULL as m3_role_name,
NULL as user_employeenumber,
Product as product_quant_practice_group__c,
Product as product_quant_practice_group_previous,
NULL as fiscal_period,
CAST(0 AS FLOAT) as ccv_por_value,
CAST(0 AS FLOAT) as acv_por_value,
NULL as field_source,
NULL as por_type,
NULL as quota_value,
NULL as role_quota,
NULL as territory_quota,
strategic_alliance_flag as strategic_alliance_flag,
NULL as closedate_change_count,
channel as channel,
opp_dell_technologies_role__c as opp_dell_technologies_role__c,
sales_channel,
opp_application_flag as opp_application_flag,
pl_annual_contact_value_year_1__c as latest_annual_contact_value_year_1__c,
pl_committed_contract_value__c as latest_committed_contract_value__c,
pl_booked_amount__c as latest_booked_amount__c,
revschd_ccv_final as latest_revschd_ccv_final,
revschd_acv_final as latest_revschd_acv_final,
revschd_booked_amount_final as latest_revschd_booked_amount_final,
Stagename as latest_stagename,
NULL as latest_closedate,
Fiscal_Quarter as latest_fiscal_quarter,
Gate__c as latest_gate,
Heatmap as latest_heatmap,
snapshot_type,
snapshot_date,
snapshot_fiscal_quarter,
(SELECT DISTINCT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT CAST(GETDATE() AS DATE))) as current_fiscal_quarter,
(SELECT WEEK  FROM FiscalQuarters WHERE  CAST(date AS DATE)=snapshot_date) as snapshot_week,
NULL as current_fiscal_period,
CAST(1 AS BIT) AS opp_created_before_snapshot_flag ,
CAST(1 AS BIT) AS pl_created_before_snapshot_flag ,
'Totals_Actual' as row_type,
'Total Bookings Last Period' as mc_bookings_cq_booked,
'Total Thru 75% Last Period' as mc_forecast_cq_booked,
'Total Thru CHM Last Period' as mc_chm_cq_booked,
'Total Pipeline Last Period' as mc_pipeline_cq_booked,
'Total Bookings Last Period' as mc_bookings_cq_acv,
'Total Thru 75% Last Period' as mc_forecast_cq_acv,
'Total Thru CHM Last Period' as mc_chm_cq_acv,
'Total Pipeline Last Period' as mc_pipeline_cq_acv,
'Total Bookings Last Period' as mc_bookings_p4q_booked,
'Total Thru 75% Last Period' as mc_forecast_p4q_booked,
'Total Thru CHM Last Period' as mc_chm_p4q_booked,
'Total Pipeline Last Period' as mc_pipeline_p4q_booked,
'Total Bookings Last Period' as mc_bookings_p4q_acv,
'Total Thru 75% Last Period' as mc_forecast_p4q_acv,
'Total Thru CHM Last Period' as mc_chm_p4q_acv,
'Total Pipeline Last Period' as mc_pipeline_p4q_acv,
'Total Bookings Last Period' as mc_bookings_p3q_booked,
'Total Thru 75% Last Period' as mc_forecast_p3q_booked,
'Total Thru CHM Last Period' as mc_chm_p3q_booked,
'Total Pipeline Last Period' as mc_pipeline_p3q_booked,
'Total Bookings Last Period' as mc_bookings_p3q_acv,
'Total Thru 75% Last Period' as mc_forecast_p3q_acv,
'Total Thru CHM Last Period' as mc_chm_p3q_acv,
'Total Pipeline Last Period' as mc_pipeline_p3q_acv,
'Total Bookings Last Period' as mc_bookings_p2q_booked,
'Total Thru 75% Last Period' as mc_forecast_p2q_booked,
'Total Thru CHM Last Period' as mc_chm_p2q_booked,
'Total Pipeline Last Period' as mc_pipeline_p2q_booked,
'Total Bookings Last Period' as mc_bookings_p2q_acv,
'Total Thru 75% Last Period' as mc_forecast_p2q_acv,
'Total Thru CHM Last Period' as mc_chm_p2q_acv,
'Total Pipeline Last Period' as mc_pipeline_p2q_acv,
'Total Bookings Last Period' as mc_bookings_p1q_booked,
'Total Thru 75% Last Period' as mc_forecast_p1q_booked,
'Total Thru CHM Last Period' as mc_chm_p1q_booked,
'Total Pipeline Last Period' as mc_pipeline_p1q_booked,
'Total Bookings Last Period' as mc_bookings_p1q_acv,
'Total Thru 75% Last Period' as mc_forecast_p1q_acv,
'Total Thru CHM Last Period' as mc_chm_p1q_acv,
'Total Pipeline Last Period' as mc_pipeline_p1q_acv,
'Total Bookings Last Period' as mc_bookings_f1q_booked,
'Total Thru 75% Last Period' as mc_forecast_f1q_booked,
'Total Thru CHM Last Period' as mc_chm_f1q_booked,
'Total Pipeline Last Period' as mc_pipeline_f1q_booked,
'Total Bookings Last Period' as mc_bookings_f1q_acv,
'Total Thru 75% Last Period' as mc_forecast_f1q_acv,
'Total Thru CHM Last Period' as mc_chm_f1q_acv,
'Total Pipeline Last Period' as mc_pipeline_f1q_acv,
'Total Bookings Last Period' as mc_bookings_f2q_booked,
'Total Thru 75% Last Period' as mc_forecast_f2q_booked,
'Total Thru CHM Last Period' as mc_chm_f2q_booked,
'Total Pipeline Last Period' as mc_pipeline_f2q_booked,
'Total Bookings Last Period' as mc_bookings_f2q_acv,
'Total Thru 75% Last Period' as mc_forecast_f2q_acv,
'Total Thru CHM Last Period' as mc_chm_f2q_acv,
'Total Pipeline Last Period' as mc_pipeline_f2q_acv,
'Total Bookings Last Period' as mc_bookings_f3q_booked,
'Total Thru 75% Last Period' as mc_forecast_f3q_booked,
'Total Thru CHM Last Period' as mc_chm_f3q_booked,
'Total Pipeline Last Period' as mc_pipeline_f3q_booked,
'Total Bookings Last Period' as mc_bookings_f3q_acv,
'Total Thru 75% Last Period' as mc_forecast_f3q_acv,
'Total Thru CHM Last Period' as mc_chm_f3q_acv,
'Total Pipeline Last Period' as mc_pipeline_f3q_acv
FROM Product_Line_Snapshot_Totals_With_Rollover WHERE Snapshot_type<='WEEK 13'

INSERT INTO u_PLS_wRollover_Waterfall
SELECT NULL as pl_id,
NULL as pl_name,
NULL as pl_product__c,
NULL as pl_service_line__c,
NULL as pl_practice_line__c,
pl_booked_amount__c as pl_booked_amount__c,
pl_annual_contact_value_year_1__c as pl_annual_contact_value_year_1__c,
pl_committed_contract_value__c as pl_committed_contract_value__c,
NULL as opp_id,
NULL as opp_closedate,
NULL as opp_ownerid,
NULL as opp_createddate,
NULL as opp_name,
Stagename as opp_stagename,
NULL as opp_probability,
Segment as opp_segment__c,
NULL as opp_type,
NULL as opp_leadsource,
Gate__c as opp_gate__c,
Heatmap as opp_heat_map__c,
NULL as opp_opportunity_number__c,
NULL as opp_sub_segment__c,
NULL as opp_emc_opportunity_number__c,
NULL as opp_lead_partner_type__c,
opp_primary_partner_role__c as opp_primary_partner_role__c,
NULL as [opp_lead_partner__c],
NULL as opp_dell_technologies_business__c,
NULL as opp_opportunity_age__c,
Theatre as opp_theatre__c,
Fiscal_Quarter as opp_close_fiscal_quarter,
NULL as acc_name,
NULL as acc_segment__c,
acc_Dell_EMC_Segment__c as acc_dell_emc_segment__c,
NULL as product_name,
NULL as product_family,
NULL as user_name,
NULL as user_division,
NULL as user_department,
NULL as user_email,
NULL as ur_owner_role_name,
NULL as revschd_forecast_amount__c,
revschd_ccv_final,
revschd_acv_final,
revschd_booked_amount_final,
NULL as m3_role_name,
NULL as user_employeenumber,
Product as product_quant_practice_group__c,
Product as product_quant_practice_group_previous,
NULL as fiscal_period,
CAST(0 AS FLOAT) as ccv_por_value,
CAST(0 AS FLOAT) as acv_por_value,
NULL as field_source,
NULL as por_type,
NULL as quota_value,
NULL as role_quota,
NULL as territory_quota,
strategic_alliance_flag as strategic_alliance_flag,
NULL as closedate_change_count,
channel as channel,
opp_dell_technologies_role__c as opp_dell_technologies_role__c,
sales_channel,
opp_application_flag as opp_application_flag,
pl_annual_contact_value_year_1__c as latest_annual_contact_value_year_1__c,
pl_committed_contract_value__c as latest_committed_contract_value__c,
pl_booked_amount__c as latest_booked_amount__c,
revschd_ccv_final as latest_revschd_ccv_final,
revschd_acv_final as latest_revschd_acv_final,
revschd_booked_amount_final as latest_revschd_booked_amount_final,
Stagename as latest_stagename,
NULL as latest_closedate,
Fiscal_Quarter as latest_fiscal_quarter,
Gate__c as latest_gate,
Heatmap as latest_heatmap,
snapshot_type,
snapshot_date,
snapshot_fiscal_quarter,
(SELECT DISTINCT fiscal_qtr FROM FiscalQuarters WHERE date=(SELECT CAST(GETDATE() AS DATE))) as current_fiscal_quarter,
(SELECT WEEK  FROM FiscalQuarters WHERE  CAST(date AS DATE)=snapshot_date) as snapshot_week,
NULL as current_fiscal_period,
CAST(1 AS BIT) AS opp_created_before_snapshot_flag ,
CAST(1 AS BIT) AS pl_created_before_snapshot_flag ,
'Totals' as row_type,
'Total Bookings Last Period' as mc_bookings_cq_booked,
'Total Thru 75% Last Period' as mc_forecast_cq_booked,
'Total Thru CHM Last Period' as mc_chm_cq_booked,
'Total Pipeline Last Period' as mc_pipeline_cq_booked,
'Total Bookings Last Period' as mc_bookings_cq_acv,
'Total Thru 75% Last Period' as mc_forecast_cq_acv,
'Total Thru CHM Last Period' as mc_chm_cq_acv,
'Total Pipeline Last Period' as mc_pipeline_cq_acv,
'Total Bookings Last Period' as mc_bookings_p4q_booked,
'Total Thru 75% Last Period' as mc_forecast_p4q_booked,
'Total Thru CHM Last Period' as mc_chm_p4q_booked,
'Total Pipeline Last Period' as mc_pipeline_p4q_booked,
'Total Bookings Last Period' as mc_bookings_p4q_acv,
'Total Thru 75% Last Period' as mc_forecast_p4q_acv,
'Total Thru CHM Last Period' as mc_chm_p4q_acv,
'Total Pipeline Last Period' as mc_pipeline_p4q_acv,
'Total Bookings Last Period' as mc_bookings_p3q_booked,
'Total Thru 75% Last Period' as mc_forecast_p3q_booked,
'Total Thru CHM Last Period' as mc_chm_p3q_booked,
'Total Pipeline Last Period' as mc_pipeline_p3q_booked,
'Total Bookings Last Period' as mc_bookings_p3q_acv,
'Total Thru 75% Last Period' as mc_forecast_p3q_acv,
'Total Thru CHM Last Period' as mc_chm_p3q_acv,
'Total Pipeline Last Period' as mc_pipeline_p3q_acv,
'Total Bookings Last Period' as mc_bookings_p2q_booked,
'Total Thru 75% Last Period' as mc_forecast_p2q_booked,
'Total Thru CHM Last Period' as mc_chm_p2q_booked,
'Total Pipeline Last Period' as mc_pipeline_p2q_booked,
'Total Bookings Last Period' as mc_bookings_p2q_acv,
'Total Thru 75% Last Period' as mc_forecast_p2q_acv,
'Total Thru CHM Last Period' as mc_chm_p2q_acv,
'Total Pipeline Last Period' as mc_pipeline_p2q_acv,
'Total Bookings Last Period' as mc_bookings_p1q_booked,
'Total Thru 75% Last Period' as mc_forecast_p1q_booked,
'Total Thru CHM Last Period' as mc_chm_p1q_booked,
'Total Pipeline Last Period' as mc_pipeline_p1q_booked,
'Total Bookings Last Period' as mc_bookings_p1q_acv,
'Total Thru 75% Last Period' as mc_forecast_p1q_acv,
'Total Thru CHM Last Period' as mc_chm_p1q_acv,
'Total Pipeline Last Period' as mc_pipeline_p1q_acv,
'Total Bookings Last Period' as mc_bookings_f1q_booked,
'Total Thru 75% Last Period' as mc_forecast_f1q_booked,
'Total Thru CHM Last Period' as mc_chm_f1q_booked,
'Total Pipeline Last Period' as mc_pipeline_f1q_booked,
'Total Bookings Last Period' as mc_bookings_f1q_acv,
'Total Thru 75% Last Period' as mc_forecast_f1q_acv,
'Total Thru CHM Last Period' as mc_chm_f1q_acv,
'Total Pipeline Last Period' as mc_pipeline_f1q_acv,
'Total Bookings Last Period' as mc_bookings_f2q_booked,
'Total Thru 75% Last Period' as mc_forecast_f2q_booked,
'Total Thru CHM Last Period' as mc_chm_f2q_booked,
'Total Pipeline Last Period' as mc_pipeline_f2q_booked,
'Total Bookings Last Period' as mc_bookings_f2q_acv,
'Total Thru 75% Last Period' as mc_forecast_f2q_acv,
'Total Thru CHM Last Period' as mc_chm_f2q_acv,
'Total Pipeline Last Period' as mc_pipeline_f2q_acv,
'Total Bookings Last Period' as mc_bookings_f3q_booked,
'Total Thru 75% Last Period' as mc_forecast_f3q_booked,
'Total Thru CHM Last Period' as mc_chm_f3q_booked,
'Total Pipeline Last Period' as mc_pipeline_f3q_booked,
'Total Bookings Last Period' as mc_bookings_f3q_acv,
'Total Thru 75% Last Period' as mc_forecast_f3q_acv,
'Total Thru CHM Last Period' as mc_chm_f3q_acv,
'Total Pipeline Last Period' as mc_pipeline_f3q_acv
FROM Latest_PLS_Totals_wRollover WHERE Snapshot_type<='WEEK 13'

UPDATE u_PLS_wRollover_Waterfall
SET pl_id =(SELECT NULL)
WHERE pl_id=opp_id


SET NOCOUNT OFF
END



