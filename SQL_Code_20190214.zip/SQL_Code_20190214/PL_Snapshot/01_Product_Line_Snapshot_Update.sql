/**

Deletes the temporary tables (if alreadys exists), deletes the the snapshots
older than 99 weeks, and calls the procedures to create the new ones.

**/

ALTER PROCEDURE  [dbo].[Product_Line_Snapshot_Update]
AS
BEGIN 
SET NOCOUNT ON

	EXEC Currency_Snap_Master
	
	DROP TABLE IF  EXISTS [dbo].[quarter]
	DROP TABLE IF  EXISTS [dbo].[OFH_Copy]
	DROP TABLE IF  EXISTS [dbo].[RFH_Copy]
	DROP TABLE IF  EXISTS [dbo].[Opp_copy]
	DROP TABLE IF  EXISTS [dbo].[Rev_copy]
	DROP TABLE IF  EXISTS [dbo].[t_static_opps2]
	DROP TABLE IF  EXISTS [dbo].[t_ofh_last_record]
	DROP TABLE IF  EXISTS [dbo].[t_ofh_last_record2]
	DROP TABLE IF  EXISTS [dbo].[Static_Revs]
	DROP TABLE IF  EXISTS [dbo].[t_rfh_last_record]
	DROP TABLE IF  EXISTS [dbo].[t_rfh_last_record2]
	DROP TABLE IF  EXISTS [dbo].[Opportunity_temp]
	DROP TABLE IF  EXISTS [dbo].[Rev_snap]
	DROP TABLE IF  EXISTS [dbo].[Opp_Header]
	DROP TABLE IF  EXISTS [dbo].[PL_Snap]
	DROP TABLE IF  EXISTS [dbo].[int_PL_Snap]
	DROP TABLE IF  EXISTS [dbo].[Product_Line_Detail]
	
	DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))

	DECLARE @run_time TIME=(SELECT FORMAT(GETDATE(),'HH:mm:ss'))

	DECLARE @Saturday DATE
	
	SELECT @Saturday=(CASE WHEN DATEPART(weekday, @today)>6
	THEN DATEADD(DAY, +5, DATEADD(WEEK, DATEDIFF(WEEK, 0, @today), 0))
	ELSE DATEADD(DAY, -2, DATEADD(WEEK, DATEDIFF(WEEK, 0, @today), 0)) END)

	DECLARE @current_quarter NVARCHAR(255)=(SELECT fiscal_qtr FROM FiscalQuarters
	where date=(SELECT CAST(GETDATE() AS DATE)))

	DECLARE @fiscal_quarter_rank TABLE
	(
		fiscal_qtr nvarchar(255),
		[rank] int
	)

	INSERT INTO @fiscal_quarter_rank
	(
		fiscal_qtr,
		[rank]
	)
	(
		SELECT [fiscal_qtr] , row_number() over (order by [fiscal_qtr]) as rank  FROM [dbo].[FiscalQuarters]
		GROUP BY [fiscal_qtr]
	)

	DECLARE @last_quarter VARCHAR(10)=(SELECT [fiscal_qtr] from @fiscal_quarter_rank
	WHERE [rank]=(SELECT [rank]-1 FROM @fiscal_quarter_rank WHERE [fiscal_qtr]=(SELECT DISTINCT [fiscal_qtr] 
	FROM [dbo].[FiscalQuarters] WHERE [date]=@today)))

	IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='Product_Line_Snapshot')
	BEGIN
		
	/*Creating Table to lead 52 weeks data from Product Line Snapshot*/
	CREATE TABLE [dbo].[Product_Line_Snapshot](
	[pl_id] [nvarchar](255) NULL,
	[pl_name] [nvarchar](255) NULL,
	[pl_product__c] [nvarchar](255) NULL,
	[pl_service_line__c] [nvarchar](max) NULL,
	[pl_practice_line__c] [nvarchar](max) NULL,
	[pl_booked_amount__c] [float] NULL,
	[pl_annual_contact_value_year_1__c] [float] NULL,
	[pl_committed_contract_value__c] [float] NULL,
	[opp_id] [nvarchar](255) NULL,
	[opp_closedate] [datetime] NULL,
	[opp_ownerid] [nvarchar](255) NULL,
	[opp_createddate] [date] NULL,
	[opp_accountid] [nvarchar](255) NULL,
	[opp_name] [nvarchar](255) NULL,
	[opp_stagename] [nvarchar](255) NULL,
	[opp_probability] [float] NULL,
	[opp_type] [nvarchar](255) NULL,
	[opp_leadsource] [nvarchar](255) NULL,
	[opp_isclosed] [bit] NULL,
	[opp_iswon] [bit] NULL,
	[opp_gate__c] [nvarchar](255) NULL,
	[opp_heat_map__c] [bit] NULL,
	[opp_primary_data_center__c] [nvarchar](255) NULL,
	[opp_sales_channel__c] [nvarchar](255) NULL,
	[opp_secondary_data_center__c] [nvarchar](255) NULL,
	[opp_opportunity_number__c] [nvarchar](255) NULL,
	[opp_sub_segment__c] [nvarchar](255) NULL,
	[opp_emc_opportunity_number__c] [nvarchar](255) NULL,
	[opp_lead_partner_type__c] [nvarchar](255) NULL,
	[opp_lead_partner__c] [nvarchar](255) NULL,
	[opp_opportunity_conversion__c] [bit] NULL,
	[opp_related_opportunity__c] [nvarchar](255) NULL,
	[opp_related_product_amount__c] [float] NULL,
	[opp_so_number__c] [varchar](255) NULL,
	[opp_dell_technologies_business__c] [nvarchar](255) NULL,
	[opp_opportunity_age__c] [float] NULL,
	[opp_pardot_campaign__c] [nvarchar](255) NULL,
	[opp_primary_partner_role__c] [nvarchar](255) NULL,
	[acc_name] [nvarchar](255) NULL,
	[acc_segment__c] [nvarchar](255) NULL,
	[acc_dell_emc_segment__c] [nvarchar](255) NULL,
	[product_name] [nvarchar](255) NULL,
	[product_family] [nvarchar](255) NULL,
	[user_id] [nvarchar](255) NULL,
	[user_name] [nvarchar](255) NULL,
	[user_division] [nvarchar](255) NULL,
	[user_department] [nvarchar](255) NULL,
	[user_email] [nvarchar](255) NULL,
	[user_userroleid] [nvarchar](255) NULL,
	[user_managerid] [nvarchar](255) NULL,
	[user_forecastenabled] [bit] NULL,
	[ur_owner_role_name] [nvarchar](255) NULL,
	[revschd_committed_amount__c] [float] NULL,
	[revschd_projection__c] [float] NULL,
	[revschd_actual__c] [float] NULL,
	[revschd_forecast_amount__c] [float] NULL,
	[revschd_ccv_final] [float] NULL,
	[revschd_acv_final] [float] NULL,
	[revschd_booked_amount_final] [float] NULL,
	[m1_role_name] [nvarchar](255) NULL,
	[m2_role_name] [nvarchar](255) NULL,
	[m3_role_name] [nvarchar](255) NULL,
	[m4_role_name] [nvarchar](255) NULL,
	[m5_role_name] [nvarchar](255) NULL,
	[role_level] [nvarchar](255) NULL,
	[hierarchy_global] [nvarchar](255) NULL,
	[hierarchy_theatre] [nvarchar](255) NULL,
	[hierarchy_segment] [nvarchar](255) NULL,
	[hierarchy_division] [nvarchar](255) NULL,
	[hierarchy_area] [nvarchar](255) NULL,
	[user_employeenumber] [nvarchar](255) NULL,
	[opp_country__c] [nvarchar](255) NULL,
	[opp_theatre__c] [nvarchar](255) NULL,
	[product_quant_practice_group__c] [nvarchar](255) NULL,
	[opp_segment__c] [nvarchar](255) NULL,
	[opp_close_fiscal_quarter] [nvarchar](255) NULL,
	[fiscal_period] [nvarchar](255) NULL,
	[id_rev_schd] [nvarchar](255) NULL,
	[ccv_por_value] [float] NULL,
	[acv_por_value] [float] NULL,
	[field_source] [nvarchar](255) NULL,
	[por_type] [nvarchar](255) NULL,
	[quota_value] [nvarchar](255) NULL,
	[role_quota] [nvarchar](255) NULL,
	[territory_quota] [nvarchar](255) NULL,
	[latest_annual_contact_value_year_1__c] [float] NULL,
	[latest_committed_contract_value__c] [float] NULL,
	[latest_booked_amount__c] [float] NULL,
	[latest_revschd_ccv_final] [float] NULL,
	[latest_revschd_acv_final] [float] NULL,
	[latest_revschd_booked_amount_final] [float] NULL,
	[latest_stagename] [nvarchar](255) NULL,
	[latest_closedate] [date] NULL,
	[latest_fiscal_quarter] [nvarchar](255) NULL,
	[latest_gate] [nvarchar](255) NULL,
	[latest_heatmap] [bit] NULL,
	[snapshot_type] [nvarchar](255) NULL,
	[snapshot_date] [date] NULL,
	[snapshot_fiscal_quarter] [nvarchar](255) NULL,
	[current_fiscal_period] [nvarchar](255) NULL,
	[isharddeleted] [bit] NULL,
	[strategic_alliance_flag] [bit] NULL,
	[latest_strategic_alliance_flag] [bit] NULL,
	[latest_theatre] [nvarchar](255) NULL,
	[latest_lob] [nvarchar](255) NULL,
	[latest_segment] [nvarchar](255) NULL,
	[latest_dell_emc_segment] [nvarchar](255) NULL,
	[opp_application_flag] [bit] NULL,
	[latest_opp_application_flag] [bit] NULL,
	[closedate_change_count] [int] NULL,
	[channel] [varchar](255) NULL,
	[opp_dell_technologies_role__c] [varchar](255) NULL,
	[latest_primary_partner_role__c] [nvarchar](255) NULL,
	[latest_channel] [varchar](255) NULL,
	[latest_dell_technologies_role__c] [varchar](255) NULL,
	[sales_channel] [varchar](255) NULL,
	[latest_sales_channel] [varchar](255) NULL,
	opp_ForecastCategory NVARCHAR(50) ,
	opp_forecast_alignment__c NVARCHAR(50) 

)

	CREATE NONCLUSTERED INDEX ix_pls1
	ON [dbo].[product_line_snapshot](snapshot_date,snapshot_type)

	CREATE INDEX ix_waterfall
ON Product_Line_Snapshot(Snapshot_type, opp_id, opp_stagename, opp_heat_map__c)
INCLUDE(revschd_ACV_final,
revschd_booked_amount_final,
latest_revschd_ACV_final,
latest_revschd_booked_amount_final)

	END
	
	
ALTER INDEX  ix_waterfall
ON  Product_Line_Snapshot
REBUILD

	IF(@run_time>='00:00:00' AND @run_time<'08:00:00')
	BEGIN
		DELETE FROM   Product_Line_Snapshot 
		WHERE Snapshot_Date<DATEADD(DD,-7,@today) AND Snapshot_type LIKE 'DAY%'

	END
	ELSE
	BEGIN

		DELETE FROM   Product_Line_Snapshot 
		WHERE Snapshot_Date<DATEADD(DD,-6,@today) AND Snapshot_type LIKE 'DAY%'

	END
	
	EXEC dbo.Prod_Daily_Auto_Backward @today, @run_time
	

	DELETE FROM   Product_Line_Snapshot WHERE Snapshot_Date<DATEADD(DD,-699,@today)

	EXEC dbo.Prod_Auto_Backward @Saturday

	--------------Latest Fields---------------------------
	
		UPDATE pls
	SET latest_annual_contact_value_year_1__c=pl.pl_annual_contact_value_year_1__c,
	latest_Committed_Contract_Value__c=pl.pl_Committed_Contract_Value__c,
	latest_booked_amount__c=pl.pl_booked_amount__c,
	latest_revschd_booked_amount_final=pl.revschd_booked_amount_final,
	latest_revschd_ccv_final=pl.revschd_ccv_final,
	latest_revschd_acv_final=pl.revschd_acv_final,
		latest_lob =pl.product_quant_practice_group__c
	FROM Product_Line_Snapshot pls LEFT JOIN 
	(SELECT * FROM Product_Line_Snapshot WHERE Snapshot_type='DAY 01'
	) pl ON pls.pl_Id=pl.pl_Id


	UPDATE pls
	SET 
	latest_stagename=pl.opp_stagename,
	latest_closedate=pl.opp_closedate,
	latest_fiscal_quarter=pl.opp_close_fiscal_quarter,
	latest_gate=pl.opp_gate__c,
	latest_heatmap=pl.opp_heat_map__c,
	 latest_strategic_alliance_flag =pl.strategic_alliance_flag,
 latest_theatre =pl.opp_theatre__c,
		latest_segment =pl.opp_segment__c,
		latest_dell_emc_segment =pl.acc_dell_emc_segment__c,
		latest_sales_channel=pl.sales_channel,
		latest_opp_application_flag=pl.opp_application_flag,
		latest_primary_partner_role__c=pl.opp_primary_partner_role__c ,
		latest_channel=pl.channel ,
		latest_dell_technologies_role__c =pl.opp_dell_technologies_role__c
	FROM Product_Line_Snapshot pls LEFT JOIN 
	(SELECT * FROM Product_Line_Snapshot WHERE Snapshot_type='DAY 01'
	) pl ON pls.opp_Id=pl.opp_Id


		UPDATE Product_Line_Snapshot
		SET Current_Fiscal_Period =(SELECT b.Fiscal_Period
		FROM FiscalQuarters b WHERE b.date=@today)

		
		UPDATE Product_Line_Snapshot
		SET latest_revschd_booked_amount_final=revschd_booked_amount_final,
		latest_stagename=opp_stagename,
		latest_fiscal_quarter=opp_close_fiscal_quarter,
		 latest_strategic_alliance_flag =strategic_alliance_flag,
		 latest_opp_application_flag=opp_application_flag,
		latest_primary_partner_role__c=opp_primary_partner_role__c ,
		latest_channel=channel ,
		latest_dell_technologies_role__c =opp_dell_technologies_role__c,
		latest_theatre =opp_theatre__c,
		latest_lob =product_quant_practice_group__c,
		latest_segment =opp_segment__c,
		latest_dell_emc_segment =acc_dell_emc_segment__c
		where field_source
		IN ('RolloverBookings','Debookings','Finance Adjustments')

		
	UPDATE  Product_Line_Snapshot
	SET isharddeleted =(SELECT TOP 1 * FROM (SELECT b.isharddeleted 
	FROM ProductLine b
	WHERE  a.pl_id=b.Id)sys)
	FROM Product_Line_Snapshot a

	UPDATE  Product_Line_Snapshot
	SET
	isharddeleted =0
	WHERE field_source 
	IN ('RolloverBookings','Debookings','Finance Adjustments')

	-------------------------------------------------------------
	SELECT  CAST(NULL AS NVARCHAR(255)) as [pl_id]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_name]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_product__c]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_service_line__c]
      ,CAST(NULL AS NVARCHAR(255)) as [pl_practice_line__c]
      ,  CAST(NULL AS FLOAT)  as [pl_booked_amount__c]
      ,  CAST(NULL AS FLOAT)  as [pl_annual_contact_value_year_1__c]
      ,  CAST(NULL AS FLOAT)  as [pl_committed_contract_value__c]
      ,b.[opp_id]
      ,[opp_closedate]
      ,[opp_ownerid]
      ,[opp_createddate]
      ,[opp_accountid]
      ,[opp_name]
      ,[opp_stagename]
      ,[opp_probability]
      ,[opp_type]
      ,[opp_leadsource]
      ,[opp_isclosed]
      ,[opp_iswon]
      ,[opp_gate__c]
      ,[opp_heat_map__c]
      ,[opp_primary_data_center__c]
      ,[opp_sales_channel__c]
      ,[opp_secondary_data_center__c]
      ,[opp_opportunity_number__c]
      ,[opp_sub_segment__c]
      ,[opp_emc_opportunity_number__c]
      ,[opp_lead_partner_type__c]
      ,[opp_lead_partner__c]
      ,[opp_opportunity_conversion__c]
      ,[opp_related_opportunity__c]
      ,[opp_related_product_amount__c]
      ,[opp_so_number__c]
      ,[opp_dell_technologies_business__c]
      ,[opp_opportunity_age__c]
      ,[opp_pardot_campaign__c]
      ,[opp_primary_partner_role__c]
      ,[acc_name]
      ,[acc_segment__c]
      ,[acc_dell_emc_segment__c]
      ,[product_name]
      ,[product_family]
      ,[user_id]
      ,[user_name]
      ,[user_division]
      ,[user_department]
      ,[user_email]
      ,[user_userroleid]
      ,[user_managerid]
      ,[user_forecastenabled]
      ,[ur_owner_role_name]
      , CAST(NULL AS FLOAT) as [revschd_committed_amount__c]
      , CAST(NULL AS FLOAT) as [revschd_projection__c]
      , CAST(NULL AS FLOAT) as [revschd_actual__c]
      , CAST(NULL AS FLOAT) as [revschd_forecast_amount__c]
      , CAST(NULL AS FLOAT) as [revschd_ccv_final]
      , CAST(NULL AS FLOAT) as [revschd_acv_final]
      , CAST(NULL AS FLOAT) as [revschd_booked_amount_final]
      ,[m1_role_name]
      ,[m2_role_name]
      ,[m3_role_name]
      ,[m4_role_name]
      ,[m5_role_name]
      ,[role_level]
      ,[hierarchy_global]
      ,[hierarchy_theatre]
      ,[hierarchy_segment]
      ,[hierarchy_division]
      ,[hierarchy_area]
      ,[user_employeenumber]
      ,[opp_country__c]
      ,[opp_theatre__c]
      , CAST(NULL AS NVARCHAR(255)) as [product_quant_practice_group__c]
      ,[opp_segment__c]
      ,[opp_close_fiscal_quarter]
      ,[fiscal_period]
      ,[id_rev_schd]
      ,[ccv_por_value]
      ,[acv_por_value]
      ,[field_source]
      ,[por_type]
      ,[quota_value]
      ,[role_quota]
      ,[territory_quota]
      ,[latest_annual_contact_value_year_1__c]
      ,[latest_committed_contract_value__c]
      ,[latest_booked_amount__c]
      ,[latest_revschd_ccv_final]
      ,[latest_revschd_acv_final]
      ,[latest_revschd_booked_amount_final]
      ,[latest_stagename]
      ,[latest_closedate]
      ,[latest_fiscal_quarter]
      ,[latest_gate]
      ,[latest_heatmap]
      ,b.[snapshot_type]
      ,b.[snapshot_date]
      ,[snapshot_fiscal_quarter]
      ,[current_fiscal_period]
      ,[isharddeleted]
      ,[strategic_alliance_flag]
      ,[latest_strategic_alliance_flag]
      ,[latest_theatre]
      ,[latest_lob]
      ,[latest_segment]
      ,[latest_dell_emc_segment]
      ,[opp_application_flag]
      ,[latest_opp_application_flag]
      ,[closedate_change_count]
      ,[channel]
      ,[opp_dell_technologies_role__c]
      ,[latest_primary_partner_role__c]
      ,[latest_channel]
      ,[latest_dell_technologies_role__c]
      ,[sales_channel]
      ,[latest_sales_channel],
	  opp_ForecastCategory , opp_forecast_alignment__c
	 INTO #opps_wo_pl FROM (
	SELECT 
	* FROM (SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=1 ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT Id FROM Opportunity where isharddeleted=0)
	GROUP BY snapshot_type, snapshot_date, opp_id) a EXCEPT
	(SELECT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where  field_Source ='SFDC' AND isharddeleted=0 ANd snapshot_type<='WEEK 13'
	GROUP BY snapshot_type, snapshot_date, opp_id)
	UNION ALL
	SELECT DISTINCT snapshot_type, snapshot_date, opp_id FROM Product_Line_Snapshot 
	where field_Source ='SFDC' AND isharddeleted IS NULL ANd snapshot_type<='WEEK 13'
	AND opp_Id IN (SELECT Id FROM Opportunity where isharddeleted=0)
	) a JOIN (SELECT *, ROW_NUMBER() OVER (PARTITION BY snapshot_Type, snapshot_date, opp_id
	ORDER BY pl_id) as Rk FROM Product_Line_Snapshot where (isharddeleted=1 OR isharddeleted IS NULL)) b
	ON a.snapshot_type=b.snapshot_type AND a.snapshot_date=b.snapshot_date
	AND a.opp_id=b.opp_id
	WHERE b.Rk=1 AND ISNULL(b.product_quant_practice_group__c,'a')<>'Managed Services'
				AND ISNULL(b.opp_type,'a') <> 'CSP-Sell Out'
	
	
	

	DROP TABLE IF  EXISTS Product_Line_Snapshot_Totals_With_Rollover

	(SELECT 
opp_theatre__c as theatre,
opp_segment__c as segment,
product_quant_practice_group__c as product,
opp_close_fiscal_quarter as fiscal_quarter,
opp_stagename as stagename,
opp_heat_map__c as heatmap,
acc_Dell_EMC_Segment__c as acc_dell_emc_segment__c,
strategic_alliance_flag as strategic_alliance_flag,
opp_application_flag as opp_application_flag,
channel as channel,
opp_dell_technologies_role__c as opp_dell_technologies_role__c,
sales_channel,
opp_primary_partner_role__c as opp_primary_partner_role__c,

opp_gate__c as gate__c,
sum(ISNULL(pl_booked_amount__c,0)) as pl_booked_amount__c,
sum(ISNULL(pl_annual_contact_value_year_1__c,0)) as pl_annual_contact_value_year_1__c,
sum(ISNULL(pl_Committed_Contract_Value__c,0)) as pl_Committed_Contract_Value__c,
sum(ISNULL(revschd_ccv_final,0)) as revschd_ccv_final,
sum(ISNULL(revschd_acv_final,0)) as revschd_acv_final,
sum(ISNULL(revschd_booked_amount_final,0)) as revschd_booked_amount_final,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
INTO Product_Line_Snapshot_Totals_With_Rollover
FROM  (SELECT * FROM Product_Line_Snapshot
		WHERE Field_Source <>'POR' and isharddeleted=0
				AND product_quant_practice_group__c<>'Managed Services'
				AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
				UNION ALL
		SELECT * FROM #opps_wo_pl) a
GROUP BY opp_theatre__c,
product_quant_practice_group__c,
opp_segment__c ,
opp_close_fiscal_quarter,
opp_stagename,
opp_heat_map__c,
acc_dell_emc_segment__c,
strategic_alliance_flag,
opp_application_flag,
channel ,
opp_dell_technologies_role__c ,
sales_channel,
opp_primary_partner_role__c,
opp_gate__c,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
) 


	DROP TABLE IF  EXISTS Product_Line_Snapshot_Totals

	(SELECT 
opp_theatre__c as theatre,
opp_segment__c as segment,
product_quant_practice_group__c as product,
opp_close_fiscal_quarter as fiscal_quarter,
opp_stagename as stagename,
opp_heat_map__c as heatmap,
acc_Dell_EMC_Segment__c as acc_dell_emc_segment__c,
strategic_alliance_flag as strategic_alliance_flag,
opp_application_flag as opp_application_flag,
channel as  channel,
opp_dell_technologies_role__c  as opp_dell_technologies_role__c,
sales_channel as sales_channel,
opp_primary_partner_role__c as opp_primary_partner_role__c,
opp_gate__c as gate__c,
sum(ISNULL(pl_booked_amount__c,0)) as pl_booked_amount__c,
sum(ISNULL(pl_annual_contact_value_year_1__c,0)) as pl_annual_contact_value_year_1__c,
sum(ISNULL(pl_Committed_Contract_Value__c,0)) as pl_Committed_Contract_Value__c,
sum(ISNULL(revschd_ccv_final,0)) as revschd_ccv_final,
sum(ISNULL(revschd_acv_final,0)) as revschd_acv_final,
sum(ISNULL(revschd_booked_amount_final,0)) as revschd_booked_amount_final,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
INTO Product_Line_Snapshot_Totals
FROM  (SELECT * FROM Product_Line_Snapshot
		WHERE Field_Source='SFDC' and isharddeleted=0
		AND product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		UNION ALL
		SELECT * FROM #opps_wo_pl) a
GROUP BY opp_theatre__c,
product_quant_practice_group__c,
opp_segment__c ,
opp_close_fiscal_quarter,
opp_stagename,
opp_heat_map__c,
acc_dell_emc_segment__c,
strategic_alliance_flag,
opp_application_flag,
channel ,
opp_dell_technologies_role__c ,
sales_channel,
opp_primary_partner_role__c,
opp_gate__c,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
) 

------------------------------------------------------------------

DROP TABLE IF  EXISTS Latest_PLS_Totals_wRollover


	(SELECT 
latest_theatre as theatre,
latest_segment as segment,
latest_lob as product,
opp_close_fiscal_quarter as fiscal_quarter,
opp_stagename as stagename,
opp_heat_map__c as heatmap,
latest_dell_emc_segment as acc_dell_emc_segment__c,
latest_strategic_alliance_flag as strategic_alliance_flag,
latest_opp_application_flag as opp_application_flag,
latest_primary_partner_role__c as opp_primary_partner_role__c,
		latest_channel as channel,
		latest_dell_technologies_role__c as opp_dell_technologies_role__c,
		latest_sales_channel as sales_channel,
opp_gate__c as gate__c,
sum(ISNULL(pl_booked_amount__c,0)) as pl_booked_amount__c,
sum(ISNULL(pl_annual_contact_value_year_1__c,0)) as pl_annual_contact_value_year_1__c,
sum(ISNULL(pl_Committed_Contract_Value__c,0)) as pl_Committed_Contract_Value__c,
sum(ISNULL(revschd_ccv_final,0)) as revschd_ccv_final,
sum(ISNULL(revschd_acv_final,0)) as revschd_acv_final,
sum(ISNULL(revschd_booked_amount_final,0)) as revschd_booked_amount_final,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
INTO Latest_PLS_Totals_wRollover
FROM  (SELECT * FROM Product_Line_Snapshot
		WHERE Field_Source <>'POR' and isharddeleted=0
				AND product_quant_practice_group__c<>'Managed Services'
				AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
				UNION ALL
		SELECT * FROM #opps_wo_pl) a
GROUP BY latest_theatre,
latest_lob,
latest_segment ,
opp_close_fiscal_quarter,
opp_stagename,
opp_heat_map__c,
latest_dell_emc_segment,
latest_strategic_alliance_flag,
latest_opp_application_flag,
latest_primary_partner_role__c,
		latest_channel ,
		latest_dell_technologies_role__c,
		latest_sales_channel,
opp_gate__c,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
) 


	DROP TABLE IF  EXISTS Latest_PLS_Totals 

	(SELECT 
latest_theatre as theatre,
latest_segment as segment,
latest_lob as product,
opp_close_fiscal_quarter as fiscal_quarter,
opp_stagename as stagename,
opp_heat_map__c as heatmap,
latest_dell_emc_segment as acc_dell_emc_segment__c,
latest_strategic_alliance_flag as strategic_alliance_flag,
latest_opp_application_flag as opp_application_flag,
latest_primary_partner_role__c as opp_primary_partner_role__c,
		latest_channel as channel,
		latest_dell_technologies_role__c as opp_dell_technologies_role__c,
		latest_sales_channel as sales_channel,
opp_gate__c as gate__c,
sum(ISNULL(pl_booked_amount__c,0)) as pl_booked_amount__c,
sum(ISNULL(pl_annual_contact_value_year_1__c,0)) as pl_annual_contact_value_year_1__c,
sum(ISNULL(pl_Committed_Contract_Value__c,0)) as pl_Committed_Contract_Value__c,
sum(ISNULL(revschd_ccv_final,0)) as revschd_ccv_final,
sum(ISNULL(revschd_acv_final,0)) as revschd_acv_final,
sum(ISNULL(revschd_booked_amount_final,0)) as revschd_booked_amount_final,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
INTO Latest_PLS_Totals
FROM  (SELECT * FROM Product_Line_Snapshot
		WHERE Field_Source='SFDC' and isharddeleted=0
		AND product_quant_practice_group__c<>'Managed Services'
		AND ISNULL(opp_type,'a') <> 'CSP-Sell Out'
		UNION ALL
		SELECT * FROM #opps_wo_pl) a
GROUP BY latest_theatre,
latest_lob,
latest_segment ,
opp_close_fiscal_quarter,
opp_stagename,
opp_heat_map__c,
latest_dell_emc_segment,
latest_strategic_alliance_flag,
latest_opp_application_flag,
latest_primary_partner_role__c,
latest_channel ,
latest_dell_technologies_role__c,
latest_sales_channel,
opp_gate__c,
snapshot_date,
snapshot_type,
snapshot_fiscal_quarter
) 


END--------------------------Proc End
/*

'


-------------------------24/01/2019

ALTER TABLE Product_Line_Snapshot
ADD  opp_forecast_alignment__c NVARCHAR(50) 
------------------------------------------------------------

		UPDATE pls
	SET channel=CASE  WHEN opp_leadsource='Dell Technologies' AND
opp_lead_partner__c IS NOT NULL THEN 'Dell Tech & Partner'
ELSE	
	CASE  WHEN opp_leadsource='Dell Technologies' THEN 'Dell Tech'
		WHEN opp_lead_partner__c IS NOT NULL THEN 'Partner'
		END END FROM Product_Line_Snapshot pls

		UPDATE pls
	SET opp_dell_technologies_role__c=ofh.dell_technologies_role__c FROM Product_Line_Snapshot pls 
	LEFT JOIN 
 Opportunity ofh
ON pls.opp_id=ofh.Id



DELETE FROM Product_Line_Snapshot
WHERE field_source <>'SFDC'


INSERT INTO Product_Line_Snapshot
(
pl_id, 
pl_name,
pl_product__c,
pl_service_line__c, 
pl_practice_line__c,
pl_booked_amount__c,
pl_annual_contact_value_year_1__c,
pl_committed_contract_value__c,
opp_id,
opp_closedate,
opp_ownerid,
opp_createddate,
opp_accountid,
opp_name,
opp_stagename,
opp_probability,
opp_type,
opp_leadsource,
opp_isclosed,
opp_iswon,
opp_gate__c,
opp_heat_map__c,
opp_primary_data_center__c,
opp_sales_channel__c,--19
opp_secondary_data_center__c,
opp_opportunity_number__c,
opp_sub_segment__c,
opp_emc_opportunity_number__c,
opp_lead_partner_type__c,
opp_lead_partner__c,
opp_opportunity_conversion__c,
opp_related_opportunity__c,
opp_related_product_amount__c,
opp_so_number__c,
opp_dell_technologies_business__c,
opp_opportunity_age__c,
opp_pardot_campaign__c,
opp_primary_partner_role__c,
opp_application_flag,
acc_name,
acc_segment__c,
acc_dell_emc_segment__c,
product_name, 
product_family,
user_id,
user_name,
user_division,
user_department,
user_email,--40
user_userroleid,


UPDATE Product_Line_Snapshot
		SET 
		opp_Name='Finance_Adj'
		where field_Source='Finance_Adj'
*/
	
