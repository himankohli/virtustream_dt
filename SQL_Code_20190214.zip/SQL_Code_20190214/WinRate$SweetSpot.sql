


  CREATE view [dbo].[v_WonLost_LTM] as 

  with 
 opp_close_history as (select opp_id,case when opp_stagename in ('99% Won (Closed/Won)','100% Booked (Closed/Won)') then opp_closedate else coalesce(opp_lost_date,opp_createddate) end as opp_close_date 
		From Opportunity_Header where opp_stagename 
		IN ('99% Won (Closed/Won)','100% Booked (Closed/Won)',
		'0% Lost (Closed/Lost)')),

opp_Multiple_LOB as
   (select * from (
  select a.opp_id,LOB,min(f1) over (partition by opp_id) as L1,f1 from
  (select distinct opp_id,product_quant_practice_group__c as LOB,
  case when   product_quant_practice_group__c='VEC' then 1
	when product_quant_practice_group__c= 'VSC'then 2
		when product_quant_practice_group__c='SW' then 3
			else 4 end as f1
   from product_line_snapshot  a   
  where ISNULL(a.opp_type,'a') <> 'CSP-Sell Out'
  AND a.opp_id in (
  select a.opp_id from  Product_Line_Snapshot a
  join opp_close_history och on a.opp_id=och.opp_id
 where ltrim(rtrim(opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)','0% Lost (Closed/Lost)')
 and snapshot_type= 'Day 01' and IsHardDeleted=0 and DATEDIFF(day,opp_close_date,getdate())<=730 and DATEDIFF(day,opp_close_date,getdate())<=730 and DATEDIFF(day,opp_close_date,getdate())>=0
 group by a.opp_id
 having count(distinct product_quant_practice_group__c)>1) 
and product_quant_practice_group__c is not null)a
)a where f1=l1),

New_Acc_Date as (
select oh.acc_name,min(a.opp_closedate) as New_AC_Dt  from Product_Line_Snapshot a
 left join  Opportunity_Header oh
on oh.opp_id=a.opp_id
where  snapshot_type= 'Day 01' and a.opp_id is not null  and a.IsHardDeleted=0 and ltrim(rtrim(a.opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)') 
 group by oh.acc_name)
 

 
 ,
 wonlost_ltm as (
select a.opp_id,oh.opp_opportunity_number__c,
oh.acc_name,
opp_theatre__c,
product_quant_practice_group__c as LOB,
a.opp_segment__c,
sum(pl_booked_amount__c) as Product_DealSize,
b.Opp_DealSize as  Opp_DealSize,case when b.Opp_DealSize< 100000
THEN '<$100K'
when b.Opp_DealSize>= 100000 and b.Opp_DealSize<250000
THEN '$100K-$250K'
when b.Opp_DealSize>= 250000 and b.Opp_DealSize<500000
THEN '$250K-$500K'
when b.Opp_DealSize>= 500000 and b.Opp_DealSize<1000000
THEN '$500K-$1M'
when b.Opp_DealSize>= 1000000 and b.Opp_DealSize<2500000
THEN '$1M-$2.5M'
when b.Opp_DealSize >= 2500000
THEN '>$2.5M'
END as Deal_Size_bucket,
a.opp_stagename,
case when ltrim(rtrim(a.opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)') then 1 else 0 end as IsWon,
case when ltrim(rtrim(a.opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)','0% Lost (Closed/Lost)') then 1 else 0 end as IsClosed,
case when datediff(day,a.opp_createddate,och.opp_close_date)>0  then datediff(day,a.opp_createddate,och.opp_close_date) else 0 end  as Opp_Age,
fq.fiscal_qtr as opp_close_fiscal_quarter,
left(fq.fiscal_qtr,4) as [Year(Opp_Close)],
right(fq.fiscal_qtr,2) as [Quarter(Opp_Close)],
oh.opp_competitor__c as Competitor,oh.acc_Vertical__c as Industry,
case when cast(och.opp_close_date as date)>cast(nad.New_AC_Dt as date) then 'N' else 'Y' end as New_Acc,
oh.lost_FROM_stage ,
case when DATEDIFF(day,och.opp_close_date,getdate())<=365 then 1 else 0 end as ltm_flag1
 from Product_Line_Snapshot a
left join (select  a.opp_id,sum(pl_booked_amount__c)  as Opp_DealSize from Product_Line_Snapshot a
join opp_close_history och on a.opp_id=och.opp_id
 where ltrim(rtrim(opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)','0% Lost (Closed/Lost)')
 and snapshot_type= 'Day 01' and IsHardDeleted=0 and DATEDIFF(day,opp_close_date,getdate())<=730 and DATEDIFF(day,opp_close_date,getdate())<=730 and DATEDIFF(day,opp_close_date,getdate())>=0
 group by  a.opp_id) b
 on a.opp_id=b.opp_id
 left join  opportunity_header oh
on oh.opp_id=a.opp_id
left join New_Acc_Date NAD
on a.acc_name=NAD.acc_name
join opp_close_history och on a.opp_id=och.opp_id 
join FiscalQuarters fq on cast(och.opp_close_date as date)=cast(fq.[date] as date)
where ltrim(rtrim(a.opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)','0% Lost (Closed/Lost)')
 and snapshot_type= 'Day 01' and a.opp_id is not null  and a.IsHardDeleted=0 and DATEDIFF(day,och.opp_close_date,getdate())<=730 and DATEDIFF(day,och.opp_close_date,getdate())<=730 and DATEDIFF(day,och.opp_close_date,getdate())>=0
 and a.opp_id not in (select distinct opp_id from opp_Multiple_LOB) and product_quant_practice_group__c is not null 
group by a.opp_id,oh.opp_opportunity_number__c,
opp_theatre__c,oh.opp_competitor__c,
product_quant_practice_group__c ,
a.opp_segment__c,a.opp_stagename,a.opp_createddate,och.opp_close_date,
b.Opp_DealSize,fq.fiscal_qtr,oh.acc_Vertical__c ,oh.lost_FROM_stage,
oh.acc_name,nad.New_AC_Dt

UNION ALL 

SELECT a.opp_id,oh.opp_opportunity_number__c,
oh.acc_name,
opp_theatre__c,
product_quant_practice_group__c as LOB,
a.opp_segment__c,
sum(pl_booked_amount__c) as Product_DealSize,
b.Opp_DealSize as  Opp_DealSize,case when b.Opp_DealSize< 100000
THEN '<$100K'
when b.Opp_DealSize>= 100000 and b.Opp_DealSize<250000
THEN '$100K-$250K'
when b.Opp_DealSize>= 250000 and b.Opp_DealSize<500000
THEN '$250K-$500K'
when b.Opp_DealSize>= 500000 and b.Opp_DealSize<1000000
THEN '$500K-$1M'
when b.Opp_DealSize>= 1000000 and b.Opp_DealSize<2500000
THEN '$1M-$2.5M'
when b.Opp_DealSize >= 2500000
THEN '>$2.5M'
END as Deal_Size_bucket,
a.opp_stagename,
case when ltrim(rtrim(a.opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)') then 1 else 0 end as IsWon,
case when ltrim(rtrim(a.opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)','0% Lost (Closed/Lost)') then 1 else 0 end as IsClosed,
case when datediff(day,a.opp_createddate,och.opp_close_date)>0  then datediff(day,a.opp_createddate,och.opp_close_date) else 0 end  as Opp_Age,
fq.fiscal_qtr as opp_close_fiscal_quarter,
left(fq.fiscal_qtr,4) as [Year(Opp_Close)],
right(fq.fiscal_qtr,2) as [Quarter(Opp_Close)],
oh.opp_competitor__c as Competitor,oh.acc_Vertical__c as Industry,
case when cast(och.opp_close_date as date)>cast(nad.New_AC_Dt as date) then 'N' else 'Y' end as New_Acc,
oh.lost_FROM_stage ,
case when DATEDIFF(day,och.opp_close_date,getdate())<=365 then 1 else 0 end as ltm_flag1
 from Product_Line_Snapshot a
left join (select  a.opp_id,sum(pl_booked_amount__c)  as Opp_DealSize from Product_Line_Snapshot a
JOIN opp_close_history och on a.opp_id=och.opp_id

 where ltrim(rtrim(opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)','0% Lost (Closed/Lost)')
 and snapshot_type= 'Day 01' and IsHardDeleted=0 and DATEDIFF(day,opp_close_date,getdate())<=730 and DATEDIFF(day,opp_close_date,getdate())<=730 and DATEDIFF(day,opp_close_date,getdate())>=0 
 group by  a.opp_id) b
 on a.opp_id=b.opp_id
 left join  opportunity_header oh
on oh.opp_id=a.opp_id

join opp_Multiple_LOB oml
on a.opp_id=oml.opp_id and oml.lob=a.product_quant_practice_group__c
left join New_Acc_Date NAD
on a.acc_name=NAD.acc_name
join opp_close_history och on a.opp_id=och.opp_id 
join FiscalQuarters fq on cast(och.opp_close_date as date)=cast(fq.[date] as date)
where ltrim(rtrim(a.opp_stagename)) in ('99% Won (Closed/Won)','100% Booked (Closed/Won)','0% Lost (Closed/Lost)')
 and snapshot_type= 'Day 01' and a.opp_id is not null  and a.IsHardDeleted=0 and DATEDIFF(day,och.opp_close_date,getdate())<=730 and DATEDIFF(day,och.opp_close_date,getdate())<=730 and DATEDIFF(day,och.opp_close_date,getdate())>=0
 and a.opp_id  in (select distinct opp_id FROM opp_Multiple_LOB)
 
group by a.opp_id,oh.opp_opportunity_number__c,
opp_theatre__c,oh.opp_competitor__c,
product_quant_practice_group__c ,
a.opp_segment__c,a.opp_stagename,a.opp_createddate,och.opp_close_date,b.Opp_DealSize,fq.fiscal_qtr,oh.acc_Vertical__c ,oh.lost_FROM_stage,oh.acc_name,nad.New_AC_Dt
)

select distinct *,max(ltm_flag1) over(partition by opp_close_fiscal_quarter) as LTM_Flag from wonlost_ltm

