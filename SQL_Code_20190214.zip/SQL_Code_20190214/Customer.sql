/**

Calculates UpSell, CrossSell, and NewLogo based on distinct combinations
of Theatre, segment, product, and Quarter.

**/
ALTER PROCEDURE [dbo].[sp_Customer]
AS
BEGIN
	DROP TABLE IF EXISTS u_Customer
	CREATE TABLE u_Customer
	(
		Quarter VARCHAR(255),
		Theatre VARCHAR(255),
		Segment VARCHAR(255),
		Product VARCHAR(255),
		Type  VARCHAR(255),
		Metric FLOAT,
		RowType  VARCHAR(255),
		Current_Fiscal_Period VARCHAR(20)
	)

	DECLARE @today DATE=(SELECT GETDATE())
	DECLARE @current_quarter VARCHAR(10)=(SELECT fiscal_qtr 
	FROM FiscalQuarters  WHERE date=@today)
	DECLARE @current_period VARCHAR(20)=(SELECT Fiscal_Period 
	FROM FiscalQuarters  WHERE date=@today)
	

	DROP TABLE IF EXISTS #fiscal_quarter_rank
SELECT [fiscal_qtr] , row_number() over (order by [fiscal_qtr]) as rank
INTO #fiscal_quarter_rank  
FROM [dbo].[FiscalQuarters]
		GROUP BY [fiscal_qtr]


		
	DECLARE @start_quarter VARCHAR(10)=(SELECT fiscal_qtr from #fiscal_quarter_rank
	WHERE rank=(SELECT rank-10 FROM #fiscal_quarter_rank WHERE fiscal_qtr=(SELECT DISTINCT [fiscal_qtr] 
	FROM [dbo].[FiscalQuarters] WHERE [date]=@today)))

	DECLARE @end_quarter VARCHAR(10)=(SELECT fiscal_qtr from #fiscal_quarter_rank
	WHERE rank=(SELECT rank+9 from #fiscal_quarter_rank WHERE fiscal_qtr=(SELECT DISTINCT [fiscal_qtr] 
	FROM [dbo].[FiscalQuarters] WHERE [date]=@today)))


	--------------------------------------------------------------------
	DROP TABLE IF EXISTS #filter_option
	SELECT *, ROW_NUMBER() OVER (ORDER BY Quarter) as rk 
	INTO #filter_option 
	FROM
	(SELECT fiscal_qtr as [Quarter], CAST(MIN(date) as date) as [start_date], 
CASE WHEN fiscal_qtr=@current_quarter
THEN @today ELSE CAST(MAX(date) as date) END as end_date FROM FiscalQuarters
	WHERE fiscal_qtr BETWEEN @start_quarter AND @end_quarter
	GROUP BY fiscal_qtr) a
	CROSS JOIN
	
	(SELECT DISTINCT opp_theater__c as Theatre
	FROM Opportunity_Header WHERE opp_theater__c IS NOT NULL
	UNION
	SELECT 'Global') b
	CROSS JOIN
	(SELECT DISTINCT opp_segment__c as Segment
	FROM Opportunity_Header WHERE opp_segment__c IS NOT NULL
	UNION
	SELECT 'Global') c CROSS JOIN 

	(SELECT DISTINCT quant_practice_group__c as Product FROM Product2
	WHERE quant_practice_group__c<>'Managed Services'
	UNION SELECT 'Global') d
	
	
	
	DECLARE @loop INT=(SELECT COUNT(*) FROM #filter_option)
	DECLARE @end_date DATE
	DECLARE @start_date DATE
	DECLARE @qtr VARCHAR(20)
	DECLARE @theatre VARCHAR(20)
	DECLARE @segment VARCHAR(20)
	DECLARE @product VARCHAR(50)

	WHILE (@loop>0)
	BEGIN 
	SET @end_date=(SELECT end_date FROM #filter_option
	where rk=@loop)
	SET @start_date=(SELECT [start_date] FROM #filter_option
	where rk=@loop)
	SET @qtr=(SELECT Quarter FROM #filter_option
	where rk=@loop)
	SET @theatre=(SELECT Theatre FROM #filter_option
	where rk=@loop)
	SET @segment=(SELECT Segment FROM #filter_option
	where rk=@loop)
	SET @product=(SELECT Product FROM #filter_option
	where rk=@loop)

	DROP TABLE IF EXISTS #Account_Rev

	SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		INTO #Account_Rev
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
		LEFT JOIN Product2 p ON pl.product__c=p.id
		LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%'
	OR o.opp_StageName LIKE '100%'
	OR o.opp_StageName LIKE (CASE WHEN @qtr>@current_quarter THEN '90%' END)
	OR o.opp_StageName LIKE (CASE WHEN  @qtr>@current_quarter THEN '75%' END)
	OR o.opp_StageName LIKE (CASE WHEN  @qtr>@current_quarter THEN '60%' END)
	OR o.opp_StageName LIKE (CASE WHEN  @qtr>@current_quarter THEN '40%' END)
	OR o.opp_StageName LIKE (CASE WHEN  @qtr>@current_quarter THEN '20%' END))
		AND rev.valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services' AND valid_flag=1
		AND CAST(o.opp_CloseDate AS DATE)<=@end_date
		AND o.opp_theater__c=(CASE WHEN @theatre='Global'
		THEN o.opp_theater__c ELSE @theatre END)
		AND o.opp_segment__c=(CASE WHEN @segment='Global'
		THEN o.opp_segment__c ELSE @segment END)
		AND p.quant_practice_group__c=(CASE WHEN @product='Global'
		THEN p.quant_practice_group__c ELSE @product END)
		GROUP BY o.acc_id
		
		
		
		DROP TABLE IF EXISTS #Opportunity_LOB
		
		SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
	pl_Booked_Amount__c as Booked_Amount_with_Override
	INTO #Opportunity_LOB
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	SUM(revschd_booked_amount_final) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%'
	OR o.opp_StageName LIKE '100%'
	OR o.opp_StageName LIKE (CASE WHEN @qtr>@current_quarter THEN '90%' END)
	OR o.opp_StageName LIKE (CASE WHEN @qtr>@current_quarter THEN '75%' END)
	OR o.opp_StageName LIKE (CASE WHEN  @qtr>@current_quarter THEN '60%' END)
	OR o.opp_StageName LIKE (CASE WHEN  @qtr>@current_quarter THEN '40%' END)
	OR o.opp_StageName LIKE (CASE WHEN  @qtr>@current_quarter THEN '20%' END)) 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=@end_date
		AND  o.opp_theater__c=(CASE WHEN @theatre='Global'
		THEN o.opp_theater__c ELSE @theatre END)
		AND o.opp_segment__c=(CASE WHEN @segment='Global'
		THEN o.opp_segment__c ELSE @segment END)
		AND p.quant_practice_group__c=(CASE WHEN @product='Global'
		THEN p.quant_practice_group__c ELSE @product END)
		
	
	

		INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,
	 'Churned Cust', (SELECT COUNT(DISTINCT AccountId) FROM  #Account_Rev 
	 where (SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)<=@end_date
	AND 
	(SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)>=@start_date)
	 , 'Cust Type', @current_period)

	INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,'New Logo', 
	 (SELECT COUNT(DISTINCT AccountId) FROM  #Account_Rev 
	 where Fiscal_Quarter=@qtr), 'Cust Type', @current_period)

	 
	INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,'Existing Cust',   
	(SELECT COUNT(DISTINCT AccountId) 
	  FROM  #Account_Rev where @end_date < (SELECT DISTINCT  End_Date__c FROM Fiscal_Period__c WHERE Mid_of_Month__c=Revenue_End_Date)
	AND Opp_CloseDate<=@end_date
	AND AccountId NOT IN (SELECT AccountId FROM  #Account_Rev 
	 where Fiscal_Quarter=@qtr)), 
	'Cust Type', @current_period)

	
	INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,'NewLogoByBooking', 
	 (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM #Opportunity_LOB WHERE acc_Id IN (SELECT AccountId FROM  #Account_Rev 
	  where Fiscal_Quarter=@qtr))/
	 NULLIF((SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM #Opportunity_LOB
	 where opp_close_fiscal_quarter=@qtr),0), 'NewLogoByBooking', @current_period)


	 
	INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,
	'UpSell_Val', (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) 
	FROM #Opportunity_LOB b where b.acc_Id IN 
	(SELECT AccountId FROM #Account_Rev where Fiscal_Quarter<>@qtr)
	AND b.pl_Id IN (SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM #Opportunity_LOB o 
	where  o.opp_close_fiscal_quarter=@qtr  AND 
	o.pl_Id=b.pl_Id) prod where prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM #Opportunity_LOB o 
	where  o.opp_close_fiscal_quarter<@qtr  AND 
	o.acc_Id=b.acc_Id)))/ NULLIF((SELECT 
	SUM(ISNULL(Booked_Amount_with_Override,0)) FROM #Opportunity_LOB 
	where opp_close_fiscal_quarter=@qtr),0), 'UpSell_Val', @current_period)


	INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,
	 'CrossSell_Val', (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) 
	 FROM #Opportunity_LOB b where b.acc_Id IN 
	(SELECT  AccountId FROM #Account_Rev where Fiscal_Quarter<>@qtr)
	AND b.pl_Id IN (SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM #Opportunity_LOB o 
	where  o.opp_close_fiscal_quarter=@qtr  AND o.pl_Id=b.pl_Id) prod
	where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM #Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@qtr  AND 
				o.acc_Id=b.acc_Id)))/
	NULLIF((SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM #Opportunity_LOB where opp_close_fiscal_quarter=@qtr),0),
	 'CrossSell_Val', @current_period)

	INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,
	  'UpSell_Cnt', 
	 (SELECT COUNT(DISTINCT AccountId) FROM #Account_Rev a where 
	  Fiscal_Quarter<>@qtr AND AccountId IN 
	  (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM #Opportunity_LOB o where  o.opp_close_fiscal_quarter=@qtr  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM #Opportunity_LOB o where  o.opp_close_fiscal_quarter<@qtr AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt', @current_period)


	INSERT INTO u_Customer values
	(@qtr , @theatre, @segment, @product,'CrossSell_Cnt', 
	  (SELECT COUNT(DISTINCT AccountId) FROM #Account_Rev a where 
	  Fiscal_Quarter<>@qtr AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM #Opportunity_LOB o where  o.opp_close_fiscal_quarter=@qtr  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM #Opportunity_LOB o where  o.opp_close_fiscal_quarter<@qtr  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'CrossSell_Cnt', @current_period)


	SET @loop=@loop-1
	END
	END
	/*

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA', 
	 (SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'CrossSell_Cnt'
	)


	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
	
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='APJ'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='APJ'
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	'APJ', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	 'APJ',

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-4 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'CrossSell_Cnt'
	)



	--------------------------------------------------------------------------------------------------------


	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(rev.revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		 AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)



	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	
	)
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'Churned Cust', ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
		 (SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)<=(SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND 
	(SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)>=(SELECT MIN(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 'Cust Type'
	)

	
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'New Logo',  
	 ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev 
	 where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))
	 ), 'Cust Type'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'Existing Cust', 
	  (SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
	   (SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))) < (SELECT DISTINCT  End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)
	AND Opp_CloseDate<=(SELECT MAX(CAST(date AS DATE))
	 FROM FiscalQuarters where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 
	   'Cust Type'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'NewLogoByBooking',
	  (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB WHERE acc_Id IN
	  (SELECT AccountId FROM  @Account_Rev 
	  where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))))/
	 (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
 
	 , 'NewLogoByBooking')

 
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Global',  
  
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'Global', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'CrossSell_Val'
	)


 
	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='Americas'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='Americas' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Americas',  
  
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'Americas', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'CrossSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'Americas', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))
 
	 AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'Americas',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='EMEA'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='EMEA' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA',  

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter) ) AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'EMEA', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'CrossSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'EMEA', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'EMEA',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='APJ'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='APJ' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ',  
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'APJ', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'CrossSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'APJ',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-3 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)

	--------------------------------------------------------------------------------------------------------


	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)
	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	
	)
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Churned Cust',  ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
		 (SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)<=(SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND 
	(SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)>=(SELECT MIN(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 'Cust Type'
	)

	
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'New Logo', 
	 ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev 
	 where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))
	 ),
	  'Cust Type'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'Existing Cust', (SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
	   (SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))) < (SELECT DISTINCT  End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)
	AND Opp_CloseDate<=(SELECT MAX(CAST(date AS DATE))
	 FROM FiscalQuarters where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 
	   'Cust Type'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'NewLogoByBooking',  
	   (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB WHERE acc_Id IN
	  (SELECT AccountId FROM  @Account_Rev 
	  where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))))/
	 (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'NewLogoByBooking'

	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Global', 
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
						(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	 'Global', 
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,

		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='Americas'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='Americas' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Americas', 
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
						(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	 'Americas', 
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'Americas', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))
 
	  AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'Americas', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='EMEA'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='EMEA' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA', 
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	 'EMEA', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'EMEA', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'EMEA', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='APJ'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='APJ' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	 'APJ', 
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	 'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)

	--------------------------------------------------------------------------------------------------------



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'

		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)

 
 

	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)),
	  'Churned Cust', 
		( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
		 (SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)<=(SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND 
	(SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)>=(SELECT MIN(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))))

	 , 'Cust Type'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'New Logo',
	 ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev 
	 where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))
	 ),
	  'Cust Type'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Existing Cust', (SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
	   (SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))) < (SELECT DISTINCT  End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)
	AND Opp_CloseDate<=(SELECT MAX(CAST(date AS DATE))
	 FROM FiscalQuarters where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 
	  'Cust Type'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'NewLogoByBooking', 
	   (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB WHERE acc_Id IN
	  (SELECT AccountId FROM  @Account_Rev 
	  where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))))/
	 (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'NewLogoByBooking'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Global',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 
	 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Global', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter) ) AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 
	 'CrossSell_Val'
	)


	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		AND p.quant_practice_group__c<>'Managed Services'
		   AND valid_flag=1
		AND o.opp_Theater__c='Americas'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='Americas'
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Americas',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Americas', 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter) ) AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/
				(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'Americas', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Americas', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,

		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='EMEA'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='EMEA'
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA', 
  
  
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter) ) AND 
					o.pl_Id=b.pl_Id
				)
				prod
				where prod.LOB  NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'EMEA', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA', 
	 (SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)


	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND o.opp_Theater__c='APJ'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)

	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='APJ' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ',

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ', 
  
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank-1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)) , 'CrossSell_Cnt'
	)


	--------------------------------------------------------------------------------------------------------



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		 FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		    AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
	
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
		GROUP BY o.acc_id
	)


		DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
	)
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'Churned Cust', 

	 ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where  (SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)<@today
	AND 
	(SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)>=(SELECT MIN(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=@current_quarter)), 
	'Cust Type'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter , 
		 'New Logo', 
		( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev 
		where Fiscal_Quarter=@current_quarter
	 ), 'Cust Type'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter, 'Existing Cust', 
		 (SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev 
		 where @today <= (SELECT DISTINCT  End_Date__c 
		 FROM Fiscal_Period__c WHERE Mid_of_Month__c=Revenue_End_Date))
	, 'Cust Type'
	)
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,  'NewLogoByBooking', 
	 (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB WHERE acc_Id IN
	  (SELECT AccountId FROM  @Account_Rev 
	  where Fiscal_Quarter=@current_quarter))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter)
	 , 'NewLogoByBooking'
)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'Global',
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'Global',
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'CrossSell_Val'
	)

	DELETE FROM @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		 FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services' AND o.opp_Theater__c='Americas'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
		GROUP BY o.acc_id
	)


		DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='Americas' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'Americas',
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'Americas',

 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
			(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'CrossSell_Val'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter , 'Americas',
  
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>@current_quarter   AND AccountId IN
	(CASE WHEN (SELECT MAX(prod.LOB) FROM
		 (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=@current_quarter  AND 
		o.acc_id=a.AccountId) prod
		where  prod.LOB IN
	   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<@current_quarter  AND 
		o.acc_id=a.AccountId))
		IS NOT NULL
		THEN
		a.AccountId END
		)),
	  'UpSell_Cnt'
	
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'Americas',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>@current_quarter  AND AccountId IN
	(CASE WHEN (SELECT MAX(prod.LOB) FROM
		 (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=@current_quarter  AND 
		o.acc_id=a.AccountId) prod
		where  prod.LOB NOT IN
	   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<@current_quarter  AND 
		o.acc_id=a.AccountId))
		IS NOT NULL
		THEN
		a.AccountId END
		)), 'CrossSell_Cnt' 
	
	)

	DELETE FROM @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		 FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services' AND o.opp_Theater__c='EMEA'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
		GROUP BY o.acc_id
	)


		DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='EMEA' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'EMEA',
 
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'EMEA',

 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'CrossSell_Val'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter , 'EMEA',
  
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>@current_quarter   AND AccountId IN
	(CASE WHEN (SELECT MAX(prod.LOB) FROM
		 (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=@current_quarter  AND 
		o.acc_id=a.AccountId) prod
		where  prod.LOB IN
	   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<@current_quarter  AND 
		o.acc_id=a.AccountId))
		IS NOT NULL
		THEN
		a.AccountId END
		)),
	  'UpSell_Cnt'
	
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'EMEA',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>@current_quarter   AND AccountId IN
	(CASE WHEN (SELECT MAX(prod.LOB) FROM
		 (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=@current_quarter  AND 
		o.acc_id=a.AccountId) prod
		where  prod.LOB NOT IN
	   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<@current_quarter  AND 
		o.acc_id=a.AccountId))
		IS NOT NULL
		THEN
		a.AccountId END
		)), 'CrossSell_Cnt' 
	
	)


	DELETE FROM @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		 FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE (o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%')
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services' AND o.opp_Theater__c='APJ'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
		GROUP BY o.acc_id
	)


		DELETE FROM @Opportunity_LOB

	INSERT INTO @Opportunity_LOB
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where 
		(o.opp_StageName LIKE '99%' OR o.opp_StageName LIKE '100%') AND o.opp_Theater__c='APJ' 
		AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=@current_quarter)
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'APJ',
 

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'UpSell_Val'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'APJ',

	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB b 
	  where b.acc_Id IN 
					(SELECT DISTINCT AccountId FROM @Account_Rev a where  Fiscal_Quarter<>@current_quarter)
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB o 
				 where  o.opp_close_fiscal_quarter=@current_quarter  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o 
			   where  o.opp_close_fiscal_quarter<@current_quarter  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB
	 where opp_close_fiscal_quarter=@current_quarter), 'CrossSell_Val'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter , 'APJ',
  
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>@current_quarter   AND AccountId IN
	(CASE WHEN (SELECT MAX(prod.LOB) FROM
		 (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=@current_quarter  AND 
		o.acc_id=a.AccountId) prod
		where  prod.LOB IN
	   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<@current_quarter  AND 
		o.acc_id=a.AccountId))
		IS NOT NULL
		THEN
		a.AccountId END
		)),
	  'UpSell_Cnt'
	
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	@current_quarter ,'APJ',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>@current_quarter  
  
	  AND AccountId IN
	(CASE WHEN (SELECT MAX(prod.LOB) FROM
		 (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter=@current_quarter  AND 
		o.acc_id=a.AccountId) prod
		where  prod.LOB NOT IN
	   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB o where  o.opp_close_fiscal_quarter<@current_quarter  AND 
		o.acc_id=a.AccountId))
		IS NOT NULL
		THEN
		a.AccountId END
		)), 'CrossSell_Cnt' 
	
	)

	--------------------------------------------------------------------------------------------------------

	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final

	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE o.opp_StageName NOT LIKE '0%' 
		AND p.quant_practice_group__c<>'Managed Services'
		AND valid_flag=1
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)

	DELETE FROM @Opportunity_LOB_pipeline

	INSERT INTO @Opportunity_LOB_pipeline
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where o.opp_StageName  NOT LIKE '0%' 
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Churned Cust', 
	   ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
		 (SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)<=(SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND 
	(SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)>=(SELECT MIN(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 
	 'Cust Type'
	)

	
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'New Logo',
	  ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev 
	 where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))
	
	 ), 'Cust Type'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'Existing Cust', 
	  (SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
	   (SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))) < (SELECT DISTINCT  End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)
	AND Opp_CloseDate<=(SELECT MAX(CAST(date AS DATE))
	 FROM FiscalQuarters where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))),  
	  'Cust Type'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'NewLogoByBooking', 
	   (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline WHERE acc_Id IN
	  (SELECT AccountId FROM  @Account_Rev 
	  where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'NewLogoByBooking'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'Global',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
						(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'Global',
  
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
						(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final

	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE o.opp_StageName NOT LIKE '0%'   
		AND valid_flag=1 
		AND p.quant_practice_group__c<>'Managed Services' AND o.opp_Theater__c='Americas'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)





	DELETE FROM @Opportunity_LOB_pipeline

	INSERT INTO @Opportunity_LOB_pipeline
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where o.opp_StageName  NOT LIKE '0%'  AND o.opp_Theater__c='Americas' 
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'Americas',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
						(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'Americas',
  
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
						(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Americas', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Americas',
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'CrossSell_Cnt'
	)



	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final

	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,

		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE o.opp_StageName NOT LIKE '0%' 
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services' AND o.opp_Theater__c='EMEA'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)





	DELETE FROM @Opportunity_LOB_pipeline

	INSERT INTO @Opportunity_LOB_pipeline
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where o.opp_StageName  NOT LIKE '0%'  AND o.opp_Theater__c='EMEA' 
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'EMEA',
  
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
						(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'EMEA',
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
							(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB)
	  FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'EMEA', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'CrossSell_Cnt'
	)


	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,
		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final

	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,

		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE o.opp_StageName NOT LIKE '0%'    
		AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services' AND o.opp_Theater__c='APJ'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)


	DELETE FROM @Opportunity_LOB_pipeline

	INSERT INTO @Opportunity_LOB_pipeline
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where o.opp_StageName  NOT LIKE '0%'  AND o.opp_Theater__c='APJ' 
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'APJ',
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
							(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	  'APJ',
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
							(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)

	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'APJ', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB NOT IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+1 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'CrossSell_Cnt'
	)

	--------------------------------------------------------------------------------------------------------




	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,

		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final
	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE o.opp_StageName NOT LIKE '0%'  AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)




	DELETE FROM @Opportunity_LOB_pipeline
	INSERT INTO @Opportunity_LOB_pipeline
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o 
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where o.opp_StageName  NOT LIKE '0%' 
		 AND  p.quant_practice_group__c<>'Managed Services'
		 AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	
	)
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	  'Churned Cust', 
	   ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
		 (SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)<=(SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND 
	(SELECT DISTINCT End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)>=(SELECT MIN(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 
	  'Cust Type'
	)

	
	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'New Logo', 
	  ( SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev 
	 where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))
	 ), 'Cust Type'
	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'Existing Cust',
	(SELECT COUNT(DISTINCT AccountId) FROM  @Account_Rev where 
	   (SELECT MAX(CAST(date AS DATE)) FROM FiscalQuarters 
	where fiscal_qtr=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))) < (SELECT DISTINCT  End_Date__c FROM Fiscal_Period__c 
	WHERE Mid_of_Month__c=Revenue_End_Date)
	AND Opp_CloseDate<=(SELECT MAX(CAST(date AS DATE))
	 FROM FiscalQuarters where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))), 
	  'Cust Type'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,

	  'NewLogoByBooking', 
	   (SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline WHERE acc_Id IN
	  (SELECT AccountId FROM  @Account_Rev 
	  where Fiscal_Quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter)))
	 , 'NewLogoByBooking'
	)


	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	 'Global',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
							(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)




	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	 'Global',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'

	)


	DELETE FROM  @Account_Rev

	INSERT INTO @Account_Rev
	(
		AccountId,
		Revenue_Start_Date,
		Revenue_End_Date,

		Fiscal_Quarter,
		Opp_CloseDate,
		Revschd_booked_amount_final

	)
	(
		SELECT o.acc_id as AccountId, 
		MIN(CAST(rev.Period__c AS DATE)) as Revenue_Start_Date,
		MAX(CAST(rev.Period__c AS DATE)) as Revenue_End_Date,
	
		MIN(o.opp_close_fiscal_quarter) as Fiscal_Quarter,
		MIN(CAST(o.Opp_CloseDate AS DATE)) as Opp_CloseDate,
		SUM(ISNULL(revschd_booked_amount_final,0)) as Revschd_booked_amount_final
		FROM Opportunity_Header o
		LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN Revenue_Schedule_Detail rev ON pl.Id=rev.pl_id
		WHERE o.opp_StageName NOT LIKE '0%' 
		   AND valid_flag=1
		AND p.quant_practice_group__c<>'Managed Services' AND o.opp_Theater__c='Americas'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
		GROUP BY o.acc_id
	)





	DELETE FROM @Opportunity_LOB_pipeline

	INSERT INTO @Opportunity_LOB_pipeline
	(LOB, opp_close_fiscal_quarter, acc_Id, pl_Id,Booked_Amount_with_Override)
	(SELECT  DISTINCT p.quant_practice_group__c as LOB, o.opp_close_fiscal_quarter , o.acc_Id, rev.pl_Id,
		pl_Booked_Amount__c as Booked_Amount_with_Override
	FROM Opportunity_Header o
	LEFT JOIN ProductLine pl ON o.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT pl_id, MAX(pl_opportunity__c) as pl_opportunity__c,
	MAX(product_quant_practice_group__c) as product_quant_practice_group__c,
	 MAX(pl_Booked_Amount_Override__c) as pl_Booked_Amount_Override__c,
	MAX(pl_Booked_Amount__c) as pl_Booked_Amount__c
	 FROM Revenue_Schedule_Detail where  valid_flag=1
	 GROUP BY pl_Id) rev
	ON pl.id=rev.pl_id
		 where o.opp_StageName  NOT LIKE '0%'  AND o.opp_Theater__c='Americas' 
		 AND  p.quant_practice_group__c<>'Managed Services'
		AND CAST(o.opp_CloseDate AS DATE)<=(SELECT CAST(MAX(date) AS DATE) FROM FiscalQuarters
		where fiscal_qtr=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))

	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	 'Americas',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
							(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'UpSell_Val'
	)




	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
	 'Americas',
 
	 (SELECT SUM(ISNULL(b.Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline b 
	  where b.acc_Id IN 
				(SELECT DISTINCT AccountId FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)))
	AND b.pl_Id IN
	(SELECT DISTINCT prod.pl_Id FROM
	 (SELECT DISTINCT  o.pl_Id, o.LOB  FROM @Opportunity_LOB_pipeline o 
				 where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
					o.pl_Id=b.pl_Id
				) 
				prod
				where prod.LOB NOT IN
			   (SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o 
			   where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
				where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND 
				o.acc_Id=b.acc_Id)))/(SELECT SUM(ISNULL(Booked_Amount_with_Override,0)) FROM @Opportunity_LOB_pipeline
	 where opp_close_fiscal_quarter=(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank 
	 WHERE fiscal_qtr=@current_quarter))), 'CrossSell_Val'

	)



	INSERT INTO u_Customer
	(Quarter ,  Type, Metric , RowType )values
	(
	(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) ,
 
	 'Americas', 
	(SELECT COUNT(DISTINCT AccountId) FROM @Account_Rev a where 
	  Fiscal_Quarter<>(SELECT DISTINCT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter)) AND
	 AccountId IN (CASE WHEN (SELECT MAX(prod.LOB) FROM
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter=(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId) prod
	where  prod.LOB IN
	(SELECT DISTINCT  o.LOB  FROM @Opportunity_LOB_pipeline o where  o.opp_close_fiscal_quarter<(SELECT fiscal_qtr FROM #fiscal_quarter_rank
	 where rank=(SELECT rank+2 FROM #fiscal_quarter_rank WHERE fiscal_qtr=@current_quarter))  AND o.acc_id=a.AccountId))
	IS NOT NULL THEN a.AccountId END)), 'UpSell_Cnt'
	)

	*/


