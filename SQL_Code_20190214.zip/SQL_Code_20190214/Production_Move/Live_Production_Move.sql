ALTER PROCEDURE Live_Prod_move
AS
BEGIN
SET NOCOUNT ON

DECLARE @pass INT

	SELECT @pass=COUNT(*)  FROM Live_Staging.dbo.u_audit_log WHERE  
	Live_Staging.dbo.u_audit_log.Import_ts > 
	(SELECT DATEADD(HH, -5, GETDATE())) AND 
	Live_Staging.dbo.u_audit_log .Object_Name = 'P2 Execution Completed'

	IF(@pass>0)
	BEGIN
DROP TABLE IF EXISTS Live_Production.dbo.FiscalQuarters
SELECT * INTO Live_Production.dbo.FiscalQuarters 
FROM Live_Staging.dbo.FiscalQuarters

DROP TABLE  IF EXISTS Live_Production.dbo.Revenue_Schedule_Snapshot 
SELECT * INTO Live_Production.dbo.Revenue_Schedule_Snapshot 
FROM Live_Staging.dbo.Revenue_Schedule_Snapshot

DROP TABLE IF EXISTS  Live_Production.dbo.Product_Line_Snapshot 
SELECT * INTO Live_Production.dbo.Product_Line_Snapshot 
FROM Live_Staging.dbo.Product_Line_Snapshot

DROP TABLE IF EXISTS  Live_Production.dbo.RolloverBookings_Data
SELECT * INTO Live_Production.dbo.RolloverBookings_Data 
FROM Live_Staging.dbo.RolloverBookings_Data

DROP TABLE  IF EXISTS Live_Production.dbo.u_Dell_EMC_POR_Data
SELECT * INTO Live_Production.dbo.u_Dell_EMC_POR_Data 
FROM Live_Staging.dbo.u_Dell_EMC_POR_Data

DROP TABLE  IF EXISTS Live_Production.dbo.Executive_POR_Data 
SELECT * INTO Live_Production.dbo.Executive_POR_Data 
FROM Live_Staging.dbo.Executive_POR_Data

DROP TABLE  IF EXISTS Live_Production.dbo.u_PLS_wRollover_Waterfall
SELECT * INTO Live_Production.dbo.u_PLS_wRollover_Waterfall 
FROM Live_Staging.dbo.u_PLS_wRollover_Waterfall

DROP TABLE IF EXISTS  Live_Production.dbo.u_Customer
SELECT * INTO Live_Production.dbo.u_Customer 
FROM Live_Staging.dbo.u_Customer

DROP TABLE  IF EXISTS Live_Production.dbo.Revenue_Schedule_Detail
SELECT * INTO Live_Production.dbo.Revenue_Schedule_Detail 
FROM Live_Staging.dbo.Revenue_Schedule_Detail


DROP TABLE Live_Production.dbo.Product_Line_Snapshot_Totals
SELECT * INTO Live_Production.dbo.Product_Line_Snapshot_Totals 
FROM Live_Staging.dbo.Product_Line_Snapshot_Totals

--DROP TABLE  IF EXISTS 
--Live_Production.dbo.Product_Line_Snapshot_Totals_With_Rollover
--SELECT * INTO Live_Production.dbo.Product_Line_Snapshot_Totals_With_Rollover 
--FROM Live_Staging.dbo.Product_Line_Snapshot_Totals_With_Rollover

DROP TABLE  IF EXISTS Live_Production.dbo.Opportunity_Header 
SELECT * INTO Live_Production.dbo.Opportunity_Header 
FROM Live_Staging.dbo.Opportunity_Header

DROP TABLE  IF EXISTS Live_Production.dbo.POR_Data 
SELECT * INTO Live_Production.dbo.POR_Data 
FROM Live_Staging.dbo.POR_Data

--DROP TABLE  IF EXISTS Live_Production.dbo.Quota_Data 
--SELECT * INTO Live_Production.dbo.Quota_Data 
--FROM Live_Staging.dbo.Quota_Data

DROP TABLE IF EXISTS  Live_Production.dbo.[User Role Based Hierarchy]
SELECT * INTO Live_Production.dbo.[User Role Based Hierarchy] 
FROM Live_Staging.dbo.[User Role Based Hierarchy]

DROP TABLE IF EXISTS  Live_Production.dbo.u_audit_log
SELECT * INTO Live_Production.dbo.u_audit_log 
FROM Live_Staging.dbo.u_audit_log

DROP TABLE IF EXISTS   Live_Production.dbo.u_Account
SELECT * INTO Live_Production.dbo.u_Account
 FROM Live_Staging.dbo.u_Account

 DROP TABLE  IF EXISTS Live_Production.dbo.[OutboundReportPreview]
SELECT * INTO Live_Production.dbo.[OutboundReportPreview]
 FROM Live_Staging.dbo.[OutboundReportPreview]

 DROP TABLE IF EXISTS  Live_Production.dbo.[u_sales_rep_performance]
SELECT * INTO Live_Production.dbo.[u_sales_rep_performance]
 FROM Live_Staging.dbo.[u_sales_rep_performance]

  DROP TABLE IF EXISTS  Live_Production.dbo.Latest_PLS_Totals
SELECT * INTO Live_Production.dbo.Latest_PLS_Totals
 FROM Live_Staging.dbo.Latest_PLS_Totals


 END
SET NOCOUNT OFF

END
