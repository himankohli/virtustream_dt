/**

Created common data source for Account and Customer dashboards, and create flags for
New Logos, Existing Revnuenue, and Customer Churned at Opportunity level.

**/
ALTER PROCEDURE [dbo].[sp_account]
AS
BEGIN

	SET NOCOUNT ON

	DECLARE @today date=(SELECT getdate())

	DECLARE @current_quarter varchar(10)=(SELECT fiscal_qtr FROM [dbo].[FiscalQuarters] WHERE [date]=@today)

	DECLARE @fiscal_quarter_rank TABLE
	(
		fiscal_qtr nvarchar(255),
		[rank] int
	)

	INSERT INTO @fiscal_quarter_rank
	(
		fiscal_qtr,
		[rank]
	)
	(
		SELECT [fiscal_qtr] , row_number() over (order by [fiscal_qtr]) as rank  FROM [dbo].[FiscalQuarters]
		GROUP BY [fiscal_qtr]
	)


	DECLARE @last_quarter VARCHAR(10)=(SELECT fiscal_qtr from @fiscal_quarter_rank
	WHERE rank=(SELECT rank-1 FROM @fiscal_quarter_rank WHERE fiscal_qtr=(SELECT DISTINCT [fiscal_qtr] 
	FROM [dbo].[FiscalQuarters] WHERE [date]=@today)))

	DECLARE @stly_quarter VARCHAR(10)=(SELECT fiscal_qtr from @fiscal_quarter_rank
	WHERE rank=(SELECT rank-4 from @fiscal_quarter_rank WHERE fiscal_qtr=(SELECT DISTINCT [fiscal_qtr] 
	FROM [dbo].[FiscalQuarters] WHERE [date]=@today)))


	DECLARE @current_year INT=(SELECT CAST(SUBSTRING(fiscal_qtr,1,4) AS INT) 
	FROM [dbo].[FiscalQuarters] WHERE [date]=@today)

	IF  EXISTS(SELECT name from sys.tables WHERE name='u_Account')
	DROP TABLE [dbo].[u_Account]


	SELECT  opphead.acc_id as account_id,
	opphead.acc_name as account_name,
	opphead.acc_billingcountry as account_billingcountry,
	opphead.acc_billingcity as account_billingcity,
	opphead.acc_segment as account_segment,
	opphead.acc_ownername as account_ownername,
	opphead.user_name as user_name,
	opphead.acc_theater__c as account_theatre,
	opphead.acc_vertical__c as account_vertical,
	opphead.opp_theater__c as opp_theatre, 
	opphead.opp_segment__c  opp_segment,
	opphead.acc_dell_emc_segment__c as account_dell_emc_segment,
	opphead.acc_managername as managername,
	(SELECT MIN(opp_closedate) from opportunity_header
	WHERE acc_id=opphead.acc_id and 
	(opp_stagename like '99%' or opp_stagename like '100%')) as customer_since,
	(SELECT MAX(primarycontactid) from opportunity_header WHERE acc_id=opphead.acc_id) as primarycontact,

	(SELECT sum(revschd_forecast_amount__c) FROM [dbo].[Revenue_Schedule_Detail]
	 WHERE valid_flag=1 AND (stage__c like '100%' or stage__c like '99%') AND
	SUBSTRING(revschd_fiscal_period__c,4,4)=(SELECT  SUBSTRING(fiscal_qtr,1,4) from [dbo].[FiscalQuarters]
	WHERE date=@today) and pl_id=revsc.pl_id) as annual_revenue,

	opphead.opp_id as opp_id,
	opphead.opp_stagename as stagename,
	(SELECT max(a.fiscal_qtr) from fiscalquarters a
	WHERE a.date=cast(opphead.opp_closedate as date)) as fiscalquarter,

	opphead.opp_name as opp_name,
	p.quant_practice_group__c as lob,

	stuff((SELECT ','+ quant_practice_group__c from (SELECT distinct o.opp_id ,
	p.quant_practice_group__c from opportunity_header o
	LEFT JOIN ProductLine pl ON opphead.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id) m
	WHERE m.opp_id=opphead.opp_id
	FOR XML PATH (''), type).value('.','nvarchar(max)'),1,1,'')
	as lob_concat,

	pl.id as pl_id,
	revsc.pl_annual_contact_value_year_1__c as pl_annual_contact_value_year_1__c,
	revsc.pl_committed_contract_value__c as pl_committed_contract_value__c,
	CASE WHEN pl_id IS NOT NULL THEN revsc.pl_total_contract_value__c 
	ELSE opphead.opp_amount
	END as pl_total_contract_value__c,

	opphead.opp_closedate as opp_closedate,

	CASE WHEN (opphead.opp_stagename like '0%' or opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%')
	THEN 
		CASE 
			WHEN  opphead.opp_createddate> opphead.opp_closedate
			THEN 0
			ELSE DATEDIFF(WEEK, opphead.opp_createddate, opphead.opp_closedate)
		END
	ELSE 
		DATEDIFF(WEEK, opphead.opp_createddate, GETDATE()) 
	END as deal_age,
	opphead.opp_heat_map__c as opp_heatmap,
	SUBSTRING(opphead.opp_stagename,1,CHARINDEX('%', opphead.opp_stagename)) as probability,

	(SELECT DISTINCT [start_date__c] FROM [dbo].[Fiscal_Period__c] 
	WHERE [isharddeleted]=0 and [mid_of_month__c]=(SELECT MIN(period__c) FROM [dbo].[Revenue_Schedule_Detail] 
	WHERE pl_opportunity__c=opphead.opp_id AND valid_flag=1)) 
	as opp_revenue_start_date__c,

	(SELECT DISTINCT [end_date__c]  FROM [dbo].[Fiscal_Period__c]  
	WHERE isharddeleted=0 and  mid_of_month__c=(SELECT MAX(period__c) from revenue_schedule_detail 
	WHERE    pl_opportunity__c=opphead.opp_id AND valid_flag=1)) as opp_revenue_end_date__c,

	(SELECT MAX(a.fiscal_period)  FROM [dbo].[FiscalQuarters] a
	WHERE a.date=CAST(GETDATE() as date)) as current_fiscal_period,


	(SELECT MIN(CAST(date as date)) FROM [dbo].[FiscalQuarters] 
	WHERE fiscal_qtr=@current_quarter) as cq_start_date,

	(SELECT MIN(CAST(date as date))  FROM [dbo].[FiscalQuarters] 
	WHERE SUBSTRING(fiscal_qtr,1,4)=@current_year)
	as cy_start_date,

	(SELECT MIN(CAST(date as date))  FROM [dbo].[FiscalQuarters] 
	WHERE fiscal_qtr=@last_quarter)
	as stlq_start_date,

	(SELECT MAX(CAST(date as date))  FROM [dbo].[FiscalQuarters] 
	WHERE fiscal_qtr=@stly_quarter)
	as stly_end_date,

	(SELECT MAX(CAST(date as date))  FROM [dbo].[FiscalQuarters] 
	WHERE fiscal_qtr=@current_quarter)
	as cq_end_date,

	(SELECT MAX(CAST(date as date))  FROM [dbo].[FiscalQuarters] 
	WHERE SUBSTRING(fiscal_qtr,1,4)=@current_year)
	as cy_end_date,

	(SELECT max(cast(date as date))  FROM [dbo].[FiscalQuarters] 
	WHERE fiscal_qtr=@last_quarter)
	as stlq_end_date,

	(SELECT min(cast(date as date))  FROM [dbo].[FiscalQuarters] 
	WHERE fiscal_qtr=@stly_quarter)
	as stly_start_date,


	 CASE 
		WHEN 
		(opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		and 
		(SELECT distinct fiscal_qtr  FROM [dbo].[FiscalQuarters] 
		WHERE date=cast(opphead.opp_closedate as date))=@current_quarter
		THEN 1
		ELSE 0
		END
	 as cq_new_logo_flag,

	 CASE 
		WHEN 
		opphead.opp_stagename not like '0%' and opphead.opp_stagename not like '99%' 
		and opphead.opp_stagename not like '100%' 
		and 
		(SELECT distinct fiscal_qtr  FROM [dbo].[FiscalQuarters] WHERE 
		date=cast(opphead.opp_closedate as date))=@current_quarter
		THEN 1
		ELSE 0
		END
	 as cq_new_logo_pipeline_flag,
	 CASE 
		WHEN (opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		 and 
	(SELECT  distinct substring(fiscal_qtr,1,4) from fiscalquarters
	 WHERE date=cast(opphead.opp_closedate as date))=@current_year
		then 1
		else 0
		end
	 as cy_new_logo_flag,
	 CASE 
		when 
		(opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		and
		(SELECT  distinct fiscal_qtr from fiscalquarters WHERE 
		date=cast(opphead.opp_closedate as date))=@last_quarter
		

		then 1
		else 0
		end
	 as stlq_new_logo_flag,

	  CASE 
		when 
		(opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		and
		(SELECT  distinct fiscal_qtr from fiscalquarters WHERE 
		date=cast(opphead.opp_closedate as date))=@stly_quarter
		
		then 1
		else 0
		end as stly_new_logo_flag,
	 CASE 
		WHEN (opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		and @today <= (SELECT distinct end_date__c from fiscal_period__c 
	WHERE isharddeleted=0 and 
	 mid_of_month__c=(SELECT max(period__c) from revenue_schedule_detail 
	WHERE    pl_opportunity__c=opphead.opp_id AND valid_flag=1))
		then 1
		else 0
		END
	 as cq_active_revenue_flag,

	 CASE 
		WHEN (opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		and @today <= (SELECT distinct end_date__c from fiscal_period__c 
	WHERE isharddeleted=0 and  mid_of_month__c=(SELECT max(period__c) from revenue_schedule_detail 
	WHERE    pl_opportunity__c=opphead.opp_id AND valid_flag=1))
		then 1
		else 0
		END
	 as cy_active_revenue_flag,

	  CASE WHEN 
		((opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		AND CAST(opphead.opp_closedate AS DATE)<=(SELECT MAX(cast(date as date)) from fiscalquarters 
	WHERE fiscal_qtr=@last_quarter)
		and 
		(SELECT MAX(cast(date as date)) from fiscalquarters 
	WHERE fiscal_qtr=@last_quarter) < (SELECT distinct end_date__c from fiscal_period__c 
	WHERE isharddeleted=0 and  mid_of_month__c=(SELECT max(period__c) from revenue_schedule_detail 
	WHERE    pl_opportunity__c=opphead.opp_id AND valid_flag=1)))
		then 1
		else 0
		end as stlq_active_revenue_flag,
		CASE WHEN 
		((opphead.opp_stagename like '99%' or opphead.opp_stagename like '100%') 
		AND CAST(opphead.opp_closedate AS DATE)<=(SELECT MAX(cast(date as date)) from fiscalquarters 
	WHERE fiscal_qtr=@stly_quarter)
		and 
		(SELECT MAX(cast(date as date)) from fiscalquarters 
	WHERE fiscal_qtr=@stly_quarter) < (SELECT distinct end_date__c from fiscal_period__c 
	WHERE isharddeleted=0 and  mid_of_month__c=(SELECT max(period__c) from revenue_schedule_detail 
	WHERE    pl_opportunity__c=opphead.opp_id AND valid_flag=1)))
		then 1
		else 0
		end
	 as stly_active_revenue_flag,
	opphead.opp_competitor__c as opp_competitor__c,
	opphead.opp_loss_reason__c as opp_loss_reason__c,
	opphead.lost_from_stage as lost_from_stage,
	revsc.pl_booked_amount__c as booked_amount_with_override,
	 revsc.revschd_actual__c as revschd_actual__c,
	 revsc.revschd_projection__c as revschd_projection__c,
	 @today as [current_date],
	 CASE WHEN revschd_count<>0 THEN 1
	 ELSE 0
	 END as revschd_flag
	INTO u_Account
	from opportunity_header opphead
	
	LEFT JOIN ProductLine pl ON opphead.opp_id=pl.opportunity__c
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN
	(SELECT pl_id, max(pl_annual_contact_value_year_1__c) as pl_annual_contact_value_year_1__c,
	max(pl_committed_contract_value__c) as pl_committed_contract_value__c,
	max(pl_total_contract_value__c) as pl_total_contract_value__c,
	SUM(revschd_booked_amount_final) as pl_booked_amount__c,
	max(pl_opportunity__c) as pl_opportunity__c, max(stage__c) as stage__c,
	sum(revschd_actual__c) as revschd_actual__c,
	sum(revschd_projection__c) as revschd_projection__c,
	count(*) as revschd_count
	FROM revenue_schedule_detail
	WHERE  valid_flag=1 group by pl_id) revsc
	on pl.id=revsc.pl_id
	WHERE ISNULL(p.quant_practice_group__c,'a')<>'Managed Services'
	SET NOCOUNT OFF
END


