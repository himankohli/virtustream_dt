
ALTER PROCEDURE SFDC_Operations_Data 
(@snapshot_date DATE, @fiscal_qtr VARCHAR(20), @Period_Start VARCHAR(20), @Period_End VARCHAR(20))

AS
BEGIN

DECLARE @d date=(SELECT snapshot_date FROM (
SELECT snapshot_date, COUNT(DISTINCT snapshot_type) as ab FROM Revenue_Schedule_Snapshot
GROUP BY snapshot_date) a
where a.ab=2)

DECLARE @p_start DATE=(SELECT Mid_of_Month__c FROM Fiscal_Period__c
where Name=@Period_Start AND isharddeleted=0)

DECLARE @p_end DATE=(SELECT Mid_of_Month__c FROM Fiscal_Period__c
where Name=@Period_End AND isharddeleted=0)


DECLARE @fiscal_period NVARCHAR(MAX)=(SELECT CONCAT(


(SELECT  DISTINCT  STUFF(
(SELECT DISTINCT '], [' +t1.Name  FROM Fiscal_Period__c t1
where t1.isharddeleted=0 AND t1.Mid_of_Month__c BETWEEN @p_start AND @p_end
FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'') 
FROM Fiscal_Period__c t
where t.isharddeleted=0 AND t.Mid_of_Month__c BETWEEN @p_start AND @p_end),
']'))


DECLARE @s VARCHAR(MAX)=(SELECT CONCAT(
'

SELECT DISTINCT
[Revenue Schedule Practice Line], 
[Revenue Schedule Service Line],
[Quant Segment Practice Group],
[Probability],
Stage,
[Heat Map],
 [Opportunity ID],
[Opportunity Number],
[SO Number],
[Sold To],
[Account Name],
[Opportunity],
[Theater],
 [Segment],
[Fiscal Year/Quarter],
[Close Date],
[Start Date],
[Owner Name],
[Country],
[Initial Revenue],
[Committed Term],
[TERM],
[Committed Contract Value],
[Annual Contract Value Year1],
[Booking Amount],
[Opportunity Type],
[Sales Channel],
[Primary Data Center],
[Secondary Data Center],
[Lead Source],
 [Additional Lead Sources],
 [Sub Segment],
[Primary Partner],
 [Primary Partner Type],
 [Job Code],
[Legal Entity],
 [WBSE],
[Dell EMC Classification],
 [Dell EMC Division],
 ',@fiscal_period,' 
 
FROM

(SELECT r.pl_practice_line__c AS [Revenue Schedule Practice Line], 
r.pl_service_line__c AS [Revenue Schedule Service Line],
r.product_quant_practice_group__c AS [Quant Segment Practice Group],
SUBSTRING(MAX(r.opp_stagename),1,CHARINDEX(''%'',MAX(r.opp_stagename))) as [Probability],
MAX(r.opp_stagename) as Stage,
MAX(CAST(r.opp_heat_map__c AS INT)) as [Heat Map],
r.opp_id as [Opportunity ID],
MAX(r.opp_opportunity_number__c) as [Opportunity Number],
MAX(r.opp_so_number__c) as [SO Number],
MAX(o.opp_Sold_To__c) as [Sold To],
MAX(r.acc_name) as [Account Name],
MAX(r.opp_name) as [Opportunity],
MAX(r.opp_theatre__c) as [Theater],
MAX(r.opp_segment__c) as [Segment],
CONCAT(''FY '',MAX(r.opp_close_fiscal_quarter)) as [Fiscal Year/Quarter],
CAST(MAX(r.opp_closedate) as DATE) as [Close Date],
MIN(pl.Initial_Start_Date__c) as [Start Date],
MAX(u.Name) as [Owner Name],
MAX(r.opp_country__c) as [Country],
MAX(pl.Initial_Revenue__c) as [Initial Revenue],
MAX(pl.committed_term) as [Committed Term],
MAX(pl.term) as [TERM],
SUM(ISNULL(r.revschd_ccv_final,0)) as [Committed Contract Value],
SUM(ISNULL(r.revschd_acv_final,0)) as [Annual Contract Value Year1],
CASE WHEN SUM(ISNULL(r.pl_booked_amount_override__c,0))<>0
THEN  SUM(ISNULL(r.pl_booked_amount_override__c,0))/COUNT(*) 
ELSE SUM(ISNULL(r.revschd_booked_amount_final,0)) END as [Booking Amount],
SUM(ISNULL(r.revschd_forecast_amount__c,0)) as [Forecast Amount],
MAX(r.opp_type) as [Opportunity Type],
MAX(r.opp_sales_channel__c) as [Sales Channel],
MAX(r.opp_primary_data_center__c) as [Primary Data Center],
MAX(r.opp_secondary_data_center__c) as [Secondary Data Center],
MAX(r.opp_leadsource) as [Lead Source],
MAX(o.Additional_Lead_Sources__c) as [Additional Lead Sources],
MAX(r.opp_sub_segment__c) as [Sub Segment],
MAX(r.opp_lead_partner__c) as [Primary Partner],
MAX(r.opp_lead_partner_type__c) as [Primary Partner Type],
MAX(pl.Job_Code__c) as [Job Code],
MAX(o.Legal_Entity__c) as [Legal Entity],
MAX(pl.WBSE__c) as [WBSE],
MAX(r.acc_dell_emc_segment__c) as [Dell EMC Classification],
MAX(o.Dell_EMC_Alignment__c) as [Dell EMC Division],
r.revschd_fiscal_period__c
FROM Revenue_Schedule_Snapshot r 
LEFT JOIN (SELECT opp.id ,acc.Name as opp_Sold_To__c, opp.Legal_Entity__c,
a.Dell_EMC_Alignment__c,
opp.Additional_Lead_Sources__c FROM Opportunity opp LEFT JOIN Account acc
ON opp.Sold_To__c=acc.Id 
LEFT JOIN (SELECT Id, Dell_EMC_Alignment__c FROM Account where IsHardDeleted=0) a
ON opp.accountId=a.Id
where opp.isharddeleted=0) o
ON r.opp_id=o.Id LEFT JOIN (SELECT p.Id, p.Initial_Start_Date__c, p.Initial_Revenue__c, p.Job_Code__c,
 p.WBSE__c,t.term, ct.committed_term FROM ProductLine p
 LEFT JOIN
(SELECT pl_id , COUNT(DISTINCT revschd_fiscal_period__c) as term FROM Revenue_Schedule_Snapshot 
where
isharddeleted=0
AND revschd_id IS NOT NULL 
AND  snapshot_type LIKE (CASE WHEN snapshot_date=''',@d,''' THEN ''DAY%'' ELSE snapshot_type END)
AND snapshot_date=''',@snapshot_date,''' AND field_source=''SFDC''
GROUP BY pl_id) t ON p.Id=t.pl_id
LEFT JOIN
(SELECT pl_id , COUNT(DISTINCT revschd_fiscal_period__c) AS committed_term FROM Revenue_Schedule_Snapshot where
 isharddeleted=0
 AND revschd_id IS NOT NULL AND revschd_committed_amount__c IS NOT NULL
 AND snapshot_type LIKE (CASE WHEN snapshot_date=''',@d,''' THEN ''DAY%'' ELSE snapshot_type END)
AND snapshot_date=''',@snapshot_date,''' AND field_source=''SFDC''
GROUP BY pl_id) ct  ON p.Id=ct.pl_id
 WHERE Isharddeleted=0) pl
 ON r.pl_Id=pl.Id
 LEFT JOIN (SELECT Id, [NAme] FROM [User] where isharddeleted=0) u
 ON r.opp_ownerid=u.Id
 where r.isharddeleted=0
 AND r.revschd_id IS NOT NULL
  AND snapshot_type LIKE (CASE WHEN snapshot_date=''',@d,''' THEN ''DAY%'' ELSE snapshot_type END)
AND r.snapshot_date=''',@snapshot_date,''' AND r.field_source=''SFDC''
AND r.opp_close_fiscal_quarter=''',@fiscal_qtr,''' GROUP BY  r.pl_practice_line__c , 
r.pl_service_line__c ,
r.product_quant_practice_group__c ,
r.opp_id, r.revschd_fiscal_period__c)
 AS SOURCE_TABLE
PIVOT 
(SUM([Forecast Amount]) FOR revschd_fiscal_period__c IN
 (',@fiscal_period,'))
AS PIV' ))

EXEC (@s)


END


