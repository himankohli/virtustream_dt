/**
[sp_intermediary_objects] is the Stored Procedure that triggers the creation of Opportunity_Header,
Revenue_Schedule_Detail, and Lead_Header.
**/

ALTER PROCEDURE [dbo].[sp_intermediary_objects]
AS
BEGIN
		SET NOCOUNT ON

	DROP TABLE IF  EXISTS [Opportunity_Header]
	
	SELECT
	o.id as opp_id,
	o.country__c as opp_country__c,
	o.theater__c as opp_theater__c,
	o.segment__c as opp_segment__c,
	CAST(o.closedate as DATE) as opp_closedate,
	CAST(o.createddate as DATE) as opp_createddate,
	o.ownerid as opp_ownerid,
	o.accountid as opp_accountid,
	o.name as opp_name,
	o.stagename as opp_stagename,
	o.Amount/cur.conversionrate as opp_amount,
	o.probability as opp_probability,
	o.type as opp_type,
	o.leadsource as opp_leadsource,
	o.primary_partner_role__c as opp_primary_partner_role__c,
	o.isclosed as opp_isclosed,
	o.iswon as opp_iswon,
	o.gate__c as opp_gate__c,
	o.heat_map__c as opp_heat_map__c,
	o.primary_data_center__c as opp_primary_data_center__c,
	o.loss_reason__c as opp_loss_reason__c,
	o.sales_channel__c as opp_sales_channel__c,
	o.secondary_data_center__c as opp_secondary_data_center__c,
	o.opportunity_number__c as opp_opportunity_number__c,
	o.competitor__c as opp_competitor__c,
	o.sub_segment__c as opp_sub_segment__c,
	o.emc_opportunity_number__c as opp_emc_opportunity_number__c,
	CAST(ac.acc_partner_type__c AS VARCHAR(50)) as opp_lead_partner_type__c,
	ac.Name as opp_lead_partner__c,
	o.revenue_start_date__c as opp_revenue_start_date__c,
	o.revenue_END_date__c as opp_revenue_END_date__c,
	o.opportunity_conversion__c as opp_opportunity_conversion__c,
	o.related_opportunity__c as opp_related_opportunity__c,
	o.related_product_amount__c as opp_related_product_amount__c,
	o.so_number__c as opp_so_number__c,
	o.dell_technologies_business__c as opp_dell_technologies_business__c,
	o.opportunity_age__c as opp_opportunity_age__c,
	o.pardot_campaign__c as opp_pardot_campaign__c,
	c.user_id,
	c.user_employeenumber,
	c.user_name,
	c.user_division,
	c.user_department,
	c.user_email,
	c.user_userroleid,
	c.user_managerid,
	c.user_managername,
	c.user_forecastenabled,
	c.ur_owner_role_name,
	SUBSTRING(o.Fiscal_Year_Quarter__c,4,7) as opp_close_fiscal_quarter,
	b.acc_id,
	b.acc_name,
	b.acc_industry,
	b.acc_type,
	b.acc_billingcountry,
	b.acc_billingcity,
	b.acc_accountnumber,
	b.acc_ownerid,
	(SELECT [name] FROM [user] WHERE id=b.acc_ownerid
	and isharddeleted=0) as acc_ownername,
	(SELECT [name] FROM [user] WHERE  isharddeleted=0 and
	id=(SELECT managerid FROM [user] WHERE id=b.acc_ownerid and isharddeleted=0)) as acc_managername,
	b.acc_original_lead_source__c,
	b.acc_segment,
	b.acc_sub_segment,
	b.acc_theater__c,
	b.acc_vertical__c,
	b.acc_ucid__c,
	b.acc_affinity_id__c,
	b.acc_dell_emc_segment__c,
	b.acc_site_duns__c,
	b.acc_dell_emc_area__c,
	b.acc_gu_duns__c,
	b.acc_dell_emc_district__c, 
	b.acc_segment__c,
	CAST(ac.acc_partner_type__c AS VARCHAR(50)) as acc_partner_type__c,
	(SELECT [name] FROM contact WHERE  isharddeleted=0 and  id in
	(SELECT b.contactid
	FROM opportunitycontactrole b
	WHERE b.isharddeleted=0 and  b.opportunityid = o.id and b.isprimary=1)) as primarycontactid,
		 o.application__c as opp_application,
		 case when [Dell_Technologies_Role__c] ='Led' or [Primary_Partner_Role__c]='Led'then 'Led'
		when [Dell_Technologies_Role__c] ='Introduced' or 
		[Primary_Partner_Role__c]='Introduced'then 'Introduced'
		when [Dell_Technologies_Role__c] ='Facilitated' or
		 [Primary_Partner_Role__c]='Facilitated'then 'Facilitated' end as channel_lev5,
		 cast(NULL as date) as opp_lost_date,
		 cast(null  as int) as opp_push_cnt,
		 cast(null  as int) as current_week_num,
		 o.dell_technologies_role__c
	into Opportunity_Header
	FROM opportunity o
	left join  currencytype cur on o.currencyisocode=cur.isocode
	LEFT JOIN (SELECT 
	id as acc_id,
	name as acc_name,
	industry as acc_industry,
	type as acc_type,
	billingcountry as acc_billingcountry,
	billingcity as acc_billingcity,
	accountnumber as acc_accountnumber,
	ownerid as acc_ownerid,
	original_lead_source__c as acc_original_lead_source__c,
	segment__c as acc_segment,
	sub_segment__c as acc_sub_segment,
	theater__c as acc_theater__c,
	vertical__c as acc_vertical__c,
	ucid__c as acc_ucid__c,
	affinity_id__c as acc_affinity_id__c,
	CASE 
		when substring(dell_emc_segment__c,1,10)='COMMERCIAL'
		then 'Commercial'
		when substring(dell_emc_segment__c,1,10)='ENTERPRISE'
		then 'Enterprise'
		when substring(dell_emc_segment__c,1,7)='FEDERAL'
		then 'Federal'
		ELSE dell_emc_segment__c
	END as acc_dell_emc_segment__c,
	site_duns__c as acc_site_duns__c,
	dell_emc_area__c as acc_dell_emc_area__c,
	gu_duns__c as acc_gu_duns__c,
	dell_emc_district__c as acc_dell_emc_district__c,
	segment__c as acc_segment__c,
	partner_type__c as acc_partner_type__c
	FROM account WHERE isharddeleted=0 ) b
	on o.accountid=b.acc_id
	LEFT JOIN (SELECT DISTINCT id, Name, partner_type__c as acc_partner_type__c
	 FROM Account 
	where isharddeleted=0 --and partner_type__c IS NOT NULL
	) ac 
	ON o.Primary_Partner__c=ac.Id
	LEFT JOIN (SELECT u.id as user_id,
	u.employeenumber as user_employeenumber,
	u.name as user_name,
	u.division as user_division,
	u.department as user_department,
	u.email as user_email,
	u.userroleid as user_userroleid,
	u.managerid as user_managerid,
	(SELECT [name] FROM [user] WHERE isharddeleted=0 and  id=u.managerid) as user_managername,
	u.forecastenabled as user_forecastenabled,
	ur.name as ur_owner_role_name
	FROM [dbo].[user] u left join userrole ur
	on u.userroleid = ur.id	
	WHERE u.isharddeleted=0 and ur.isharddeleted=0) c
	on o.ownerid = c.user_id
	--LEFT JOIN (SELECT distinct fiscal_qtr as opp_close_fiscal_quarter, date as fq_date FROM fiscalquarters) d
	--on o.closedate=d.fq_date 
	WHERE o.isdeleted=0
	and o.isharddeleted=0 AND ISNULL(o.type,'a') <> 'CSP-Sell Out'

	ALTER TABLE Opportunity_Header
	ADD lost_from_stage  nvarchar(255)

	UPDATE  opportunity_header
	SET
	lost_from_stage =(SELECT top 1 oldvalue FROM (SELECT b.oldvalue , b.createddate
	FROM opportunityfieldhistory b
	WHERE b.opportunityid in(
	SELECT id FROM opportunity
	WHERE stagename like '0%') and b.opportunityid = a.opp_id
	and b.field='stagename'
	)sys order by createddate desc )
	FROM opportunity_header a
	WHERE a.opp_stagename like '0%'

	
	UPDATE  Opportunity_Header
	SET lost_FROM_stage =opp_stagename
	WHERE opp_stagename like '0%'
	and lost_from_stage is null


-----------------------------------------------------------
 ---------------------Opp_Lst_Date Update------------------

 
update a 
set opp_lost_date=b.opp_lost_date
from Opportunity_Header a 
join (
select Opportunityid as id,max(CreatedDate) as opp_lost_date from OpportunityFieldHistory
where field ='StageName' and NewValue='0% Lost (Closed/Lost)'
group by Opportunityid) b
on a.opp_id=b.Id
where a.opp_stagename='0% Lost (Closed/Lost)'

------------------------------------------

---------Number of time opp close date was pushed---------------
update a 
set opp_push_cnt=coalesce(b.c1,0)
 from Opportunity_Header a 
 left join (
select OpportunityId,count(1) as c1  from OpportunityFieldHistory
where Field in ('CloseDate')
group by OpportunityId) b
on a.opp_id=b.OpportunityId




--------------------------------------------------

-----------------current week number update-------------------------
declare @min_date date
set @min_date=(select cast(min([date]) as date) as min_date from FiscalQuarters where fiscal_qtr in (
select fiscal_qtr from FiscalQuarters
where cast([date] as date)=cast(getdate() as date)) 
group by fiscal_qtr)

update Opportunity_Header
set current_week_num=(
select ceiling(cast(DATEDIFF(day,@min_date,getdate()+1) as float)/7 ))



----------------------------------------------------------------

	DECLARE @a INT=(SELECT COUNT(*) FROM opportunity_header)

	DECLARE @b INT=(SELECT COUNT(*) FROM opportunity where isharddeleted=0 AND ISNULL(type,'a')<>'CSP-Sell Out')

	IF(@a<>@b)
	BEGIN
		INSERT INTO u_audit_log
		values('Opportunity_Header: Record Count Not Matching',0,GETDATE(),NULL,NULL,NULL)
	END
	ELSE
	BEGIN
		INSERT INTO u_audit_log
		values('Opportunity_Header: Object Updated',1,GETDATE(),NULL,NULL,NULL)
	END

-------------------------------------------------------------------------
---------------------------Revenue_Schedule_Detail-----------------------
-------------------------------------------------------------------------

	DECLARE @today DATE=(SELECT GETDATE())

	DROP TABLE IF  EXISTS  [dbo].[Revenue_Schedule_Detail]

 SELECT r.id as revschd_id, pl.id  as pl_id, pl.name as pl_name, pl.product__c as pl_product__c, 
 pl.service_line__c as pl_service_line__c, pl.practice_line__c as pl_practice_line__c,
 pl.opportunity__c as pl_opportunity__c, 
 pl.annual_contact_value_year_1__c/cpl.conversionrate as pl_annual_contact_value_year_1__c,
 pl.committed_contract_value__c/cpl.conversionrate as pl_committed_contract_value__c,
 pl.total_contract_value__c/cpl.conversionrate as pl_total_contract_value__c,
 pl.booked_amount__c/cpl.conversionrate as pl_booked_amount__c,
 pl.booked_amount_override__c/cpl.conversionrate as pl_booked_amount_override__c,
 p.name as product_name,
 p.quant_practice_group__c as product_quant_practice_group__c, p.family as product_family,
 r.stage__c , r.period__c, r.createddate as revschd_createddate,
 r.committed_amount__c/c.conversionrate as revschd_committed_amount__c,
 r.projection__c/c.conversionrate as revschd_projection__c,
  r.actual__c/c.conversionrate as revschd_actual__c, 
 r.forecast_amount__c/c.conversionrate as revschd_forecast_amount__c, 
 fp.fiscal_period as revschd_fiscal_period__c
 ,CASE
		WHEN r.include_in_acv_1__c=1 or
			r.include_in_acv_2__c=1 or
			r.include_in_acv_3__c=1
		THEN
			CASE 
				WHEN r.stage__c like '100%'
				THEN r.booked_committed_amount__c/c.conversionrate
				ELSE r.committed_amount__c/c.conversionrate
	
			END
		ELSE null
		END as revschd_ccv_final,
		CASE
		
				WHEN r.stage__c like '100%'
				THEN r.booked_committed_amount__c/c.conversionrate
				ELSE r.committed_amount__c/c.conversionrate
	
			END as revschd_tcv_final,

		CASE 
			WHEN r.stage__c like '100%'
			THEN 
				CASE
					WHEN  r.include_in_acv_1__c=1 THEN r.booked_amount__c/c.conversionrate
					ELSE null
				END
			ELSE r.acv_1__c/c.conversionrate
		END as revschd_acv_final,

		CASE 
		WHEN pl.annual_contact_value_year_1__c>=  pl.committed_contract_value__c
		and r.stage__c like '100%'
		THEN 
			CASE
				WHEN  r.include_in_acv_1__c=1 THEN r.booked_amount__c/c.conversionrate
				ELSE null
			END
		WHEN pl.annual_contact_value_year_1__c<  pl.committed_contract_value__c
		and r.stage__c like '100%'
		THEN
			CASE
				WHEN  r.include_in_acv_1__c=1 or
				r.include_in_acv_2__c=1 or
				r.include_in_acv_3__c=1
				THEN r.booked_committed_amount__c/c.conversionrate
				ELSE null
			END
		WHEN pl.annual_contact_value_year_1__c>=  pl.committed_contract_value__c
		and r.stage__c not like '100%'
		THEN
			r.acv_1__c/c.conversionrate
		WHEN pl.annual_contact_value_year_1__c<  pl.committed_contract_value__c
		and r.stage__c not like '100%'
		THEN
			CASE
				WHEN  r.include_in_acv_1__c=1 or
				r.include_in_acv_2__c=1 or
				r.include_in_acv_3__c=1
				THEN r.committed_amount__c/c.conversionrate
				ELSE null
			END
	END as revschd_booked_amount_final,
	CASE WHEN ISNULL(r.forecast_amount__c,1)<>0 
	AND ISNULL(p.quant_practice_group__c,'a')<>'Managed Services'
	THEN 1 ELSE 0 END as valid_flag
 INTO Revenue_Schedule_Detail
 FROM revenueschedule r 
 left join  currencytype c on r.currencyisocode=c.isocode
 left join (SELECT * FROM ProductLine where isharddeleted=0) pl on r.product_line__c=pl.id
 left join  currencytype cpl on pl.currencyisocode=cpl.isocode
 left join product2 p on pl.product__c=p.id
 left join (SELECT id, name as fiscal_period from fiscal_period__c WHERE isharddeleted=0 ) fp 
 on r.fiscal_period__c=fp.id
 WHERE r.isdeleted=0 
 and r.isharddeleted=0 and c.isharddeleted=0 

	DECLARE @c INT=(SELECT COUNT(*) FROM [dbo].[Revenue_Schedule_Detail])

	DECLARE @d INT=(SELECT COUNT(*) FROM [dbo].[RevenueSchedule] where isdeleted=0 and isharddeleted=0)

	IF(@c<>@d)
	BEGIN
		INSERT INTO u_audit_log
		values('Revenue_Schedule_Detail: Record Count Not Matching',0,GETDATE(),NULL,NULL,NULL)
	END
	ELSE
	BEGIN
		INSERT INTO u_audit_log
		values('Revenue_Schedule_Detail: Object Updated',1,GETDATE(),NULL,NULL,NULL)
	END
	SET NOCOUNT OFF

END


