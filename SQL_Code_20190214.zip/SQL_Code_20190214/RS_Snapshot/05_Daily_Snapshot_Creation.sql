/**

Daily Snapshot data is created based on required logic for current snapshots and
Histoy is calculated for previous snapshots

**/

ALTER PROCEDURE Daily_Snapshot_Creation(@ref_date DATETIME, @run_time TIME)
AS  
BEGIN
--------------Opportunity History Tracking-------------------



SET @ref_date=CASE
	WHEN @run_time>='00:00:00' AND @run_time<'08:00:00'
		THEN DATEADD(dd, -1, @ref_date) 
	ELSE @ref_date 
	END

	DECLARE @today DATETIME=(SELECT CAST(GETDATE() AS DATE))

	DROP TABLE IF  EXISTS #Opportunity_temp

	CREATE TABLE #Opportunity_temp 
	(
		Id NVARCHAR(255), 
		Account_Id NVARCHAR(255),
		Name NVARCHAR(255), 
		Stagename NVARCHAR(255), 
		CreatedDate DATETIME, 
		CloseDate DATETIME, 
		Type NVARCHAR(255), 
		Probability FLOAT,
		LeadSource NVARCHAR(255),
		Gate NVARCHAR(255),
		Manager NVARCHAR(255),
		Segment NVARCHAR(255),
		Iswon BIT,
		Isclosed BIT,  
		Heatmap BIT,
		Primary_Data_Center NVARCHAR(255),
		Sales_Channel NVARCHAR(255), 
		Country__c NVARCHAR(255),
		Theater NVARCHAR(255),
		OwnerId NVARCHAR(255),
		Secondary_Data_Center__c NVARCHAR(255),
		Opportunity_Number__c NVARCHAR(255),
		Sub_Segment__c NVARCHAR(255),
		EMC_Opportunity_Number__c NVARCHAR(255),
		Lead_Partner_Type__c NVARCHAR(255),
		Lead_Partner__c NVARCHAR(255),
		Opportunity_Conversion__c BIT,
		Related_Opportunity__c NVARCHAR(255),
		Related_Product_Amount__c FLOAT,
		SO_Number__c VARCHAR(255),
		Dell_Technologies_Business__c NVARCHAR(255),
		Opportunity_Age__c FLOAT,
		Pardot_Campaign__c NVARCHAR(255),
		Primary_Partner_Role__c NVARCHAR(255),
		application__c nvarchar(255)
	)

	
	IF(CASE
	WHEN @run_time>='00:00:00' AND @run_time<'08:00:00'
		THEN  DATEADD(dd, 1, @ref_date)
	ELSE    @ref_date
	END =@today)
	BEGIN
	INSERT INTO #Opportunity_temp
	(
		id, 
		Name,
		createddate,
		Stagename,
		CloseDate,
		Gate,
		Segment, 
		Manager,
		Heatmap,
		Type,
		Iswon,
		Isclosed,
		Country__c,
		Theater, 
		OwnerId,
		Account_id,
		Probability,
		LeadSource,
		Primary_Data_Center, 
		Sales_Channel,
		secondary_data_center__c,
		Opportunity_Number__c,
		Sub_Segment__c,
		emc_opportunity_number__c,
		lead_partner_type__c,
		lead_partner__c,
		opportunity_conversion__c,
		related_opportunity__c,
		related_product_amount__c ,
		so_number__c,
		Dell_Technologies_Business__c,
		Opportunity_Age__c,
		Pardot_Campaign__c,
		Primary_Partner_Role__c,
		application__c
	)  
	(SELECT o.id, o.Name,o.CreatedDate,o.Stagename, o.CloseDate, o.Gate__c,
	o.Segment__c ,o.Manager__c,o.Heat_Map__c,
	o.Type,
	o.Iswon,o.Isclosed,o.Country__c, 
	o.Theater__c,o.OwnerId, o.AccountId,o.Probability, o.LeadSource,
	o.Primary_Data_Center__c, o.Sales_Channel__c,
	o.secondary_data_center__c, 
	o.Opportunity_Number__c, o.sub_segment__c,o.emc_opportunity_number__c,
	o.Primary_Partner_Type__c as lead_partner_type__c,
	a.Name as lead_partner__c,
	o.opportunity_conversion__c,o.related_opportunity__c,o.related_product_amount__c,
	o.so_number__c,o.dell_technologies_business__c,o.opportunity_age__c,o.pardot_campaign__c,
	o.Primary_Partner_Role__c, o.application__c
	FROM Opp_copy   o LEFT JOIN Account a
	ON o.Primary_Partner__c=a.Id
	WHERE CAST(o.createddate AS DATE) <=CAST(@ref_date AS DATE) )
	END
	ELSE
	BEGIN
	
	INSERT INTO #Opportunity_temp
	(
		id, 
		createddate,
		Gate,
		Segment, 
		Iswon,
		Isclosed,
		Country__c,
		Theater, 
		OwnerId,
		Account_id,
		Probability,
		LeadSource,
		Primary_Data_Center, 
		Sales_Channel,
		secondary_data_center__c,
		Opportunity_Number__c,
		Sub_Segment__c,
		emc_opportunity_number__c,
		lead_partner_type__c,
		lead_partner__c,
		opportunity_conversion__c,
		related_opportunity__c,
		related_product_amount__c ,
		so_number__c,
		Dell_Technologies_Business__c,
		Opportunity_Age__c,
		Pardot_Campaign__c,
		Primary_Partner_Role__c,
		application__c
	)  
	(SELECT o.id, o.CreatedDate, o.Gate__c,o.Segment__c ,
	o.Iswon,o.Isclosed,o.Country__c, 
	o.Theater__c,o.OwnerId, o.AccountId,
	o.Probability, o.LeadSource,
	o.Primary_Data_Center__c, 
	o.Sales_Channel__c,
	o.secondary_data_center__c, o.Opportunity_Number__c, o.sub_segment__c,
	o.emc_opportunity_number__c,
	o.Primary_Partner_Type__c as lead_partner_type__c,
	a.Name as lead_partner__c,
	o.opportunity_conversion__c,o.related_opportunity__c,o.related_product_amount__c,
	o.so_number__c,o.dell_technologies_business__c,
	o.opportunity_age__c,o.pardot_campaign__c,
	o.Primary_Partner_Role__c, o.application__c
	FROM Opp_copy o LEFT JOIN Account a
	ON o.Primary_Partner__c=a.Id
	WHERE CAST(o.createddate AS DATE) <= CAST(@ref_date AS DATE))

	CREATE TABLE t_static_opps2 
	(
		id NVARCHAR(255), 
		createddate DATETIME,
		name NVARCHAR(255),
		type NVARCHAR(255),
		Manager NVARCHAR(255), 
		stagename NVARCHAR(255),  
		heatmap BIT, 
		closedate DATE
	)

	INSERT INTO t_static_opps2(id, createddate, name, type, Manager, stagename, heatmap, closedate)
	(SELECT id, createddate, name, type, Manager__c, stagename, heat_map__c, closedate  
	FROM Opp_copy WHERE id NOT IN 
	(SELECT DISTINCT opportunityid FROM OFH_Copy 
	WHERE field IN ('Name', 'Type', 'Manager__c','Heat_Map__c', 'StageName','CloseDate'))
	AND  CAST(createddate AS DATE)  <=  @ref_date)

	UPDATE #Opportunity_temp 
	SET stagename = b.stagename,
	heatmap= b.heatmap,
	closedate=b.closedate,
	name= b.name,
	type= b.type,
	Manager=b.Manager
	FROM #Opportunity_temp a JOIN t_static_opps2 b ON a.id = b.id
	

	CREATE TABLE t_ofh_last_record 
	(
		opportunityid CHAR(18), 
		field VARCHAR(34),  
		newvalue NVARCHAR(119), 
		CreatedDate DATETIME
	)

	CREATE TABLE t_ofh_last_record2 
	(
		opportunityid CHAR(18), 
		field VARCHAR(34), 
		oldvalue NVARCHAR(119),
		CreatedDate DATETIME
		
	)
	
	EXEC dbo.Prev_Records @ref_date
	EXEC dbo.Next_Records @ref_date

	UPDATE #Opportunity_temp 
	SET stagename = b.newvalue FROM #Opportunity_temp a JOIN t_ofh_last_record b
	ON a.id = b.opportunityid WHERE b.field = 'StageName' 
	AND a.stagename IS NULL

	UPDATE #Opportunity_temp
	SET heatmap = b.newvalue FROM #Opportunity_temp a JOIN  t_ofh_last_record b 
	ON a.id = b.opportunityid WHERE b.field = 'Heat_Map__c' 
	AND a.heatmap IS NULL
	
	UPDATE #Opportunity_temp 
	SET closedate = b.newvalue FROM #Opportunity_temp a JOIN  t_ofh_last_record b 
	ON a.id = b.opportunityid WHERE b.field = 'CloseDate'
	AND a.closedate IS NULL
	
	UPDATE #Opportunity_temp 
	SET name = b.newvalue FROM  #Opportunity_temp a JOIN t_ofh_last_record b 
	ON a.id = b.opportunityid WHERE b.field = 'name' 
	AND a.name IS NULL
	
	UPDATE #Opportunity_temp 
	SET type = b.newvalue FROM #Opportunity_temp a JOIN  t_ofh_last_record b 
	ON a.id = b.opportunityid WHERE b.field = 'type' 
	AND a.type IS NULL
	
	UPDATE #Opportunity_temp 
	SET Manager = b.newvalue FROM #Opportunity_temp a JOIN  t_ofh_last_record b 
	ON a.id = b.opportunityid WHERE b.field = 'Manager__c' 
	AND a.Manager IS NULL

	UPDATE #Opportunity_temp 
	SET stagename = b.oldvalue FROM  #Opportunity_temp a JOIN t_ofh_last_record2 b 
	ON a.id = b.opportunityid WHERE b.field = 'StageName' 
	 AND a.stagename IS NULL

	UPDATE #Opportunity_temp 
	SET heatmap = b.oldvalue FROM  #Opportunity_temp a JOIN t_ofh_last_record2 b 
	ON a.id = b.opportunityid WHERE b.field = 'Heat_Map__c' 
	AND a.heatmap IS NULL

	UPDATE #Opportunity_temp 
	SET closedate = b.oldvalue FROM  #Opportunity_temp a JOIN t_ofh_last_record2 b
	ON a.id = b.opportunityid WHERE b.field = 'CloseDate' 
	AND a.closedate IS NULL

	UPDATE #Opportunity_temp 
	SET name = b.oldvalue FROM #Opportunity_temp a JOIN  t_ofh_last_record2 b 
	ON a.id = b.opportunityid WHERE b.field = 'name' 
	AND a.name IS NULL

	UPDATE #Opportunity_temp 
	SET type = b.oldvalue FROM  #Opportunity_temp a JOIN t_ofh_last_record2 b 
	ON a.id = b.opportunityid WHERE b.field = 'type' 
	AND a.type IS NULL

	UPDATE #Opportunity_temp 
	SET Manager = b.oldvalue FROM #Opportunity_temp a JOIN  t_ofh_last_record2 b
	ON a.id = b.opportunityid WHERE b.field = 'Manager__c' 
	AND a.Manager IS NULL

	UPDATE #Opportunity_temp 
	SET stagename = b.stagename FROM #Opportunity_temp a JOIN  Opp_copy b 
	ON a.id = b.id WHERE  CAST(b.createddate AS DATE) <= @ref_date
	AND a.stagename IS NULL

	UPDATE #Opportunity_temp
	SET heatmap = b.heat_map__c FROM  #Opportunity_temp a JOIN Opp_copy b 
	ON a.id= b.id WHERE  CAST(b.createddate AS DATE) <= @ref_date
	AND a.heatmap IS NULL

	UPDATE #Opportunity_temp 
	SET closedate = b.closedate FROM #Opportunity_temp a JOIN  Opp_copy b 
	ON a.id= b.id WHERE  CAST(b.createddate AS DATE) <= @ref_date
	AND a.closedate IS NULL

	UPDATE #Opportunity_temp 
	SET name = b.name FROM #Opportunity_temp a JOIN  Opp_copy b 
	ON a.id= b.id WHERE  CAST(b.createddate AS DATE) <= @ref_date
	AND a.name IS NULL
	
	UPDATE #Opportunity_temp 
	SET type = b.type FROM #Opportunity_temp a JOIN  Opp_copy b 
	ON a.id= b.id WHERE  CAST(b.createddate AS DATE) <= @ref_date
	AND a.type IS NULL

	UPDATE #Opportunity_temp 
	SET Manager = b.Manager__c FROM #Opportunity_temp a JOIN  Opp_copy b 
	ON a.id= b.id WHERE CAST(b.createddate AS DATE) <= @ref_date
	AND a.Manager IS NULL
	

END
	UPDATE  #Opportunity_temp
	SET type=NULL
	WHERE type='ABCD'

	UPDATE #Opportunity_temp
	SET Manager=NULL
	WHERE Manager='ABCD'
	
	
--------------Revenue Schedule History Tracking-------------------

	CREATE  TABLE Rev_snap
	(
		Id NVARCHAR(255), 
		CreatedDate DATETIME, 
		CurrencyIsoCode CHAR(3),
		Committed_Amount__c FLOAT,
		Projection__c FLOAT,
		Actual__c FLOAT,
		Forecast_Amount__c FLOAT,
		Fiscal_Period__c NVARCHAR(255),
		Product_Line__c NVARCHAR(255),
		Opportunity__c NVARCHAR(255),
		Stage__c NVARCHAR(MAX),
		Include_in_ACV_1__c BIT,
		Include_in_ACV_2__c BIT,
		Include_in_ACV_3__c BIT,
		ACV_1__c FLOAT,
		Booked_Amount__c FLOAT,
		Booked_Committed_Amount__c FLOAT
	)

	IF(CASE
	WHEN @run_time>='00:00:00' AND @run_time<'08:00:00'
		THEN  DATEADD(dd, 1, @ref_date) ELSE    @ref_date END =@today)
	BEGIN

	INSERT INTO Rev_snap(Id, CreatedDate,
	CurrencyIsoCode,Committed_Amount__c ,
		Projection__c ,
		Actual__c , Fiscal_Period__c, Forecast_Amount__c,Product_Line__c,
	Stage__c, Opportunity__c,
	Include_in_ACV_1__c,
		Include_in_ACV_2__c,
		Include_in_ACV_3__c ,
		ACV_1__c ,
		Booked_Amount__c ,
		Booked_Committed_Amount__c  )  
	(SELECT id, CreatedDate, 
	CurrencyIsoCode, Committed_Amount__c , Projection__c , Actual__c,
	Fiscal_Period__c, Forecast_Amount__c, Product_Line__c,
	Stage__c, Opportunity__c,
	Include_in_ACV_1__c,
		Include_in_ACV_2__c,
		Include_in_ACV_3__c ,
		ACV_1__c ,
		Booked_Amount__c ,
		Booked_Committed_Amount__c
	FROM Rev_copy  WHERE  CAST(createddate AS DATE)<= @ref_date)

	END
	ELSE
	BEGIN
	/*Insertion the field which we are not tracking from RevenueScheduleHistory*/

	INSERT INTO Rev_snap(Id, CreatedDate,
	CurrencyIsoCode, Fiscal_Period__c, Forecast_Amount__c,Product_Line__c,
	Stage__c, Opportunity__c,
	Include_in_ACV_1__c,
		Include_in_ACV_2__c,
		Include_in_ACV_3__c ,
		ACV_1__c ,
		Booked_Amount__c ,
		Booked_Committed_Amount__c  )  
	(SELECT id, CreatedDate, 
	CurrencyIsoCode, Fiscal_Period__c, Forecast_Amount__c, Product_Line__c,
	Stage__c, Opportunity__c,
	Include_in_ACV_1__c,
		Include_in_ACV_2__c,
		Include_in_ACV_3__c ,
		ACV_1__c ,
		Booked_Amount__c ,
		Booked_Committed_Amount__c
	FROM Rev_copy WHERE  CAST(createddate AS DATE)<= @ref_date)

		CREATE TABLE Static_Revs 
	(
		id CHAR(18), 
		CreatedDate DATETIME, 
		Committed_Amount__c FLOAT,
		Projection__c FLOAT,
		Actual__c FLOAT
	)
	
	INSERT INTO Static_Revs(id, createddate, Committed_Amount__c ,Projection__c ,Actual__c )
	(SELECT id, createddate, Committed_Amount__c ,Projection__c ,Actual__c  
	FROM Rev_copy WHERE id NOT IN 
	(SELECT DISTINCT ParentId FROM RFH_Copy 
	WHERE Field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c'))
	AND  CAST(createddate AS DATE) <=  @ref_date)
	
	
	UPDATE Rev_snap 
	SET Committed_Amount__c = b.Committed_Amount__c,
	Projection__c= b.Projection__c,
	 Actual__c=b.Actual__c FROM Rev_snap a JOIN Static_Revs b ON a.id = b.id
	
		
	CREATE TABLE t_rfh_last_record 
	(
		ParentId CHAR(18),
		field VARCHAR(25), 
		newvalue NVARCHAR(119), 
		createddate DATETIME
	)

	CREATE TABLE t_rfh_last_record2 
	(		
		ParentId CHAR(18),
		field VARCHAR(25), 
		oldvalue NVARCHAR(119), 
		createddate DATETIME
	)
	EXEC dbo.Rev_Prev_Records   @ref_date
	EXEC dbo.Rev_Next_Records   @ref_date



	UPDATE Rev_snap 
	SET Committed_Amount__c = b.newvalue FROM Rev_snap a JOIN t_rfh_last_record b
	 ON a.id = b.ParentId WHERE b.field = 'Committed_Amount__c' 
	 AND a.Committed_Amount__c IS  NULL

	UPDATE Rev_snap
	SET Projection__c = b.newvalue FROM Rev_snap a JOIN  t_rfh_last_record b 
	ON a.id = b.ParentId WHERE b.field = 'Projection__c' 
	AND a.Projection__c IS  NULL

	UPDATE Rev_snap 
	SET Actual__c = b.newvalue FROM Rev_snap a JOIN  t_rfh_last_record b 
	ON a.id = b.ParentId WHERE b.field = 'Actual__c' 
	AND a.Actual__c IS  NULL


	UPDATE Rev_snap 
	SET Committed_Amount__c = b.oldvalue FROM  Rev_snap a JOIN t_rfh_last_record2 b 
	ON a.id = b.ParentId WHERE b.field = 'Committed_Amount__c' 
	AND a.Committed_Amount__c IS  NULL

	UPDATE Rev_snap 
	SET Projection__c = b.oldvalue FROM  Rev_snap a JOIN t_rfh_last_record2 b 
	ON a.id = b.ParentId WHERE b.field = 'Projection__c' 
	AND a.Projection__c IS  NULL

	UPDATE Rev_snap 
	SET Actual__c = b.oldvalue FROM  Rev_snap a JOIN t_rfh_last_record2 b
	 ON a.id = b.ParentId WHERE b.field = 'Actual__c'
	 AND a.Actual__c IS  NULL


	UPDATE Rev_snap 
	SET Committed_Amount__c = b.Committed_Amount__c FROM Rev_snap a JOIN  Rev_copy b 
	ON a.id = b.id WHERE  CAST(b.createddate AS DATE) <= @ref_date
	AND a.Committed_Amount__c IS  NULL

	UPDATE Rev_snap
	SET Projection__c = b.Projection__c FROM  Rev_snap a JOIN Rev_copy b 
	ON a.id= b.id WHERE CAST(b.createddate AS DATE) <= @ref_date
	AND a.Projection__c IS  NULL

	UPDATE Rev_snap 
	SET Actual__c = b.Actual__c FROM Rev_snap a JOIN  Rev_copy b 
	ON a.id= b.id WHERE  CAST(b.createddate AS DATE) <= @ref_date
	AND a.Actual__c IS  NULL



	DROP TABLE IF  EXISTS t_static_opps2
	DROP TABLE IF  EXISTS t_ofh_last_record
	DROP TABLE IF  EXISTS t_ofh_last_record2
	DROP TABLE IF  EXISTS Static_Revs
	DROP TABLE IF  EXISTS t_rfh_last_record
	DROP TABLE IF  EXISTS t_rfh_last_record2

	END


	UPDATE Rev_snap
	SET Actual__c=NULL
	WHERE Actual__c=999950000

	UPDATE Rev_snap
	SET Committed_Amount__c=NULL
	WHERE Committed_Amount__c=999950000

	UPDATE Rev_snap
	SET Projection__c=NULL
	WHERE Projection__c=999950000


	------------------Creation of Snapshot-----------------------
	SELECT
	o.id as opp_id,
	o.Country__c as opp_Country__c,
	o.Theater as opp_theatre__c,
	o.Segment as opp_segment__c,
	o.closedate as opp_closedate,
	o.ownerid as opp_ownerid,
	o.createddate as opp_CreatedDate,
	o.Account_id as opp_accountid,
	o.name as opp_name,
	o.stagename as opp_stagename,
	o.Probability as opp_probability,
	o.type as opp_type,
	o.leadsource as opp_leadsource,
	o.isclosed as opp_isclosed,
	o.iswon as opp_iswon,
	o.Gate as opp_gate__c,
	o.heatmap as opp_heat_map__c,
	o.Primary_Data_Center as opp_primary_data_center__c,
	o.Sales_Channel as opp_sales_channel__c,
	o.secondary_data_center__c as opp_secondary_data_center__c,
	o.Opportunity_Number__c as opp_Opportunity_Number__c,
	o.sub_segment__c as opp_sub_segment__c,
	o.emc_opportunity_number__c as opp_emc_opportunity_number__c,
	o.lead_partner_type__c as opp_lead_partner_type__c,
	o.lead_partner__c as opp_lead_partner__c,
	o.opportunity_conversion__c as opp_opportunity_conversion__c,
	o.related_opportunity__c as opp_related_opportunity__c,
	o.related_product_amount__c as opp_related_product_amount__c,
	o.so_number__c as opp_so_number__c,
	o.dell_technologies_business__c as opp_dell_technologies_business__c,
	o.opportunity_age__c as opp_opportunity_age__c,
	o.pardot_campaign__c as opp_pardot_campaign__c,
	o.Primary_Partner_Role__c as opp_Primary_Partner_Role__c,
	CASE WHEN ISNULL(o.application__c,'a') IN ('Epic','Meditech','Cerner')
	THEN 1 ELSE 0 END as opp_application_flag,
	c.user_id,
	c.user_employeenumber,
	c.user_name,
	c.user_division,
	c.user_department,
	c.user_email,
	c.user_userroleid,
	c.user_managerid,
	c.user_forecastenabled,
	c.ur_owner_role_name,
	d.opp_close_fiscal_quarter,
	d.fq_Fiscal_Period as fiscal_period,
	b.acc_Name,
	b.acc_industry,
	b.acc_type,
	b.acc_accountnumber,
	b.acc_ownerid,
	b.acc_original_lead_source__c,
	b.acc_segment,
	b.acc_sub_segment,
	b.acc_theater__c,
	b.acc_ucid__c,
	b.acc_affinity_id__c,
	b.acc_Dell_EMC_Segment__c,
	b.acc_site_duns__c,
	b.acc_dell_emc_area__c,
	b.acc_gu_duns__c,
	b.acc_dell_emc_district__c, 
	b.acc_Segment__c
	INTO Opp_Header
	FROM #Opportunity_temp o
	LEFT JOIN (SELECT 
	id as acc_id,
	Name as acc_Name,
	industry as acc_industry,
	type as acc_type,
	accountnumber as acc_accountnumber,
	ownerid as acc_ownerid,
	original_lead_source__c as acc_original_lead_source__c,
	segment__c as acc_segment,
	sub_segment__c as acc_sub_segment,
	theater__c as acc_theater__c,
	ucid__c as acc_ucid__c,
	affinity_id__c as acc_affinity_id__c,
	CASE 
			WHEN SUBSTRING(Dell_EMC_Segment__c,1,10)='COMMERCIAL'
			THEN 'Commercial'
			WHEN SUBSTRING(Dell_EMC_Segment__c,1,10)='ENTERPRISE'
			THEN 'Enterprise'
			WHEN SUBSTRING(Dell_EMC_Segment__c,1,7)='FEDERAL'
			THEN 'Federal'
			ELSE Dell_EMC_Segment__c
		END as acc_Dell_EMC_Segment__c,
	site_duns__c as acc_site_duns__c,
	dell_emc_area__c as acc_dell_emc_area__c,
	gu_duns__c as acc_gu_duns__c,
	dell_emc_district__c as acc_dell_emc_district__c,
	Segment__c as acc_Segment__c
	FROM Account) b
	ON o.Account_id=b.acc_id
	LEFT JOIN (SELECT u.id as user_id,
	u.employeenumber as user_employeenumber,
	u.name as user_name,
	u.division as user_division,
	u.department as user_department,
	u.email as user_email,
	u.userroleid as user_userroleid,
	u.managerid as user_managerid,
	u.forecastenabled as user_forecastenabled,
	ur.name as ur_owner_role_name
	from [dbo].[User] u LEFT JOIN UserRole ur
	ON u.userroleid = ur.id) c
	ON o.ownerid = c.user_id
	LEFT JOIN (SELECT DISTINCT fiscal_qtr As opp_close_fiscal_quarter, date as fq_date,
	Fiscal_Period as fq_Fiscal_Period FROM FiscalQuarters) d
	ON o.closedate=d.fq_date
	

SELECT	 r.Product_Line__c as Product_Line, 
CASE WHEN MAX(o.stagename) LIKE '100%'
 THEN SUM(ISNULL(CASE
		WHEN r.Include_in_ACV_1__c=1 OR
			r.Include_in_ACV_2__c=1 OR
			r.Include_in_ACV_3__c=1
		THEN
			 r.Booked_Committed_Amount__c
		ELSE NULL
		END,0)) 
 ELSE SUM(ISNULL( CASE
		WHEN r.Include_in_ACV_1__c=1 OR
			r.Include_in_ACV_2__c=1 OR
			r.Include_in_ACV_3__c=1
		THEN
			 r.Committed_Amount__c
		ELSE NULL
		END
		,0)) 
 END as
 revschd_CCV_final,
 CASE WHEN MAX(o.stagename) LIKE '100%'
 THEN SUM(ISNULL(CASE
				WHEN  r.Include_in_ACV_1__c=1 THEN r.Booked_Amount__c
				ELSE NULL
			END,0)) 
 ELSE 
SUM(ISNULL(
			CASE
				WHEN  r.Include_in_ACV_1__c=1 THEN ISNULL(r.Actual__c,ISNULL(r.Projection__c,0))
				ELSE NULL
			END
			,0))
 END as revschd_ACV_final,
			MAX(o.id) as Opportunity__c
INTO PL_Snap
FROM Rev_snap r
LEFT JOIN #Opportunity_temp o ON r.Opportunity__c=o.id
GROUP BY r.Product_Line__c


DECLARE @currency TABLE
(
	Id NVARCHAR(255),
	IsoCode CHAR(3),
	ConversionRate FLOAT
)

INSERT INTO @currency
(	Id ,
	IsoCode ,
	ConversionRate
)
(SELECT Id ,
	IsoCode ,
	ConversionRate FROM Currency_Snapshot WHERE SnapshotDate=@ref_date
)

	SELECT pl.id  as pl_id, pl.name as pl_name, pl.product__c as pl_product__c, 
	pl.service_line__c as pl_service_line__c, pl.practice_line__c as pl_practice_line__c,
	pl.term__c as pl_term__c,
		pl.committed_term_months__c as pl_committed_term_months__c,
	r.opportunity__c as pl_opportunity__c, 
p.name as product_name,
	p.quant_practice_group__c as product_quant_practice_group__c, p.family as product_family,
	r.id as Revschd_id, r.CreatedDate as revschd_CreatedDate, 
		pl.booked_amount_override__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=pl.CurrencyIsoCode)
as pl_booked_amount_override__c,
	r.committed_amount__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) as Revschd_Committed_amount__c,
	r.Projection__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode)  as revschd_projection__c,
	r.actual__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode)  as revschd_actual__c, 
	ISNULL(r.Actual__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) ,
	ISNULL(r.Projection__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) ,0)) as revschd_forecast_amount__c,
	fp.fiscal_period as revschd_fiscal_period__c,
		
		CASE WHEN o.stagename LIKE '100%'
 THEN CASE
		WHEN r.Include_in_ACV_1__c=1 OR
			r.Include_in_ACV_2__c=1 OR
			r.Include_in_ACV_3__c=1
		THEN
			 r.Booked_Committed_Amount__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) 
		ELSE NULL
		END
 ELSE CASE
		WHEN r.Include_in_ACV_1__c=1 OR
			r.Include_in_ACV_2__c=1 OR
			r.Include_in_ACV_3__c=1
		THEN
			 r.Committed_Amount__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) 
		ELSE NULL
		END
 END as
 revschd_CCV_final,
 CASE WHEN o.stagename LIKE '100%'
 THEN CASE
				WHEN  r.Include_in_ACV_1__c=1 THEN r.Booked_Amount__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) 
				ELSE NULL
			END
 ELSE 

			CASE
				WHEN  r.Include_in_ACV_1__c=1 
				THEN ISNULL(r.Actual__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode),
				ISNULL(r.Projection__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) ,0))
				ELSE NULL
			END
		
 END as revschd_ACV_final,

		CASE 
		WHEN pls.revschd_ACV_final>=  pls.revschd_CCV_final
		AND o.stagename LIKE '100%'
		THEN 
			CASE
				WHEN  r.Include_in_ACV_1__c=1 
				THEN r.Booked_Amount__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) 
				ELSE NULL
			END
		WHEN  pls.revschd_ACV_final < pls.revschd_CCV_final
		AND o.stagename LIKE '100%'
		THEN
			CASE
				WHEN  r.Include_in_ACV_1__c=1 OR
				r.Include_in_ACV_2__c=1 OR
				r.Include_in_ACV_3__c=1
				THEN r.Booked_Committed_Amount__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) 
				ELSE NULL
			END
		WHEN  pls.revschd_ACV_final>=  pls.revschd_CCV_final
		AND o.stagename NOT LIKE '100%'
		THEN
			ACV_1__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) 
		WHEN pls.revschd_ACV_final < pls.revschd_CCV_final
		AND o.stagename NOT LIKE '100%'
		THEN
			CASE
				WHEN  r.Include_in_ACV_1__c=1 OR
				r.Include_in_ACV_2__c=1 OR
				r.Include_in_ACV_3__c=1
				THEN r.Committed_Amount__c/(SELECT c.ConversionRate FROM @currency c WHERE c.IsoCode=r.CurrencyIsoCode) 
				ELSE NULL
			END
	END as revschd_booked_amount_final

	INTO Revenue_Sch_Detail
	FROM Rev_snap r 
	LEFT JOIN PL_Snap pls ON r.product_line__c=pls.Product_Line
	LEFT JOIN #Opportunity_temp o ON r.Opportunity__c=o.id
	LEFT JOIN (SELECT * FROM ProductLine WHERE isharddeleted=0) pl  
	ON r.product_line__c=pl.id
	LEFT JOIN Product2 p ON pl.product__c=p.id
	LEFT JOIN (SELECT Id, Name as fiscal_period FROM Fiscal_Period__c) fp
	ON r.fiscal_period__c=fp.Id
	

	INSERT INTO [dbo].[Revenue_Schedule_Snapshot]
	(
		revschd_id,
		pl_id, 
		pl_name,
		pl_product__c, 
		pl_service_line__c, 
		pl_practice_line__c,
		pl_term__c,
		pl_committed_term_months__c,
		opp_id,
		opp_closedate,
		opp_ownerid,
		opp_createddate,
		opp_accountid,
		opp_name,
		opp_stagename,
		opp_probability,
		opp_type,
		opp_leadsource,
		opp_isclosed,
		opp_iswon,
		opp_gate__c,
		opp_heat_map__c,
		opp_primary_data_center__c,
		opp_sales_channel__c,
		opp_secondary_data_center__c,
		opp_opportunity_number__c,
		opp_sub_segment__c,
		opp_emc_opportunity_number__c,
		opp_lead_partner_type__c,
		opp_lead_partner__c,
		opp_opportunity_conversion__c,
		opp_related_opportunity__c,
		opp_related_product_amount__c,
		opp_so_number__c,
		opp_dell_technologies_business__c,
		opp_opportunity_age__c,
		opp_pardot_campaign__c,
		opp_primary_partner_role__c,
		acc_name,
		acc_segment__c,
		acc_dell_emc_segment__c,
		product_name, 
		product_family,
		user_id,
		user_name,
		user_division,
		user_department,
		user_email,
		user_userroleid,
		user_managerid,
		user_forecastenabled,
		ur_owner_role_name,
		revschd_createddate,
		revschd_committed_amount__c ,
		revschd_projection__c ,
		revschd_actual__c  ,
		revschd_forecast_amount__c  ,
		revschd_ccv_final ,
		revschd_acv_final ,
		pl_booked_amount_override__c,
		revschd_booked_amount_final , 
		revschd_fiscal_period__c,
		m1_role_name,
		m2_role_name,
		m3_role_name,
		m4_role_name,
		m5_role_name,
		role_level,
		hierarchy_global,
		hierarchy_theatre,
		hierarchy_segment,
		hierarchy_division,
		hierarchy_area,
		user_employeenumber,
		opp_country__c,
		opp_theatre__c,
		product_quant_practice_group__c,
		opp_segment__c,
		opp_close_fiscal_quarter,
		fiscal_period,
		ccv_por_value, 
		acv_por_value, 
		field_source,
		por_type, 
		quota_value,
		role_quota,
		territory_quota, 	
		snapshot_date,
		opp_application_flag
		
	)
	(
		SELECT 
		revsc.revschd_id,
		revsc.pl_id, 
		revsc.pl_name,
		revsc.pl_product__c, 
		revsc.pl_service_line__c, 
		revsc.pl_practice_line__c,
		revsc.pl_term__c,
		revsc.pl_committed_term_months__c,
		opphead.opp_id,
		opphead.opp_closedate,
		opphead.opp_ownerid,
		opphead.opp_CreatedDate,
		opphead.opp_accountid,
		opphead.opp_name,
		opphead.opp_stagename,
		opphead.opp_probability,
		opphead.opp_type,
		opphead.opp_leadsource,
		opphead.opp_isclosed,
		opphead.opp_iswon,
		opphead.opp_gate__c,
		opphead.opp_heat_map__c,
		opphead.opp_primary_data_center__c,
		opphead.opp_sales_channel__c,
		opphead.opp_secondary_data_center__c,
		opphead.opp_Opportunity_Number__c,
		opphead.opp_sub_segment__c,
		opphead.opp_emc_opportunity_number__c,
		opphead.opp_lead_partner_type__c,
		opphead.opp_lead_partner__c,
		opphead.opp_opportunity_conversion__c,
		opphead.opp_related_opportunity__c,
		opphead.opp_related_product_amount__c,
		opphead.opp_so_number__c,
		opphead.opp_dell_technologies_business__c,
		opphead.opp_opportunity_age__c,
		opphead.opp_pardot_campaign__c,
		opphead.opp_Primary_Partner_Role__c,
		opphead.acc_Name,
		opphead.acc_Segment__c,
		opphead.acc_Dell_EMC_Segment__c,
		revsc.product_name, 
		revsc.product_family,
		opphead.user_id,
		opphead.user_name,
		opphead.user_division,
		opphead.user_department,
		opphead.user_email,
		opphead.user_userroleid,
		opphead.user_managerid,
		opphead.user_forecastenabled,
		opphead.ur_owner_role_name,
		revsc.revschd_CreatedDate,		
		revsc.revschd_committed_amount__c ,
		revsc.revschd_projection__c ,
		revsc.revschd_actual__c  ,
		revsc.revschd_forecast_amount__c  ,
		revsc.revschd_CCV_final ,
		revsc.revschd_ACV_final ,
		revsc.pl_booked_amount_override__c,
		revsc.revschd_booked_amount_final ,  
		revsc.revschd_fiscal_period__c,
		rolehierarchy.M1_Role_Name,
		rolehierarchy.M2_Role_Name,
		rolehierarchy.M3_Role_Name,
		rolehierarchy.M4_Role_Name,
		rolehierarchy.M5_Role_Name,
		rolehierarchy.Role_Level,
		'Global' as hierarchy_global,
		opphead.opp_theatre__c as hierarchy_theatre,
		opphead.acc_Segment__c as hierarchy_segment,
		CASE 
			WHEN opphead.opp_theatre__c='Americas'  
			THEN 
				CASE 
					WHEN opphead.acc_Segment__c='Diamond Accounts'
					THEN CONCAT('Division ',opphead.acc_Name)
					ELSE rolehierarchy.M3_Role_Name
				END
			WHEN opphead.opp_theatre__c='EMEA'  
			THEN  
				CASE 
					WHEN opphead.acc_Segment__c='Diamond Accounts'
					THEN CONCAT('Division ',opphead.acc_Name)
					ELSE
					CASE
					WHEN opphead.opp_Country__c IN ('United Kingdom','Ireland')
					THEN 'UK Division'
					WHEN opphead.opp_Country__c='France'
					THEN 'France Division'
					WHEN opphead.opp_Country__c='United Arab Emirates'
					THEN 'UAE Division'
					WHEN opphead.opp_Country__c='Germany'
					THEN 'Germany Division'
					ELSE 'ROE Division'
					END
				END
			WHEN opphead.opp_theatre__c='APJ'  
			THEN  
				CASE 
					WHEN opphead.acc_Segment__c='Diamond Accounts'
					THEN CONCAT('Division ',opphead.acc_Name)
					ELSE
					CASE
					WHEN opphead.opp_Country__c IN ('New Zealand','Australia')
					THEN 'ANZ Division'
					WHEN opphead.opp_Country__c='Japan'
					THEN 'Japan Division'
					ELSE 'Rest of APJ Division'
					END
				END  
		END as hierarchy_division,
		CASE 
			WHEN opphead.opp_theatre__c='Americas' AND opphead.acc_Segment__c='Commercial'
			THEN rolehierarchy.M2_Role_Name
			ELSE NULL
		END as hierarchy_area,
		opphead.user_employeenumber,
		opphead.opp_Country__c,
		opphead.opp_theatre__c,
		revsc.product_quant_practice_group__c,
		opphead.opp_segment__c,
		opphead.opp_close_fiscal_quarter,
		opphead.fiscal_period,
		NULL as  ccv_por_value, 
		NULL as  acv_por_value,
		'SFDC' as Field_Source,
		'New Bookings' as por_type, 
		NULL as quota_value,
		NULL as Role_quota,
		NULL as Territory_Quota,
		CAST(@ref_date AS DATE) as snapshot_date,
		opphead.opp_application_flag
		FROM Opp_Header opphead
		LEFT JOIN Revenue_Sch_Detail revsc
		ON opphead.opp_id=revsc.pl_opportunity__c
		LEFT JOIN [User Role Based Hierarchy] rolehierarchy
		ON opphead.ur_owner_role_name=rolehierarchy.Owner_Role_Name

		UNION ALL

		SELECT  NULL as revschd_id,
NULL as pl_id,
NULL as pl_name,
NULL as pl_product__c,
NULL as pl_service_line__c,
NULL as pl_practice_line__c,
NULL as pl_term__c,
NULL as pl_committed_term_months__c,
NULL as  opp_id,
NULL as opp_closedate,
NULL as opp_ownerid,
NULL as opp_CreatedDate,
NULL as opp_accountid,
NULL as opp_name,--10
CASE WHEN data_type='Actuals'  AND por_type='Rollover Bookings'
THEN '100% Booked (Closed/Won)' END as opp_stagename,
NULL as opp_probability,
NULL as opp_type,
NULL as opp_leadsource,
NULL as opp_isclosed,
NULL as opp_iswon,
NULL as opp_gate__c,
NULL as opp_heat_map__c,
NULL as opp_primary_data_center__c,
NULL as opp_sales_channel__c,
NULL as opp_secondary_data_center__c,
NULL as opp_Opportunity_Number__c,
NULL as opp_sub_segment__c,
NULL as opp_emc_opportunity_number__c,
NULL as opp_lead_partner_type__c,
NULL as opp_lead_partner__c,
NULL as opp_opportunity_conversion__c,
NULL as opp_related_opportunity__c,
NULL as opp_related_product_amount__c,
NULL as opp_so_number__c,
NULL as opp_dell_technologies_business__c,
NULL as opp_opportunity_age__c,
NULL as opp_pardot_campaign__c,
NULL as opp_Primary_Partner_Role__c,
NULL as acc_Name,
NULL as acc_Segment__c,
--CASE WHEN classification<>'Internal' THEN
 classification 
 --END 
   as acc_Dell_EMC_Segment__c,
NULL as product_name,
NULL as product_family,
NULL as user_id,
NULL as user_name,
NULL as user_division,
NULL as user_department,
NULL as user_email,--40
NULL as user_userroleid,
NULL as user_managerid,
NULL as user_forecastenabled, 
NULL as ur_owner_role_name,
NULL as revschd_CreatedDate,
NULL as revschd_committed_amount__c ,
NULL as revschd_projection__c ,
NULL as revschd_actual__c  ,
NULL as revschd_forecast_amount__c  ,
NULL as revschd_CCV_final ,
CASE WHEN data_type='Actuals'  AND por_type='Rollover Bookings'
THEN acv_value END  as revschd_ACV_final ,
NULL as pl_booked_amount_override__c,
CASE WHEN data_type='Actuals'  AND por_type='Rollover Bookings'
 THEN ccv_value END  as revschd_booked_amount_final , 
NULL as revschd_fiscal_period__c,
NULL as M1_Role_Name,
NULL as M2_Role_Name,
NULL as M3_Role_Name,
NULL as M4_Role_Name,
NULL as M5_Role_Name,
NULL as Role_Level,
'Global' as hierarchy_global,
theatre as hierarchy_theatre,
NULL as hierarchy_segment,
NULL as hierarchy_division,
NULL as hierarchy_area,
NULL as user_employeenumber,
NULL as opp_Country__c,
theatre as opp_theatre__c,
product as product_quant_practice_group__c,
segment    as opp_segment__c,
fiscal_quarter as opp_close_fiscal_quarter,
NULL as fiscal_period,
CASE WHEN data_type='POR' THEN ccv_value END  as ccv_por_value, 
CASE WHEN data_type='POR' THEN acv_value END  as acv_por_value,
CASE WHEN data_type='POR' THEN 'POR' 
WHEN data_type='Actuals' AND por_type='Rollover Bookings'
THEN 'RolloverBookings' END as field_source,
por_type, 
NULL as quota_value,
NULL as Role_quota,
NULL as Territory_Quota,
CAST(@ref_date AS DATE) as snapshot_date,
NULL as opp_application_flag
FROM (SELECT * FROM Consolidated_POR_Data
where data_type<>'POR'
UNION ALL
SELECT theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  SUM(ccv_value) ccv_value,  SUM(acv_value) acv_value,
data_domain FROM POR_Data GROUP BY 
theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  
data_domain) a

)

	UPDATE  Revenue_Schedule_Snapshot
	SET
	Snapshot_Fiscal_Quarter =(SELECT TOP 1 * FROM (SELECT b.fiscal_qtr 
	FROM FiscalQuarters b
	WHERE  
	a.snapshot_date=b.date)sys)
	FROM Revenue_Schedule_Snapshot a
	WHERE a.snapshot_date=CAST(@ref_date AS DATE)

	DROP TABLE IF  EXISTS Opp_Header
	DROP TABLE IF  EXISTS Revenue_Sch_Detail
	DROP TABLE IF  EXISTS #Opportunity_temp
	DROP TABLE IF  EXISTS Rev_snap
	DROP TABLE IF  EXISTS PL_Snap
	
END
