/**

Triggers the updation of Daily Snapshots of Revenue_Schedule_Snapshot, it checks if any 
historical snapshot is missing then it triggers SP that recreate the missing ones.

**/

ALTER PROCEDURE Daily_Auto_Backward(@snap_date DATE, @run_time TIME)
AS
BEGIN
	DECLARE @today DATE=(SELECT CAST(GETDATE() AS DATE))

	IF EXISTS(SELECT name FROM sys.tables WHERE name='opp_copy')
	DROP TABLE opp_copy

	SELECT * INTO Opp_copy FROM Opportunity  WHERE isdeleted=0 AND isharddeleted=0

	IF  EXISTS(SELECT name FROM sys.tables WHERE name='ofh_copy')
	DROP TABLE ofh_copy

	SELECT * INTO ofh_copy FROM OpportunityFieldHistory  WHERE
	field IN ('Name', 'Type', 'Manager__c','Heat_Map__c', 'StageName','CloseDate')

	ALTER TABLE ofh_copy 
	ADD  opp_created_date DATE

	UPDATE ofh_copy 
	SET opp_created_date = CAST(b.createddate AS DATE)
	FROM OFH_Copy a JOIN Opp_copy b 
	ON a.opportunityid = b.id

	UPDATE opp_copy
	SET type='ABCD'
	WHERE type IS NULL

	UPDATE opp_copy
	SET Manager__c='ABCD'
	WHERE Manager__c IS NULL

	UPDATE ofh_copy
	SET OldValue='ABCD'
	WHERE OldValue IS NULL
	AND Field IN ('Type', 'Manager__c')

	UPDATE ofh_copy
	SET NewValue='ABCD'
	WHERE NewValue IS NULL
	AND Field IN ('Type', 'Manager__c')

	IF  EXISTS(SELECT name FROM sys.tables WHERE name='rev_copy')
	DROP TABLE rev_copy

	SELECT * INTO rev_copy FROM RevenueSchedule WHERE isdeleted=0 AND isharddeleted=0

	IF  EXISTS(SELECT name FROM sys.tables WHERE name='rfh_copy')
	DROP TABLE rfh_copy

	SELECT  * INTO rfh_copy FROM RevenueScheduleHistory
	WHERE field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	ALTER TABLE rfh_copy 
	ADD  Rev_created_date DATE

	ALTER TABLE rfh_copy
	ALTER COLUMN NewValue FLOAT

	ALTER TABLE rfh_copy
	ALTER COLUMN OldValue FLOAT

	UPDATE rfh_copy SET Rev_created_date = CAST(b.createddate AS DATE) FROM rfh_copy a JOIN RevenueSchedule b 
	ON a.ParentId = b.id

	UPDATE rev_copy
	SET Committed_Amount__c=999950000
	WHERE Committed_Amount__c IS NULL

	UPDATE rev_copy
	SET Projection__c=999950000
	WHERE Projection__c IS NULL

	UPDATE rev_copy
	SET Actual__c=999950000
	WHERE Actual__c IS NULL

	UPDATE rfh_copy
	SET OldValue=999950000
	WHERE OldValue IS NULL
	AND Field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')

	UPDATE rfh_copy
	SET NewValue=999950000
	WHERE NewValue IS NULL
	AND Field IN ('Committed_Amount__c' , 'Projection__c' , 'Actual__c')


	/* Number of Loops*/
	DECLARE @cnti INT=7

	/* Name of week in the Reverse Order*/
	DECLARE @day INT=1
	DECLARE @counter1 INT
	
	
	WHILE @cnti>0
	BEGIN

	SET @counter1=0
	

	IF(@run_time>='00:00:00' AND @run_time<'08:00:00')
	BEGIN
	SELECT @counter1=COUNT(DISTINCT Snapshot_Date) FROM Revenue_Schedule_Snapshot
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date) and Snapshot_type LIKE 'DAY%'
	and Snapshot_Date<>DATEADD(dd, -1, @today)
	
	
	IF(@counter1=0)
	BEGIN
	DELETE FROM Revenue_Schedule_Snapshot 
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date) AND Snapshot_type LIKE 'DAY%'

	
	EXEC dbo.Daily_Snapshot_Creation @snap_date, @run_time
	END

	UPDATE  Revenue_Schedule_Snapshot
	SET
	Snapshot_type =(SELECT CONCAT('DAY 0',@day))
	WHERE Snapshot_Date=DATEADD(dd, -1, @snap_date)  AND (Snapshot_type  LIKE 'DAY%' 
	OR Snapshot_type IS NULL)



	END
	ELSE
	BEGIN

		SELECT @counter1=COUNT(DISTINCT Snapshot_Date) FROM Revenue_Schedule_Snapshot
		WHERE Snapshot_Date=@snap_date and Snapshot_type LIKE 'DAY%'
		and Snapshot_Date<>@today


		IF(@counter1=0 )
		BEGIN
		DELETE FROM Revenue_Schedule_Snapshot 
		WHERE Snapshot_Date=@snap_date AND Snapshot_type LIKE 'DAY%'
	
		EXEC dbo.Daily_Snapshot_Creation @snap_date, @run_time
		END

		UPDATE  Revenue_Schedule_Snapshot
		SET
		Snapshot_type =(SELECT CONCAT('DAY 0',@day))
		WHERE Snapshot_Date=@snap_date  AND (Snapshot_type  LIKE 'DAY%' 
		OR Snapshot_type IS NULL)

		
	END
	
	SET @snap_date= DATEADD(DD,-1,@snap_date)
	SET @cnti=@cnti-1
	SET @day=@day+1
	END

	DROP TABLE IF  EXISTS ofh_copy
	DROP TABLE IF  EXISTS  rfh_copy
	DROP TABLE IF  EXISTS  opp_copy
	DROP TABLE IF  EXISTS  rev_copy
	END