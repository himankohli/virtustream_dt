

INSERT INTO Product_Line_Snapshot
(

opp_name,
opp_stagename,
opp_probability,
opp_type,
opp_leadsource,
opp_isclosed,
opp_iswon,
opp_gate__c,
opp_heat_map__c,
opp_primary_data_center__c,
opp_sales_channel__c,--19
opp_secondary_data_center__c,
opp_opportunity_number__c,
opp_sub_segment__c,
opp_emc_opportunity_number__c,
opp_lead_partner_type__c,
opp_lead_partner__c,
opp_opportunity_conversion__c,
opp_related_opportunity__c,
opp_related_product_amount__c,
opp_so_number__c,
opp_dell_technologies_business__c,
opp_opportunity_age__c,
opp_pardot_campaign__c,
opp_primary_partner_role__c,
opp_application_flag,
acc_name,
acc_segment__c,
acc_dell_emc_segment__c,
product_name, 
product_family,
user_id,
user_name,
user_division,
user_department,
user_email,--40
user_userroleid,
user_managerid,
user_forecastenabled,
ur_owner_role_name,
revschd_committed_amount__c,
revschd_projection__c,
revschd_actual__c, 
revschd_forecast_amount__c, 
revschd_ccv_final,
revschd_acv_final,
revschd_booked_amount_final,
m1_role_name,
m2_role_name,
m3_role_name,
m4_role_name,
m5_role_name,
role_level,
hierarchy_global,
hierarchy_theatre,
hierarchy_segment,
hierarchy_division,
hierarchy_area,
user_employeenumber,
opp_country__c,
opp_theatre__c,
product_quant_practice_group__c,
opp_segment__c,
opp_close_fiscal_quarter,
fiscal_period,
id_rev_schd,
ccv_por_value, 
acv_por_value,
field_source,
por_type, 
quota_value,
role_quota,
territory_quota, 
strategic_alliance_flag,
closedate_change_count,
channel,
opp_dell_technologies_role__c,
snapshot_type, snapshot_date, snapshot_fiscal_quarter, current_fiscal_period 
)
(SELECT * FROM
(
SELECT  
CASE WHEN data_type='Actuals' THEN por_type END as opp_name,--10
CASE WHEN data_type='Actuals' THEN '100% Booked (Closed/Won)' END as opp_stagename,
NULL as opp_probability,
NULL as opp_type,
NULL as opp_leadsource,
NULL as opp_isclosed,
NULL as opp_iswon,
NULL as opp_gate__c,
NULL as opp_heat_map__c,
NULL as opp_primary_data_center__c,
NULL as opp_sales_channel__c,
NULL as opp_secondary_data_center__c,
NULL as opp_Opportunity_Number__c,
NULL  as opp_sub_segment__c,
NULL as opp_emc_opportunity_number__c,
NULL as opp_lead_partner_type__c,
NULL as opp_lead_partner__c,
NULL as opp_opportunity_conversion__c,
NULL as opp_related_opportunity__c,
NULL as opp_related_product_amount__c,
NULL as opp_so_number__c,
NULL as opp_dell_technologies_business__c,
NULL as opp_opportunity_age__c,--30
NULL as opp_pardot_campaign__c, 
NULL as opp_Primary_Partner_Role__c,
NULL as opp_application_flag,
NULL as acc_Name,
NULL as acc_Segment__c,
classification    as acc_Dell_EMC_Segment__c,
NULL as product_name,
NULL as product_family,
NULL as user_id,
NULL as user_name,
NULL as user_division,
NULL as user_department,
NULL as user_email,--40
NULL as user_userroleid,
NULL as user_managerid,
NULL as user_forecastenabled, 
NULL as ur_owner_role_name,
 NULL as revschd_committed_amount__c,
  NULL as revschd_Projection__c,
  NULL as revschd_actual__c,
NULL as revschd_forecast_amount__c,
NULL as revschd_CCV_final,
--CASE WHEN data_type='Actuals' THEN acv_value END  
0 as revschd_ACV_final,
--CASE WHEN data_type='Actuals' THEN ccv_value END 
0  as revschd_booked_amount_final,
NULL as M1_Role_Name,
NULL as M2_Role_Name,
NULL as M3_Role_Name,
NULL as M4_Role_Name,
NULL as M5_Role_Name,
NULL as Role_Level,
'Global' as hierarchy_global,
theatre as hierarchy_theatre,
NULL as hierarchy_segment,
NULL as hierarchy_division,
NULL as hierarchy_area,
NULL as user_employeenumber,
NULL as opp_Country__c,
theatre as opp_theatre__c,
product as product_quant_practice_group__c,
segment  as opp_segment__c,
fiscal_quarter as opp_close_fiscal_quarter,
NULL as fiscal_period,
'por' as id_rev_schd,
CASE WHEN data_type='POR' THEN ccv_value END  as ccv_por_value, 
CASE WHEN data_type='POR' THEN acv_value END  as acv_por_value,
CASE WHEN data_type='POR' THEN 'POR'  
WHEN por_type='Rollover Bookings' THEN 'RolloverBookings'
ELSE por_type END as field_source,
por_type, 
NULL as quota_value,
NULL as Role_quota,
NULL as Territory_Quota,
NULL as strategic_alliance_flag,
NULL as closedate_change_count,
NULL as channel,
NULL as opp_dell_technologies_role__c
FROM Consolidated_POR_Data
------What to insert?------
where por_type IN ('Debookings','Finance Adjustments')) b
CROSS JOIN
(SELECT DISTINCT snapshot_type, snapshot_date, snapshot_fiscal_quarter, current_fiscal_period FROM Product_Line_Snapshot
where snapshot_type<='WEEK 13') a)

--------------------Testing--------------------
--SELECT snapshot_type, field_source, count(*)  FROM Product_Line_Snapshot
--where snapshot_type<='WEEK 13'
--GROUP BY snapshot_type, field_source
--ORDER By 1,2


/*

SELECT * INTO Consolidated_POR_Data_bkp_20181228 FROM Consolidated_POR_Data
DROP TABLE UAT_Staging.dbo.Consolidated_POR_Data

SELECT * INTO UAT_Staging.dbo.Consolidated_POR_Data FROM Dev_Staging.dbo.Consolidated_POR_Data

SELECT data_type, por_type, sum(ccv_value)
FROM Consolidated_POR_Data
GROUP BY data_type, por_type



*/
	
