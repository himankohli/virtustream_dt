/**

[dbo].[ingestion_check] checks whether the Ingestion Process is completed successfully or not.
When Ingestion is successfully completed, it calls continues to tranformation process.
Incase, Ingestion is failed, it stops the process.

**/
ALTER PROCEDURE [dbo].[ingestion_check]
AS
BEGIN

SET XACT_ABORT ON
SET NOCOUNT ON

	DECLARE @check_flag INT=1
	DECLARE @loop INT=20
	DECLARE @count INT
	DECLARE @rc INT
		
	SELECT @rc=COUNT(cnt) FROM 
	(SELECT  COUNT(ObjectName) as cnt 
	FROM [Row_Count] GROUP BY ObjectName) c

	
		IF (@rc<>20)
		BEGIN
			INSERT INTO u_audit_log
			values((SELECT 'Ingestion Failed'),0,GETDATE(),NULL,NULL,NULL)
		END
		ELSE
		BEGIN
			INSERT INTO u_audit_log
			values('Ingestion Successful',1,GETDATE(),NULL,NULL,NULL)

			DECLARE @a INT=(SELECT COUNT(*) FROM sys.tables where name IN
			('OpportunityContactRole',
			'Sales_Credit_Detail',
			'Event',
			'Lead',
			'Task',
			'Campaign',
			'CampaignMember',
			'Opportunity',
			'UserRole',
			'RevenueSchedule',
			'OpportunityTeamMember',
			'Fiscal_Period__c',
			'Account',
			'OpportunityFieldHistory',
			'ProductLine',
			'RevenueScheduleHistory',
			'Product2',
			'CurrencyType',
			'Contact',
			'User'))

			IF (@a<>20)
			BEGIN
				INSERT INTO u_audit_log
				values('Raw Object Missing: Execution Stopped',0,GETDATE(),NULL,NULL,NULL)

			END
			ELSE
			BEGIN
			
				BEGIN TRANSACTION
				EXEC [dbo].[init_transformation]
				EXEC [dbo].[delete_temporary_objects]
				INSERT INTO [dbo].[u_audit_log]
				values('P1 Execution Completed',1,GETDATE(),NULL,NULL,NULL)
				COMMIT  TRANSACTION

				BEGIN TRANSACTION
				EXEC [dbo].[currency_snap_master]
				COMMIT  TRANSACTION
				

				DECLARE @r INT=(SELECT COUNT(*) FROM u_audit_log
				where Pass=1 AND Object_Name='P1 Execution Completed'
				AND Import_ts>=(SELECT DATEADD(HH,-1,GETDATE())))

				IF(@r>=1)
				BEGIN
				
				/*
				Live Code
				BEGIN TRANSACTION
					EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'VSASQLSTG01',
@recipients = 'himanshu.kohli@forecastera.com; ashwani.bhatt@forecastera.com ; angad@forecastera.com ; avni.sood@forecastera.com ; Ajay.rayaroth@forecastera.com',
@subject = 'VS Sales BI: Live Run: P1 Success',
@body = 'The process run P1 for VS Sales BI Project in Live Environment is complete and the data ingestion is successfully completed';
COMMIT TRANSACTION
*/

				BEGIN TRANSACTION
				EXEC [dbo].[sp_intermediary_objects]
				COMMIT  TRANSACTION

				BEGIN TRANSACTION
				EXEC [dbo].[sp_Executive_POR_Data] 			
				
				COMMIT  TRANSACTION
				
		BEGIN TRANSACTION		
		EXEC [dbo].[sp_customer]
		INSERT INTO [dbo].[u_audit_log]
				values('u_Customer: Object updated',
				1,GETDATE(),NULL, NULL,NULL)
		COMMIT  TRANSACTION

		BEGIN TRANSACTION
		EXEC [dbo].[sp_account]
		INSERT INTO [dbo].[u_audit_log]
		values('u_Account: Object updated',1,GETDATE(),NULL, NULL,NULL)
		COMMIT  TRANSACTION

		BEGIN TRANSACTION
		EXEC [dbo].[sp_Marketing]
		INSERT INTO [dbo].[u_audit_log]
		values('Marketing Tables updated',1,GETDATE(),NULL, NULL,NULL)
		COMMIT  TRANSACTION

		BEGIN TRANSACTION
			EXEC [dbo].[product_line_snapshot_update]

			DECLARE @x INT=(SELECT COUNT(*) FROM [dbo].[Product_Line_Snapshot]
			WHERE [snapshot_type]='DAY 01' AND [field_source]='SFDC'
			AND pl_id IS NOT NULL)

			DECLARE @b INT=(SELECT COUNT(*) FROM Opportunity o 
			LEFT JOIN ProductLine pl  ON o.Id=pl.Opportunity__c
			LEFT JOIN Product2 p ON pl.product__c=p.id where o.IshardDeleted=0 AND pl.isharddeleted=0)

			DECLARE @p INT=(SELECT COUNT(DISTINCT snapshot_type) FROM Product_Line_Snapshot
	WHERE isharddeleted=0)

	IF(@x<>@b)
	BEGIN
		INSERT INTO [dbo].[u_audit_log]
		values('Product_Line_Snapshot: Record Count Not Matching',0,GETDATE(),NULL,NULL,NULL)
	END
	ELSE
	BEGIN

		IF(@p<>106)
		BEGIN
		INSERT INTO  [dbo].[u_audit_log]
		values('Product_Line_Snapshot: Snapshot Missing',0,GETDATE(),NULL, NULL,NULL)
		END
		ELSE
		BEGIN
		INSERT INTO  [dbo].[u_audit_log]
		values('Product_Line_Snapshot: Object updated',1,GETDATE(),NULL, NULL,NULL)
		END
	END
			COMMIT  TRANSACTION

			BEGIN  TRANSACTION
			EXEC [dbo].[sp_PLS_wRollover_Waterfall]

			INSERT INTO [dbo].[u_audit_log]
			values('u_PLS_wRollover_Waterfall: Object updated',1,GETDATE(),NULL, NULL,NULL)
			COMMIT  TRANSACTION
		
		
			BEGIN  TRANSACTION
		EXEC [dbo].[sales_rep_data]
		INSERT INTO [dbo].[u_audit_log]
		values('Sales Rep: Object updated',1,GETDATE(),NULL, NULL,NULL)
		COMMIT  TRANSACTION

			BEGIN  TRANSACTION		
			EXEC [dbo].[revenue_schedule_snapshot_update]

			DECLARE @c INT=
			(SELECT COUNT(*) FROM [dbo].[Revenue_Schedule_Snapshot] 
			where snapshot_type='DAY 01' AND field_source='SFDC' 
			AND revschd_id IS NOT NULL)

	DECLARE @d INT=
	(SELECT COUNT(*) FROM Opportunity o LEFT JOIN RevenueSchedule r
	ON o.Id=r.Opportunity__c where o.isdeleted=0 and o.isharddeleted=0 
	and r.isdeleted=0 and r.isharddeleted=0  AND r.id IS NOT NULL)

	DECLARE @q INT=(SELECT COUNT(DISTINCT snapshot_type) FROM Revenue_Schedule_Snapshot
	WHERE isharddeleted=0)

				IF(@c<>@d)
				BEGIN
					INSERT INTO [dbo].[u_audit_log]
					values('Revenue_Schedule_Snapshot: Record Count Not Matching',0,GETDATE(),NULL,NULL,NULL)
				END
				ELSE
				BEGIN

					IF(@q<>20)
					BEGIN
		INSERT INTO [dbo].[u_audit_log]
		values('Revenue_Schedule_Snapshot: Snapshot Missing',0,GETDATE(),NULL, NULL,NULL)
					END
					ELSE
					BEGIN
					INSERT INTO [dbo].[u_audit_log]
					values('Revenue_Schedule_Snapshot: Object updated',1,
					GETDATE(),NULL, NULL,NULL)
					END
				END	
				COMMIT TRANSACTION

				BEGIN TRANSACTION
				EXEC dbo.sp_DealDesk_Snapshot
				INSERT INTO [dbo].[u_audit_log]
				values('Deal Desk Snapshots updated',1,GETDATE(),NULL,NULL,NULL)
				COMMIT TRANSACTION
				
				BEGIN TRANSACTION
				INSERT INTO [dbo].[u_audit_log]
				values('P2 Execution Completed',1,GETDATE(),NULL,NULL,NULL)
				COMMIT TRANSACTION


				--------------------Live Env Code-----------------------
				/*DECLARE @s INT=(SELECT COUNT(*) FROM u_audit_log
				where Pass=1 AND Object_Name='P2 Execution Completed'
				AND Import_ts>=(SELECT DATEADD(HH,-1,GETDATE())))

				IF(@s>=1)
				BEGIN
				
				
				BEGIN TRANSACTION
					EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'VSASQLSTG01',
@recipients = 'himanshu.kohli@forecastera.com; ashwani.bhatt@forecastera.com ; angad@forecastera.com ; avni.sood@forecastera.com ; Ajay.rayaroth@forecastera.com',
@subject = 'VS Sales BI: Live Run: P2 Success',
@body = 'The process run P2 for VS Sales BI Project in Live Environment is complete and the data ingestion is successfully completed';
COMMIT TRANSACTION

				
				
				BEGIN TRANSACTION
				EXEC UAT_Prod_move
				COMMIT TRANSACTION
				END*/
				----------------------------------------
			END
		END
	END
END

