


CREATE TABLE [dbo].[Consolidated_POR_Data](
	[theatre] [varchar](50) NULL,
	[segment] [varchar](50) NULL,
	[product] [varchar](50) NULL,
	[classification] [varchar](50) NULL,
	[fiscal_quarter] [varchar](50) NULL,
	[data_type] [varchar](50) NULL,
	[por_type] [varchar](50) NULL,
	[ccv_value] FLOAT NULL,
	[acv_value] FLOAT NULL,
	[data_domain] [varchar](50) NULL
)

CREATE TABLE [dbo].[POR_Data](
	[Week] [int] NOT NULL,
	[theatre] [varchar](50) NULL,
	[segment] [varchar](50) NULL,
	[product] [varchar](50) NULL,
	[classification] [varchar](50) NULL,
	[fiscal_quarter] [varchar](50) NULL,
	[data_type] [varchar](50) NULL,
	[por_type] [varchar](50) NULL,
	[ccv_value] [float] NULL,
	[acv_value] [float] NULL,
	[data_domain] [varchar](50) NULL
) 


ALTER TABLE New_Consolidated_POR_20190107
ALTER COLUMN [acv_value] FLOAT 


-----------------------Backup---------------------


SELECT * INTO Consolidated_POR_Data_bkp_20190205 FROM Consolidated_POR_Data

------------------------Insert more combination----------------
INSERT INTO Consolidated_POR_Data
(theatre,
segment,
product,
classification,
fiscal_quarter,
data_type,
por_type,
ccv_value,
acv_value,
data_domain)
SELECT theatre,
segment,
product,
classification,
'2020 Q4' as fiscal_quarter,
data_type,
por_type,
0 as ccv_value,
0 as acv_value,
data_domain FROM Consolidated_POR_Data
where fiscal_quarter='2019 Q4'
-----------------------Update-----------------------------------
UPDATE a
SET ccv_value=CAST(coalesce(b.ccv_value,0) AS FLOAT),
acv_value=CAST(coalesce(b.acv_value,0) AS FLOAT)
 FROM Consolidated_POR_Data a LEFT JOIN New_Consolidated_POR_Data_20190213 b
ON  a.theatre=b.theatre
AND a.product=b.product AND a.segment=b.segment
AND  a.Classification=b.Classification AND
 a.data_type=b.data_type AND a.por_type=b.por_type AND
a.fiscal_quarter=b.fiscal_quarter
--------------------Optional WHERe clause------------------------
WHERE a.fiscal_quarter='2019 Q4'
--AND a.data_type='Actuals' AND a.POR_type='Rollover Bookings'



--------------------------Code Testing----------------------

SELECT POR_type,fiscal_quarter, COUNT(*),
SUM(CAST(ccv_value AS FLOAT)) FROM Consolidated_POR_Data
where fiscal_quarter='2019 Q4' and Data_type='Actuals' --AND POR_type='Rollover Bookings'
GROUP BY POR_type,fiscal_quarter


SELECT fiscal_quarter,SUM(CAST(ccv_value AS FLOAT))
FROM Consolidated_POR_Data_bkp_20181210
where Data_type='Actuals'
GROUP BY fiscal_quarter

-----------------Move to Dev_Staging---------------------
DROP TABLE  Dev_Staging.dbo.Consolidated_POR_Data


SELECT * INTO    Dev_Staging.dbo.Consolidated_POR_Data
FROM UAT_Staging.dbo.Consolidated_POR_Data

------------------Move to Live Environment-----
INSERT INTO VSASQLSTG01.Staging.dbo.Consolidated_POR_Data
SELECT * FROm Consolidated_POR_Data


-----------------------------ROLBACK-------------------------

DROP TABLE Consolidated_POR_Data

SELECT * INTO  Consolidated_POR_Data
FROM UAT_Staging.dbo.Consolidated_POR_Data_bkp_20181127


INSERT INTO VSASQLSTG01.Staging.dbo.Consolidated_POR_Data
SELECT * FROm Consolidated_POR_Data





----------Updating PLS with consolidated data---------------------

SELECT * INTO PLS_bkp FROM Product_Line_Snapshot


UPDATE a
SET ccv_por_value=CAST(coalesce(b.ccv_value,0) AS FLOAT),
acv_por_value=CAST(coalesce(b.acv_value,0) AS FLOAT),
revschd_booked_amount_final=(SELECT NULL),
revschd_acv_final=(SELECT NULL)
 FROM Product_Line_Snapshot a LEFT JOIN Consolidated_POR_Data_bkp_20181127 b
ON  a.opp_theatre__c=b.theatre
AND a.product_quant_practice_group__c=b.product 
AND a.opp_segment__c=b.segment
AND  a.acc_dell_emc_segment__c=b.Classification AND
 a.field_source=(CASE WHEN b.data_type='Actuals' THEN 'RolloverBookings'
 ELSE b.data_type END ) AND a.por_type=b.por_type AND
a.opp_close_fiscal_quarter=b.fiscal_quarter
WHERE  snapshot_type<='WEEK 13'
AND field_source='POR'
AND a.snapshot_date<'2018-11-27'


UPDATE a
SET ccv_por_value=(SELECT NULL),
acv_por_value=(SELECT NULL),
revschd_booked_amount_final=CAST(coalesce(b.ccv_value,0) AS FLOAT),
revschd_acv_final=CAST(coalesce(b.acv_value,0) AS FLOAT)
 FROM Product_Line_Snapshot a LEFT JOIN Consolidated_POR_Data_bkp_20181127 b
ON  a.opp_theatre__c=b.theatre
AND a.product_quant_practice_group__c=b.product 
AND a.opp_segment__c=b.segment
AND  a.acc_dell_emc_segment__c=b.Classification AND
 a.field_source=(CASE WHEN b.data_type='Actuals' THEN 'RolloverBookings'
 ELSE b.data_type END ) AND a.por_type=b.por_type AND
a.opp_close_fiscal_quarter=b.fiscal_quarter
WHERE  snapshot_type<='WEEK 13'
AND field_source='RolloverBookings'
AND a.snapshot_date<'2018-11-27'

------------------Update Weekly POR_Data------------------

UPDATE POR_Data
SET classification=(SELECT NULL)
where  classification='(blank)'

UPDATE a
SET  ccv_value=CAST(coalesce(b.ccv_value,0) AS FLOAT),
acv_value=CAST(coalesce(b.acv_value,0) AS FLOAT)
 FROM POR_Data a  LEFT JOIN New_POR_Data_20190114 b
ON  a.theatre=b.theatre
AND a.product=b.product AND a.segment=b.segment
AND  a.Classification=b.Classification AND
 a.Week=b.Week AND a.por_type=b.por_type AND
a.fiscal_quarter=b.fiscal_quarter
-----------Optional where clause--------
where a.fiscal_quarter LIKE '2020%'



----------------------Uncumulate POR_Data-------------------

sp_rename 'POR_Data','POR_data_Cumulative'

TRUNCate tABLE POR_Data

INSERT INTO POR_Data
SELECT week,theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  ccv_value, acv_value,
data_domain FROM POR_data_Cumulative where Week=1


DECLARE @a INT=13
WHILE @a>1
BEGIN
INSERT INTO POR_Data
SELECT a.week,a.theatre, a.segment, a.product, a.classification,
 a.fiscal_quarter,
a.data_type, a.por_type,  a.ccv_value - b.ccv_value ccv_value , 
a.acv_value - b.acv_value acv_value,
a.data_domain FROM 
(SELECT week,theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  ccv_value, acv_value,
data_domain FROM POR_data_Cumulative where Week=@a) a
 JOIN
(SELECT week,theatre, segment, product, classification, fiscal_quarter,
data_type, por_type,  ccv_value, acv_value,
data_domain FROM POR_data_Cumulative where Week=@a-1) b
ON a.theatre= b.theatre AND a.segment =b.segment AND a.product =b.product AND 
 a.classification =b.classification 
 AND  a.fiscal_quarter =b.fiscal_quarter AND 
 a.por_type= b.por_type
 SET @a=@a-1
 END

 -----------------Move to Dev_Staging---------------------
DROP TABLE IF EXISTS Dev_Staging.dbo.POR_Data


SELECT * INTO    Dev_Staging.dbo.POR_Data
FROM UAT_Staging.dbo.POR_Data


INSERT INTO VSASQLSTG01.Staging.dbo.POR_Data
SELECT * FROm POR_Data


SELECT COUNT(*) FROM POR_Data
------------------------Insert more combination----------------
INSERT INTO POR_Data
(Week,

theatre,
segment,
product,
classification,
fiscal_quarter,
data_type,
por_type,
ccv_value,
acv_value,
data_domain)
SELECT Week,
theatre,
segment,
product,
classification,
'2020 Q4' as fiscal_quarter,
data_type,
por_type,
0 as ccv_value,
0 as acv_value,
data_domain FROM POR_Data
where fiscal_quarter='2019 Q4'



--------------------Removing extra field from Finance Data----------------


ALTER TABLE Finance_Adjustments_20190204
ALTER COlUMN [ acv_value ] FLOAT
ALTER TABLE Finance_Adjustments_20190204
ALTER COlUMN [ ccv_value ] FLOAT



UPDATE a
SET ccv_value=CAST(coalesce(b.ccv_value,0) AS FLOAT),
acv_value=CAST(coalesce(b.acv_value,0) AS FLOAT)
 FROM Consolidated_POR_Data a LEFT JOIN 
 (SELECT [theatre]
      ,[product]
      ,[segment]
      ,[fiscal_quarter]
      ,SUM([acv_value]) as [acv_value]
      ,SUM([ccv_value]) as [ccv_value]
      ,[data_type]
      ,[por_type]
      ,[Classification]
      ,[data_domain] FROM New_Consolidated_POR_Data_20190213 where por_type='Finance Adjustments'
GROUP BY [theatre]
      ,[product]
      ,[segment]
      ,[fiscal_quarter]
      ,[data_type]
      ,[por_type]
      ,[Classification]
      ,[data_domain]) b
ON  a.theatre=b.theatre
AND a.product=b.product AND a.segment=b.segment
AND  a.Classification=b.Classification AND
 a.data_type=b.data_type AND a.por_type=b.por_type AND
a.fiscal_quarter=b.fiscal_quarter
WHERE a.fiscal_quarter='2019 Q4'
ANd a.data_type='Actuals' AND a.POR_type='Finance Adjustments'

----------------Checking Update numbers for Finance Adjustments----


SELECT fiscal_quarter,SUM(CAST(ccv_value AS FLOAT)) FROM Consolidated_POR_Data
where por_type = 'Finance Adjustments'
GROUP BY fiscal_quarter ORDER BY 1

SELECT fiscal_quarter, SUM([ ccv_value ]) FROM Finance_Adjustments_20190204
where por_type = 'Finance Adjustments'
GROUP BY fiscal_quarter ORDER BY 1


SELECT opp_close_fiscal_quarter, SUM(revschd_booked_amount_final) FROM Product_Line_Snapshot
where snapshot_type='DAY 01' AND field_source ='Finance Adjustments'
GROUP BY opp_close_fiscal_quarter ORDER BY 1
